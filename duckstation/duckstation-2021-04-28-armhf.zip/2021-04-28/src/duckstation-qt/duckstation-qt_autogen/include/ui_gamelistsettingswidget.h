/********************************************************************************
** Form generated from reading UI file 'gamelistsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMELISTSETTINGSWIDGET_H
#define UI_GAMELISTSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GameListSettingsWidget
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTableView *searchDirectoryList;
    QHBoxLayout *horizontalLayout;
    QPushButton *addSearchDirectoryButton;
    QPushButton *removeSearchDirectoryButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *scanForNewGames;
    QPushButton *rescanAllGames;

    void setupUi(QWidget *GameListSettingsWidget)
    {
        if (GameListSettingsWidget->objectName().isEmpty())
            GameListSettingsWidget->setObjectName(QStringLiteral("GameListSettingsWidget"));
        GameListSettingsWidget->resize(527, 376);
        gridLayout = new QGridLayout(GameListSettingsWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(GameListSettingsWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        searchDirectoryList = new QTableView(GameListSettingsWidget);
        searchDirectoryList->setObjectName(QStringLiteral("searchDirectoryList"));

        verticalLayout->addWidget(searchDirectoryList);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        addSearchDirectoryButton = new QPushButton(GameListSettingsWidget);
        addSearchDirectoryButton->setObjectName(QStringLiteral("addSearchDirectoryButton"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(addSearchDirectoryButton->sizePolicy().hasHeightForWidth());
        addSearchDirectoryButton->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/list-add.png"), QSize(), QIcon::Normal, QIcon::Off);
        addSearchDirectoryButton->setIcon(icon);

        horizontalLayout->addWidget(addSearchDirectoryButton);

        removeSearchDirectoryButton = new QPushButton(GameListSettingsWidget);
        removeSearchDirectoryButton->setObjectName(QStringLiteral("removeSearchDirectoryButton"));
        sizePolicy.setHeightForWidth(removeSearchDirectoryButton->sizePolicy().hasHeightForWidth());
        removeSearchDirectoryButton->setSizePolicy(sizePolicy);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/list-remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        removeSearchDirectoryButton->setIcon(icon1);

        horizontalLayout->addWidget(removeSearchDirectoryButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        scanForNewGames = new QPushButton(GameListSettingsWidget);
        scanForNewGames->setObjectName(QStringLiteral("scanForNewGames"));
        sizePolicy.setHeightForWidth(scanForNewGames->sizePolicy().hasHeightForWidth());
        scanForNewGames->setSizePolicy(sizePolicy);
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/folder-open.png"), QSize(), QIcon::Normal, QIcon::Off);
        scanForNewGames->setIcon(icon2);

        horizontalLayout->addWidget(scanForNewGames);

        rescanAllGames = new QPushButton(GameListSettingsWidget);
        rescanAllGames->setObjectName(QStringLiteral("rescanAllGames"));
        sizePolicy.setHeightForWidth(rescanAllGames->sizePolicy().hasHeightForWidth());
        rescanAllGames->setSizePolicy(sizePolicy);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/view-refresh.png"), QSize(), QIcon::Normal, QIcon::Off);
        rescanAllGames->setIcon(icon3);

        horizontalLayout->addWidget(rescanAllGames);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);


        retranslateUi(GameListSettingsWidget);

        QMetaObject::connectSlotsByName(GameListSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *GameListSettingsWidget)
    {
        GameListSettingsWidget->setWindowTitle(QApplication::translate("GameListSettingsWidget", "Form", nullptr));
        label->setText(QApplication::translate("GameListSettingsWidget", "Search Directories", nullptr));
        addSearchDirectoryButton->setText(QApplication::translate("GameListSettingsWidget", "Add", nullptr));
        removeSearchDirectoryButton->setText(QApplication::translate("GameListSettingsWidget", "Remove", nullptr));
        scanForNewGames->setText(QApplication::translate("GameListSettingsWidget", "Scan New", nullptr));
        rescanAllGames->setText(QApplication::translate("GameListSettingsWidget", "Rescan All", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GameListSettingsWidget: public Ui_GameListSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMELISTSETTINGSWIDGET_H
