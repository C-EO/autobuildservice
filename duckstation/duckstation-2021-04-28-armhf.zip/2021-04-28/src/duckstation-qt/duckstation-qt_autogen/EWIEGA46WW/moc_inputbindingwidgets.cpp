/****************************************************************************
** Meta object code from reading C++ file 'inputbindingwidgets.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "duckstation-qt/inputbindingwidgets.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'inputbindingwidgets.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_InputBindingWidget_t {
    QByteArrayData data[18];
    char stringdata0[275];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputBindingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputBindingWidget_t qt_meta_stringdata_InputBindingWidget = {
    {
QT_MOC_LITERAL(0, 0, 18), // "InputBindingWidget"
QT_MOC_LITERAL(1, 19, 20), // "bindToControllerAxis"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 16), // "controller_index"
QT_MOC_LITERAL(4, 58, 10), // "axis_index"
QT_MOC_LITERAL(5, 69, 8), // "inverted"
QT_MOC_LITERAL(6, 78, 19), // "std::optional<bool>"
QT_MOC_LITERAL(7, 98, 18), // "half_axis_positive"
QT_MOC_LITERAL(8, 117, 22), // "bindToControllerButton"
QT_MOC_LITERAL(9, 140, 12), // "button_index"
QT_MOC_LITERAL(10, 153, 19), // "bindToControllerHat"
QT_MOC_LITERAL(11, 173, 9), // "hat_index"
QT_MOC_LITERAL(12, 183, 13), // "hat_direction"
QT_MOC_LITERAL(13, 197, 14), // "beginRebindAll"
QT_MOC_LITERAL(14, 212, 12), // "clearBinding"
QT_MOC_LITERAL(15, 225, 13), // "reloadBinding"
QT_MOC_LITERAL(16, 239, 9), // "onClicked"
QT_MOC_LITERAL(17, 249, 25) // "onInputListenTimerTimeout"

    },
    "InputBindingWidget\0bindToControllerAxis\0"
    "\0controller_index\0axis_index\0inverted\0"
    "std::optional<bool>\0half_axis_positive\0"
    "bindToControllerButton\0button_index\0"
    "bindToControllerHat\0hat_index\0"
    "hat_direction\0beginRebindAll\0clearBinding\0"
    "reloadBinding\0onClicked\0"
    "onInputListenTimerTimeout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputBindingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    4,   54,    2, 0x0a /* Public */,
       8,    2,   63,    2, 0x0a /* Public */,
      10,    3,   68,    2, 0x0a /* Public */,
      13,    0,   75,    2, 0x0a /* Public */,
      14,    0,   76,    2, 0x0a /* Public */,
      15,    0,   77,    2, 0x0a /* Public */,
      16,    0,   78,    2, 0x09 /* Protected */,
      17,    0,   79,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Bool, 0x80000000 | 6,    3,    4,    5,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    9,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    3,   11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void InputBindingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InputBindingWidget *_t = static_cast<InputBindingWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->bindToControllerAxis((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< std::optional<bool>(*)>(_a[4]))); break;
        case 1: _t->bindToControllerButton((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->bindToControllerHat((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 3: _t->beginRebindAll(); break;
        case 4: _t->clearBinding(); break;
        case 5: _t->reloadBinding(); break;
        case 6: _t->onClicked(); break;
        case 7: _t->onInputListenTimerTimeout(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject InputBindingWidget::staticMetaObject = {
    { &QPushButton::staticMetaObject, qt_meta_stringdata_InputBindingWidget.data,
      qt_meta_data_InputBindingWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputBindingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputBindingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputBindingWidget.stringdata0))
        return static_cast<void*>(this);
    return QPushButton::qt_metacast(_clname);
}

int InputBindingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPushButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}
struct qt_meta_stringdata_InputButtonBindingWidget_t {
    QByteArrayData data[1];
    char stringdata0[25];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputButtonBindingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputButtonBindingWidget_t qt_meta_stringdata_InputButtonBindingWidget = {
    {
QT_MOC_LITERAL(0, 0, 24) // "InputButtonBindingWidget"

    },
    "InputButtonBindingWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputButtonBindingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InputButtonBindingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject InputButtonBindingWidget::staticMetaObject = {
    { &InputBindingWidget::staticMetaObject, qt_meta_stringdata_InputButtonBindingWidget.data,
      qt_meta_data_InputButtonBindingWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputButtonBindingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputButtonBindingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputButtonBindingWidget.stringdata0))
        return static_cast<void*>(this);
    return InputBindingWidget::qt_metacast(_clname);
}

int InputButtonBindingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InputBindingWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_InputAxisBindingWidget_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputAxisBindingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputAxisBindingWidget_t qt_meta_stringdata_InputAxisBindingWidget = {
    {
QT_MOC_LITERAL(0, 0, 22) // "InputAxisBindingWidget"

    },
    "InputAxisBindingWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputAxisBindingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InputAxisBindingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject InputAxisBindingWidget::staticMetaObject = {
    { &InputBindingWidget::staticMetaObject, qt_meta_stringdata_InputAxisBindingWidget.data,
      qt_meta_data_InputAxisBindingWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputAxisBindingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputAxisBindingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputAxisBindingWidget.stringdata0))
        return static_cast<void*>(this);
    return InputBindingWidget::qt_metacast(_clname);
}

int InputAxisBindingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InputBindingWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_InputRumbleBindingWidget_t {
    QByteArrayData data[4];
    char stringdata0[66];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputRumbleBindingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputRumbleBindingWidget_t qt_meta_stringdata_InputRumbleBindingWidget = {
    {
QT_MOC_LITERAL(0, 0, 24), // "InputRumbleBindingWidget"
QT_MOC_LITERAL(1, 25, 22), // "bindToControllerRumble"
QT_MOC_LITERAL(2, 48, 0), // ""
QT_MOC_LITERAL(3, 49, 16) // "controller_index"

    },
    "InputRumbleBindingWidget\0"
    "bindToControllerRumble\0\0controller_index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputRumbleBindingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   19,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,

       0        // eod
};

void InputRumbleBindingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InputRumbleBindingWidget *_t = static_cast<InputRumbleBindingWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->bindToControllerRumble((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject InputRumbleBindingWidget::staticMetaObject = {
    { &InputBindingWidget::staticMetaObject, qt_meta_stringdata_InputRumbleBindingWidget.data,
      qt_meta_data_InputRumbleBindingWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputRumbleBindingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputRumbleBindingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputRumbleBindingWidget.stringdata0))
        return static_cast<void*>(this);
    return InputBindingWidget::qt_metacast(_clname);
}

int InputRumbleBindingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InputBindingWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
