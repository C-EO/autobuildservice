// f1310bf93a68fb6369330509cd0724c1bd088fbb master 0.1-3894-gf1310bf9 2021-04-28T02:51:44+10:00
const char* g_scm_hash_str = "f1310bf93a68fb6369330509cd0724c1bd088fbb";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3894-gf1310bf9";
const char* g_scm_date_str = "2021-04-28T02:51:44+10:00";

