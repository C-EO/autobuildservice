/* */
#include <windows.h>
#include <mmsystem.h>


int main(void){return 0;}

