// e382df0d41288491f4adb5eb2b5dcbebf9ebc0d2 master 0.1-3935-ge382df0d 2021-05-03T12:43:33+10:00
const char* g_scm_hash_str = "e382df0d41288491f4adb5eb2b5dcbebf9ebc0d2";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3935-ge382df0d";
const char* g_scm_date_str = "2021-05-03T12:43:33+10:00";

