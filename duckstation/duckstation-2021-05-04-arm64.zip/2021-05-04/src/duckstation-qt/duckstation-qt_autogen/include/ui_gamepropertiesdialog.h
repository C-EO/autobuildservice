/********************************************************************************
** Form generated from reading UI file 'gamepropertiesdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMEPROPERTIESDIALOG_H
#define UI_GAMEPROPERTIESDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GamePropertiesDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QFormLayout *formLayout_2;
    QLabel *label_4;
    QLineEdit *imagePath;
    QLabel *label;
    QLineEdit *gameCode;
    QLabel *label_2;
    QLineEdit *title;
    QLabel *label_3;
    QComboBox *region;
    QLabel *label_7;
    QComboBox *compatibility;
    QLabel *label_6;
    QLineEdit *upscalingIssues;
    QLabel *label_5;
    QLineEdit *comments;
    QLabel *label_9;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *versionTested;
    QPushButton *setToCurrent;
    QLabel *label_8;
    QTableWidget *tracks;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout_3;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *userEnableCPUClockSpeedControl;
    QSpacerItem *horizontalSpacer_2;
    QLabel *userCPUClockSpeedLabel;
    QSlider *userCPUClockSpeed;
    QGroupBox *groupBox_4;
    QFormLayout *formLayout_5;
    QLabel *label_18;
    QHBoxLayout *horizontalLayout_8;
    QComboBox *userAspectRatio;
    QSpinBox *userCustomAspectRatioNumerator;
    QLabel *userCustomAspectRatioSeparator;
    QSpinBox *userCustomAspectRatioDenominator;
    QLabel *label_17;
    QComboBox *userCropMode;
    QLabel *label_31;
    QComboBox *userDownsampleMode;
    QGridLayout *gridLayout_2;
    QCheckBox *userLinearUpscaling;
    QCheckBox *userIntegerUpscaling;
    QGroupBox *groupBox_5;
    QFormLayout *formLayout_6;
    QLabel *label_20;
    QComboBox *userResolutionScale;
    QLabel *label_24;
    QComboBox *userMSAAMode;
    QLabel *label_23;
    QComboBox *userTextureFiltering;
    QGridLayout *gridLayout;
    QCheckBox *userScaledDithering;
    QCheckBox *userForce43For24Bit;
    QCheckBox *userForceNTSCTimings;
    QCheckBox *userTrueColor;
    QCheckBox *userPGXP;
    QCheckBox *userWidescreenHack;
    QCheckBox *userPGXPProjectionPrecision;
    QCheckBox *userPGXPDepthBuffer;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_4;
    QLabel *label_13;
    QComboBox *userCDROMReadSpeedup;
    QLabel *label_32;
    QComboBox *userRunaheadFrames;
    QSpacerItem *verticalSpacer_3;
    QWidget *tab_4;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox_3;
    QFormLayout *formLayout_4;
    QLabel *label_15;
    QComboBox *userControllerType1;
    QLabel *label_16;
    QComboBox *userControllerType2;
    QLabel *label_19;
    QComboBox *userInputProfile;
    QLabel *label_33;
    QComboBox *userMultitapMode;
    QGroupBox *groupBox_6;
    QFormLayout *formLayout_3;
    QLabel *label_21;
    QComboBox *userMemoryCard1Type;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *userMemoryCard1SharedPath;
    QPushButton *userMemoryCard1SharedPathBrowse;
    QLabel *label_22;
    QComboBox *userMemoryCard2Type;
    QLabel *label_12;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *userMemoryCard2SharedPath;
    QPushButton *userMemoryCard2SharedPathBrowse;
    QSpacerItem *verticalSpacer_2;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *compatibilityTraits;
    QGroupBox *compatibilityOverrides;
    QFormLayout *formLayout;
    QLabel *label_10;
    QHBoxLayout *horizontalLayout;
    QSpinBox *displayActiveStartOffset;
    QSpinBox *displayActiveEndOffset;
    QLabel *label_29;
    QHBoxLayout *horizontalLayout_7;
    QSpinBox *displayLineStartOffset;
    QSpinBox *displayLineEndOffset;
    QLabel *label_14;
    QSpinBox *dmaMaxSliceTicks;
    QLabel *label_25;
    QSpinBox *dmaHaltTicks;
    QLabel *label_26;
    QSpinBox *gpuFIFOSize;
    QLabel *label_27;
    QSpinBox *gpuMaxRunAhead;
    QLabel *label_28;
    QDoubleSpinBox *gpuPGXPTolerance;
    QLabel *label_30;
    QDoubleSpinBox *gpuPGXPDepthThreshold;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *computeHashes;
    QPushButton *verifyDump;
    QPushButton *exportCompatibilityInfo;
    QPushButton *close;

    void setupUi(QDialog *GamePropertiesDialog)
    {
        if (GamePropertiesDialog->objectName().isEmpty())
            GamePropertiesDialog->setObjectName(QStringLiteral("GamePropertiesDialog"));
        GamePropertiesDialog->resize(793, 651);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/duck.png"), QSize(), QIcon::Normal, QIcon::Off);
        GamePropertiesDialog->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(GamePropertiesDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        tabWidget = new QTabWidget(GamePropertiesDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        formLayout_2 = new QFormLayout(tab);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_4 = new QLabel(tab);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_4);

        imagePath = new QLineEdit(tab);
        imagePath->setObjectName(QStringLiteral("imagePath"));
        imagePath->setReadOnly(true);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, imagePath);

        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label);

        gameCode = new QLineEdit(tab);
        gameCode->setObjectName(QStringLiteral("gameCode"));
        gameCode->setReadOnly(true);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, gameCode);

        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_2);

        title = new QLineEdit(tab);
        title->setObjectName(QStringLiteral("title"));
        title->setReadOnly(true);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, title);

        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_3);

        region = new QComboBox(tab);
        region->setObjectName(QStringLiteral("region"));
        region->setEnabled(false);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, region);

        label_7 = new QLabel(tab);
        label_7->setObjectName(QStringLiteral("label_7"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, label_7);

        compatibility = new QComboBox(tab);
        compatibility->setObjectName(QStringLiteral("compatibility"));

        formLayout_2->setWidget(4, QFormLayout::FieldRole, compatibility);

        label_6 = new QLabel(tab);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout_2->setWidget(5, QFormLayout::LabelRole, label_6);

        upscalingIssues = new QLineEdit(tab);
        upscalingIssues->setObjectName(QStringLiteral("upscalingIssues"));

        formLayout_2->setWidget(5, QFormLayout::FieldRole, upscalingIssues);

        label_5 = new QLabel(tab);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout_2->setWidget(6, QFormLayout::LabelRole, label_5);

        comments = new QLineEdit(tab);
        comments->setObjectName(QStringLiteral("comments"));

        formLayout_2->setWidget(6, QFormLayout::FieldRole, comments);

        label_9 = new QLabel(tab);
        label_9->setObjectName(QStringLiteral("label_9"));

        formLayout_2->setWidget(7, QFormLayout::LabelRole, label_9);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        versionTested = new QLineEdit(tab);
        versionTested->setObjectName(QStringLiteral("versionTested"));

        horizontalLayout_3->addWidget(versionTested);

        setToCurrent = new QPushButton(tab);
        setToCurrent->setObjectName(QStringLiteral("setToCurrent"));

        horizontalLayout_3->addWidget(setToCurrent);


        formLayout_2->setLayout(7, QFormLayout::FieldRole, horizontalLayout_3);

        label_8 = new QLabel(tab);
        label_8->setObjectName(QStringLiteral("label_8"));

        formLayout_2->setWidget(8, QFormLayout::SpanningRole, label_8);

        tracks = new QTableWidget(tab);
        if (tracks->columnCount() < 5)
            tracks->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tracks->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tracks->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tracks->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tracks->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tracks->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        tracks->setObjectName(QStringLiteral("tracks"));
        tracks->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tracks->setCornerButtonEnabled(false);
        tracks->verticalHeader()->setVisible(false);

        formLayout_2->setWidget(9, QFormLayout::SpanningRole, tracks);

        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        verticalLayout_3 = new QVBoxLayout(tab_3);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        groupBox_7 = new QGroupBox(tab_3);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        gridLayout_3 = new QGridLayout(groupBox_7);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        userEnableCPUClockSpeedControl = new QCheckBox(groupBox_7);
        userEnableCPUClockSpeedControl->setObjectName(QStringLiteral("userEnableCPUClockSpeedControl"));
        userEnableCPUClockSpeedControl->setTristate(true);

        horizontalLayout_4->addWidget(userEnableCPUClockSpeedControl);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        userCPUClockSpeedLabel = new QLabel(groupBox_7);
        userCPUClockSpeedLabel->setObjectName(QStringLiteral("userCPUClockSpeedLabel"));
        userCPUClockSpeedLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(userCPUClockSpeedLabel);


        gridLayout_3->addLayout(horizontalLayout_4, 0, 0, 1, 1);

        userCPUClockSpeed = new QSlider(groupBox_7);
        userCPUClockSpeed->setObjectName(QStringLiteral("userCPUClockSpeed"));
        userCPUClockSpeed->setMinimum(10);
        userCPUClockSpeed->setMaximum(1000);
        userCPUClockSpeed->setValue(100);
        userCPUClockSpeed->setOrientation(Qt::Horizontal);
        userCPUClockSpeed->setTickPosition(QSlider::TicksBothSides);
        userCPUClockSpeed->setTickInterval(50);

        gridLayout_3->addWidget(userCPUClockSpeed, 1, 0, 1, 1);


        verticalLayout_3->addWidget(groupBox_7);

        groupBox_4 = new QGroupBox(tab_3);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        formLayout_5 = new QFormLayout(groupBox_4);
        formLayout_5->setObjectName(QStringLiteral("formLayout_5"));
        label_18 = new QLabel(groupBox_4);
        label_18->setObjectName(QStringLiteral("label_18"));

        formLayout_5->setWidget(0, QFormLayout::LabelRole, label_18);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        userAspectRatio = new QComboBox(groupBox_4);
        userAspectRatio->setObjectName(QStringLiteral("userAspectRatio"));

        horizontalLayout_8->addWidget(userAspectRatio);

        userCustomAspectRatioNumerator = new QSpinBox(groupBox_4);
        userCustomAspectRatioNumerator->setObjectName(QStringLiteral("userCustomAspectRatioNumerator"));
        userCustomAspectRatioNumerator->setMinimum(0);
        userCustomAspectRatioNumerator->setMaximum(9999);

        horizontalLayout_8->addWidget(userCustomAspectRatioNumerator);

        userCustomAspectRatioSeparator = new QLabel(groupBox_4);
        userCustomAspectRatioSeparator->setObjectName(QStringLiteral("userCustomAspectRatioSeparator"));

        horizontalLayout_8->addWidget(userCustomAspectRatioSeparator);

        userCustomAspectRatioDenominator = new QSpinBox(groupBox_4);
        userCustomAspectRatioDenominator->setObjectName(QStringLiteral("userCustomAspectRatioDenominator"));
        userCustomAspectRatioDenominator->setMinimum(0);
        userCustomAspectRatioDenominator->setMaximum(9999);

        horizontalLayout_8->addWidget(userCustomAspectRatioDenominator);

        horizontalLayout_8->setStretch(0, 1);

        formLayout_5->setLayout(0, QFormLayout::FieldRole, horizontalLayout_8);

        label_17 = new QLabel(groupBox_4);
        label_17->setObjectName(QStringLiteral("label_17"));

        formLayout_5->setWidget(1, QFormLayout::LabelRole, label_17);

        userCropMode = new QComboBox(groupBox_4);
        userCropMode->setObjectName(QStringLiteral("userCropMode"));

        formLayout_5->setWidget(1, QFormLayout::FieldRole, userCropMode);

        label_31 = new QLabel(groupBox_4);
        label_31->setObjectName(QStringLiteral("label_31"));

        formLayout_5->setWidget(2, QFormLayout::LabelRole, label_31);

        userDownsampleMode = new QComboBox(groupBox_4);
        userDownsampleMode->setObjectName(QStringLiteral("userDownsampleMode"));

        formLayout_5->setWidget(2, QFormLayout::FieldRole, userDownsampleMode);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        userLinearUpscaling = new QCheckBox(groupBox_4);
        userLinearUpscaling->setObjectName(QStringLiteral("userLinearUpscaling"));
        userLinearUpscaling->setTristate(true);

        gridLayout_2->addWidget(userLinearUpscaling, 0, 0, 1, 1);

        userIntegerUpscaling = new QCheckBox(groupBox_4);
        userIntegerUpscaling->setObjectName(QStringLiteral("userIntegerUpscaling"));
        userIntegerUpscaling->setTristate(true);

        gridLayout_2->addWidget(userIntegerUpscaling, 0, 1, 1, 1);


        formLayout_5->setLayout(3, QFormLayout::SpanningRole, gridLayout_2);


        verticalLayout_3->addWidget(groupBox_4);

        groupBox_5 = new QGroupBox(tab_3);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        formLayout_6 = new QFormLayout(groupBox_5);
        formLayout_6->setObjectName(QStringLiteral("formLayout_6"));
        label_20 = new QLabel(groupBox_5);
        label_20->setObjectName(QStringLiteral("label_20"));

        formLayout_6->setWidget(0, QFormLayout::LabelRole, label_20);

        userResolutionScale = new QComboBox(groupBox_5);
        userResolutionScale->setObjectName(QStringLiteral("userResolutionScale"));

        formLayout_6->setWidget(0, QFormLayout::FieldRole, userResolutionScale);

        label_24 = new QLabel(groupBox_5);
        label_24->setObjectName(QStringLiteral("label_24"));

        formLayout_6->setWidget(1, QFormLayout::LabelRole, label_24);

        userMSAAMode = new QComboBox(groupBox_5);
        userMSAAMode->setObjectName(QStringLiteral("userMSAAMode"));

        formLayout_6->setWidget(1, QFormLayout::FieldRole, userMSAAMode);

        label_23 = new QLabel(groupBox_5);
        label_23->setObjectName(QStringLiteral("label_23"));

        formLayout_6->setWidget(2, QFormLayout::LabelRole, label_23);

        userTextureFiltering = new QComboBox(groupBox_5);
        userTextureFiltering->setObjectName(QStringLiteral("userTextureFiltering"));

        formLayout_6->setWidget(2, QFormLayout::FieldRole, userTextureFiltering);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        userScaledDithering = new QCheckBox(groupBox_5);
        userScaledDithering->setObjectName(QStringLiteral("userScaledDithering"));
        userScaledDithering->setTristate(true);

        gridLayout->addWidget(userScaledDithering, 0, 1, 1, 1);

        userForce43For24Bit = new QCheckBox(groupBox_5);
        userForce43For24Bit->setObjectName(QStringLiteral("userForce43For24Bit"));
        userForce43For24Bit->setTristate(true);

        gridLayout->addWidget(userForce43For24Bit, 2, 0, 1, 1);

        userForceNTSCTimings = new QCheckBox(groupBox_5);
        userForceNTSCTimings->setObjectName(QStringLiteral("userForceNTSCTimings"));
        userForceNTSCTimings->setTristate(true);

        gridLayout->addWidget(userForceNTSCTimings, 1, 1, 1, 1);

        userTrueColor = new QCheckBox(groupBox_5);
        userTrueColor->setObjectName(QStringLiteral("userTrueColor"));
        userTrueColor->setTristate(true);

        gridLayout->addWidget(userTrueColor, 0, 0, 1, 1);

        userPGXP = new QCheckBox(groupBox_5);
        userPGXP->setObjectName(QStringLiteral("userPGXP"));
        userPGXP->setTristate(true);

        gridLayout->addWidget(userPGXP, 2, 1, 1, 1);

        userWidescreenHack = new QCheckBox(groupBox_5);
        userWidescreenHack->setObjectName(QStringLiteral("userWidescreenHack"));
        userWidescreenHack->setTristate(true);

        gridLayout->addWidget(userWidescreenHack, 1, 0, 1, 1);

        userPGXPProjectionPrecision = new QCheckBox(groupBox_5);
        userPGXPProjectionPrecision->setObjectName(QStringLiteral("userPGXPProjectionPrecision"));
        userPGXPProjectionPrecision->setTristate(true);

        gridLayout->addWidget(userPGXPProjectionPrecision, 3, 0, 1, 1);

        userPGXPDepthBuffer = new QCheckBox(groupBox_5);
        userPGXPDepthBuffer->setObjectName(QStringLiteral("userPGXPDepthBuffer"));
        userPGXPDepthBuffer->setTristate(true);

        gridLayout->addWidget(userPGXPDepthBuffer, 3, 1, 1, 1);


        formLayout_6->setLayout(3, QFormLayout::SpanningRole, gridLayout);


        verticalLayout_3->addWidget(groupBox_5);

        groupBox = new QGroupBox(tab_3);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_4 = new QGridLayout(groupBox);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_4->addWidget(label_13, 0, 0, 1, 1);

        userCDROMReadSpeedup = new QComboBox(groupBox);
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->addItem(QString());
        userCDROMReadSpeedup->setObjectName(QStringLiteral("userCDROMReadSpeedup"));

        gridLayout_4->addWidget(userCDROMReadSpeedup, 0, 1, 1, 1);

        label_32 = new QLabel(groupBox);
        label_32->setObjectName(QStringLiteral("label_32"));

        gridLayout_4->addWidget(label_32, 1, 0, 1, 1);

        userRunaheadFrames = new QComboBox(groupBox);
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->addItem(QString());
        userRunaheadFrames->setObjectName(QStringLiteral("userRunaheadFrames"));

        gridLayout_4->addWidget(userRunaheadFrames, 1, 1, 1, 1);


        verticalLayout_3->addWidget(groupBox);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_3);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        verticalLayout_4 = new QVBoxLayout(tab_4);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        groupBox_3 = new QGroupBox(tab_4);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        formLayout_4 = new QFormLayout(groupBox_3);
        formLayout_4->setObjectName(QStringLiteral("formLayout_4"));
        label_15 = new QLabel(groupBox_3);
        label_15->setObjectName(QStringLiteral("label_15"));

        formLayout_4->setWidget(1, QFormLayout::LabelRole, label_15);

        userControllerType1 = new QComboBox(groupBox_3);
        userControllerType1->setObjectName(QStringLiteral("userControllerType1"));

        formLayout_4->setWidget(1, QFormLayout::FieldRole, userControllerType1);

        label_16 = new QLabel(groupBox_3);
        label_16->setObjectName(QStringLiteral("label_16"));

        formLayout_4->setWidget(2, QFormLayout::LabelRole, label_16);

        userControllerType2 = new QComboBox(groupBox_3);
        userControllerType2->setObjectName(QStringLiteral("userControllerType2"));

        formLayout_4->setWidget(2, QFormLayout::FieldRole, userControllerType2);

        label_19 = new QLabel(groupBox_3);
        label_19->setObjectName(QStringLiteral("label_19"));

        formLayout_4->setWidget(3, QFormLayout::LabelRole, label_19);

        userInputProfile = new QComboBox(groupBox_3);
        userInputProfile->setObjectName(QStringLiteral("userInputProfile"));

        formLayout_4->setWidget(3, QFormLayout::FieldRole, userInputProfile);

        label_33 = new QLabel(groupBox_3);
        label_33->setObjectName(QStringLiteral("label_33"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label_33);

        userMultitapMode = new QComboBox(groupBox_3);
        userMultitapMode->setObjectName(QStringLiteral("userMultitapMode"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, userMultitapMode);


        verticalLayout_4->addWidget(groupBox_3);

        groupBox_6 = new QGroupBox(tab_4);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        formLayout_3 = new QFormLayout(groupBox_6);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_21 = new QLabel(groupBox_6);
        label_21->setObjectName(QStringLiteral("label_21"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_21);

        userMemoryCard1Type = new QComboBox(groupBox_6);
        userMemoryCard1Type->setObjectName(QStringLiteral("userMemoryCard1Type"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, userMemoryCard1Type);

        label_11 = new QLabel(groupBox_6);
        label_11->setObjectName(QStringLiteral("label_11"));

        formLayout_3->setWidget(2, QFormLayout::LabelRole, label_11);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        userMemoryCard1SharedPath = new QLineEdit(groupBox_6);
        userMemoryCard1SharedPath->setObjectName(QStringLiteral("userMemoryCard1SharedPath"));

        horizontalLayout_5->addWidget(userMemoryCard1SharedPath);

        userMemoryCard1SharedPathBrowse = new QPushButton(groupBox_6);
        userMemoryCard1SharedPathBrowse->setObjectName(QStringLiteral("userMemoryCard1SharedPathBrowse"));

        horizontalLayout_5->addWidget(userMemoryCard1SharedPathBrowse);


        formLayout_3->setLayout(2, QFormLayout::FieldRole, horizontalLayout_5);

        label_22 = new QLabel(groupBox_6);
        label_22->setObjectName(QStringLiteral("label_22"));

        formLayout_3->setWidget(4, QFormLayout::LabelRole, label_22);

        userMemoryCard2Type = new QComboBox(groupBox_6);
        userMemoryCard2Type->setObjectName(QStringLiteral("userMemoryCard2Type"));

        formLayout_3->setWidget(4, QFormLayout::FieldRole, userMemoryCard2Type);

        label_12 = new QLabel(groupBox_6);
        label_12->setObjectName(QStringLiteral("label_12"));

        formLayout_3->setWidget(6, QFormLayout::LabelRole, label_12);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        userMemoryCard2SharedPath = new QLineEdit(groupBox_6);
        userMemoryCard2SharedPath->setObjectName(QStringLiteral("userMemoryCard2SharedPath"));

        horizontalLayout_6->addWidget(userMemoryCard2SharedPath);

        userMemoryCard2SharedPathBrowse = new QPushButton(groupBox_6);
        userMemoryCard2SharedPathBrowse->setObjectName(QStringLiteral("userMemoryCard2SharedPathBrowse"));

        horizontalLayout_6->addWidget(userMemoryCard2SharedPathBrowse);


        formLayout_3->setLayout(6, QFormLayout::FieldRole, horizontalLayout_6);


        verticalLayout_4->addWidget(groupBox_6);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);

        tabWidget->addTab(tab_4, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_2 = new QVBoxLayout(tab_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        compatibilityTraits = new QGroupBox(tab_2);
        compatibilityTraits->setObjectName(QStringLiteral("compatibilityTraits"));

        verticalLayout_2->addWidget(compatibilityTraits);

        compatibilityOverrides = new QGroupBox(tab_2);
        compatibilityOverrides->setObjectName(QStringLiteral("compatibilityOverrides"));
        formLayout = new QFormLayout(compatibilityOverrides);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label_10 = new QLabel(compatibilityOverrides);
        label_10->setObjectName(QStringLiteral("label_10"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_10);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        displayActiveStartOffset = new QSpinBox(compatibilityOverrides);
        displayActiveStartOffset->setObjectName(QStringLiteral("displayActiveStartOffset"));
        displayActiveStartOffset->setMinimum(-5000);
        displayActiveStartOffset->setMaximum(5000);
        displayActiveStartOffset->setValue(0);

        horizontalLayout->addWidget(displayActiveStartOffset);

        displayActiveEndOffset = new QSpinBox(compatibilityOverrides);
        displayActiveEndOffset->setObjectName(QStringLiteral("displayActiveEndOffset"));
        displayActiveEndOffset->setMinimum(-5000);
        displayActiveEndOffset->setMaximum(5000);
        displayActiveEndOffset->setValue(0);

        horizontalLayout->addWidget(displayActiveEndOffset);


        formLayout->setLayout(0, QFormLayout::FieldRole, horizontalLayout);

        label_29 = new QLabel(compatibilityOverrides);
        label_29->setObjectName(QStringLiteral("label_29"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_29);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        displayLineStartOffset = new QSpinBox(compatibilityOverrides);
        displayLineStartOffset->setObjectName(QStringLiteral("displayLineStartOffset"));
        displayLineStartOffset->setMinimum(-128);
        displayLineStartOffset->setMaximum(127);
        displayLineStartOffset->setValue(0);

        horizontalLayout_7->addWidget(displayLineStartOffset);

        displayLineEndOffset = new QSpinBox(compatibilityOverrides);
        displayLineEndOffset->setObjectName(QStringLiteral("displayLineEndOffset"));
        displayLineEndOffset->setMinimum(-128);
        displayLineEndOffset->setMaximum(127);
        displayLineEndOffset->setValue(0);

        horizontalLayout_7->addWidget(displayLineEndOffset);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout_7);

        label_14 = new QLabel(compatibilityOverrides);
        label_14->setObjectName(QStringLiteral("label_14"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_14);

        dmaMaxSliceTicks = new QSpinBox(compatibilityOverrides);
        dmaMaxSliceTicks->setObjectName(QStringLiteral("dmaMaxSliceTicks"));
        dmaMaxSliceTicks->setMaximum(10000);
        dmaMaxSliceTicks->setSingleStep(100);

        formLayout->setWidget(2, QFormLayout::FieldRole, dmaMaxSliceTicks);

        label_25 = new QLabel(compatibilityOverrides);
        label_25->setObjectName(QStringLiteral("label_25"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_25);

        dmaHaltTicks = new QSpinBox(compatibilityOverrides);
        dmaHaltTicks->setObjectName(QStringLiteral("dmaHaltTicks"));
        dmaHaltTicks->setMaximum(1000);
        dmaHaltTicks->setSingleStep(10);

        formLayout->setWidget(3, QFormLayout::FieldRole, dmaHaltTicks);

        label_26 = new QLabel(compatibilityOverrides);
        label_26->setObjectName(QStringLiteral("label_26"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_26);

        gpuFIFOSize = new QSpinBox(compatibilityOverrides);
        gpuFIFOSize->setObjectName(QStringLiteral("gpuFIFOSize"));
        gpuFIFOSize->setMaximum(128);

        formLayout->setWidget(4, QFormLayout::FieldRole, gpuFIFOSize);

        label_27 = new QLabel(compatibilityOverrides);
        label_27->setObjectName(QStringLiteral("label_27"));

        formLayout->setWidget(5, QFormLayout::LabelRole, label_27);

        gpuMaxRunAhead = new QSpinBox(compatibilityOverrides);
        gpuMaxRunAhead->setObjectName(QStringLiteral("gpuMaxRunAhead"));
        gpuMaxRunAhead->setMaximum(1000);
        gpuMaxRunAhead->setSingleStep(16);

        formLayout->setWidget(5, QFormLayout::FieldRole, gpuMaxRunAhead);

        label_28 = new QLabel(compatibilityOverrides);
        label_28->setObjectName(QStringLiteral("label_28"));

        formLayout->setWidget(6, QFormLayout::LabelRole, label_28);

        gpuPGXPTolerance = new QDoubleSpinBox(compatibilityOverrides);
        gpuPGXPTolerance->setObjectName(QStringLiteral("gpuPGXPTolerance"));
        gpuPGXPTolerance->setMinimum(-1);
        gpuPGXPTolerance->setMaximum(10);
        gpuPGXPTolerance->setSingleStep(0);
        gpuPGXPTolerance->setValue(-1);

        formLayout->setWidget(6, QFormLayout::FieldRole, gpuPGXPTolerance);

        label_30 = new QLabel(compatibilityOverrides);
        label_30->setObjectName(QStringLiteral("label_30"));

        formLayout->setWidget(7, QFormLayout::LabelRole, label_30);

        gpuPGXPDepthThreshold = new QDoubleSpinBox(compatibilityOverrides);
        gpuPGXPDepthThreshold->setObjectName(QStringLiteral("gpuPGXPDepthThreshold"));
        gpuPGXPDepthThreshold->setMaximum(4096);

        formLayout->setWidget(7, QFormLayout::FieldRole, gpuPGXPDepthThreshold);


        verticalLayout_2->addWidget(compatibilityOverrides);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        computeHashes = new QPushButton(GamePropertiesDialog);
        computeHashes->setObjectName(QStringLiteral("computeHashes"));

        horizontalLayout_2->addWidget(computeHashes);

        verifyDump = new QPushButton(GamePropertiesDialog);
        verifyDump->setObjectName(QStringLiteral("verifyDump"));

        horizontalLayout_2->addWidget(verifyDump);

        exportCompatibilityInfo = new QPushButton(GamePropertiesDialog);
        exportCompatibilityInfo->setObjectName(QStringLiteral("exportCompatibilityInfo"));

        horizontalLayout_2->addWidget(exportCompatibilityInfo);

        close = new QPushButton(GamePropertiesDialog);
        close->setObjectName(QStringLiteral("close"));

        horizontalLayout_2->addWidget(close);


        verticalLayout->addLayout(horizontalLayout_2);


        retranslateUi(GamePropertiesDialog);

        tabWidget->setCurrentIndex(0);
        close->setDefault(true);


        QMetaObject::connectSlotsByName(GamePropertiesDialog);
    } // setupUi

    void retranslateUi(QDialog *GamePropertiesDialog)
    {
        GamePropertiesDialog->setWindowTitle(QApplication::translate("GamePropertiesDialog", "Dialog", nullptr));
        label_4->setText(QApplication::translate("GamePropertiesDialog", "Image Path:", nullptr));
        label->setText(QApplication::translate("GamePropertiesDialog", "Game Code:", nullptr));
        label_2->setText(QApplication::translate("GamePropertiesDialog", "Title:", nullptr));
        label_3->setText(QApplication::translate("GamePropertiesDialog", "Region:", nullptr));
        label_7->setText(QApplication::translate("GamePropertiesDialog", "Compatibility:", nullptr));
        label_6->setText(QApplication::translate("GamePropertiesDialog", "Upscaling Issues:", nullptr));
        label_5->setText(QApplication::translate("GamePropertiesDialog", "Comments:", nullptr));
        label_9->setText(QApplication::translate("GamePropertiesDialog", "Version Tested:", nullptr));
        setToCurrent->setText(QApplication::translate("GamePropertiesDialog", "Set to Current", nullptr));
        label_8->setText(QApplication::translate("GamePropertiesDialog", "Tracks:", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tracks->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("GamePropertiesDialog", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tracks->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("GamePropertiesDialog", "Mode", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tracks->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("GamePropertiesDialog", "Start", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tracks->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("GamePropertiesDialog", "Length", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tracks->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("GamePropertiesDialog", "Hash", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("GamePropertiesDialog", "Properties", nullptr));
        groupBox_7->setTitle(QApplication::translate("GamePropertiesDialog", "CPU Clock Speed Control", nullptr));
        userEnableCPUClockSpeedControl->setText(QApplication::translate("GamePropertiesDialog", "Enable Clock Speed Control (Overclocking/Underclocking)", nullptr));
        userCPUClockSpeedLabel->setText(QApplication::translate("GamePropertiesDialog", "100% (effective 33.3mhz)", nullptr));
        groupBox_4->setTitle(QApplication::translate("GamePropertiesDialog", "GPU Screen Display", nullptr));
        label_18->setText(QApplication::translate("GamePropertiesDialog", "Aspect Ratio:", nullptr));
        userCustomAspectRatioSeparator->setText(QApplication::translate("GamePropertiesDialog", ":", nullptr));
        label_17->setText(QApplication::translate("GamePropertiesDialog", "Crop Mode:", nullptr));
        label_31->setText(QApplication::translate("GamePropertiesDialog", "Downsampling:", nullptr));
        userLinearUpscaling->setText(QApplication::translate("GamePropertiesDialog", "Linear Upscaling", nullptr));
        userIntegerUpscaling->setText(QApplication::translate("GamePropertiesDialog", "Integer Upscaling", nullptr));
        groupBox_5->setTitle(QApplication::translate("GamePropertiesDialog", "GPU Enhancements", nullptr));
        label_20->setText(QApplication::translate("GamePropertiesDialog", "Resolution Scale:", nullptr));
        label_24->setText(QApplication::translate("GamePropertiesDialog", "Multisample Antialiasing:", nullptr));
        label_23->setText(QApplication::translate("GamePropertiesDialog", "Texture Filtering:", nullptr));
        userScaledDithering->setText(QApplication::translate("GamePropertiesDialog", "Scaled Dithering (scale dither pattern to resolution)", nullptr));
        userForce43For24Bit->setText(QApplication::translate("GamePropertiesDialog", "Force 4:3 For 24-Bit Display (disable widescreen for FMVs)", nullptr));
        userForceNTSCTimings->setText(QApplication::translate("GamePropertiesDialog", "Force NTSC Timings (60hz-on-PAL)", nullptr));
        userTrueColor->setText(QApplication::translate("GamePropertiesDialog", "True Color Rendering (24-bit, disables dithering)", nullptr));
        userPGXP->setText(QApplication::translate("GamePropertiesDialog", "PGXP Geometry Correction", nullptr));
        userWidescreenHack->setText(QApplication::translate("GamePropertiesDialog", "Widescreen Hack", nullptr));
        userPGXPProjectionPrecision->setText(QApplication::translate("GamePropertiesDialog", "PGXP Preserve Projection Precision", nullptr));
        userPGXPDepthBuffer->setText(QApplication::translate("GamePropertiesDialog", "PGXP Depth Buffer", nullptr));
        groupBox->setTitle(QApplication::translate("GamePropertiesDialog", "Other Settings", nullptr));
        label_13->setText(QApplication::translate("GamePropertiesDialog", "CD-ROM Read Speedup:", nullptr));
        userCDROMReadSpeedup->setItemText(0, QApplication::translate("GamePropertiesDialog", "(unchanged)", nullptr));
        userCDROMReadSpeedup->setItemText(1, QApplication::translate("GamePropertiesDialog", "None (Double Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(2, QApplication::translate("GamePropertiesDialog", "2x (Quad Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(3, QApplication::translate("GamePropertiesDialog", "3x (6x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(4, QApplication::translate("GamePropertiesDialog", "4x (8x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(5, QApplication::translate("GamePropertiesDialog", "5x (10x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(6, QApplication::translate("GamePropertiesDialog", "6x (12x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(7, QApplication::translate("GamePropertiesDialog", "7x (14x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(8, QApplication::translate("GamePropertiesDialog", "8x (16x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(9, QApplication::translate("GamePropertiesDialog", "9x (18x Speed)", nullptr));
        userCDROMReadSpeedup->setItemText(10, QApplication::translate("GamePropertiesDialog", "10x (20x Speed)", nullptr));

        label_32->setText(QApplication::translate("GamePropertiesDialog", "Runahead Frames:", nullptr));
        userRunaheadFrames->setItemText(0, QApplication::translate("GamePropertiesDialog", "(unchanged)", nullptr));
        userRunaheadFrames->setItemText(1, QApplication::translate("GamePropertiesDialog", "Disabled", nullptr));
        userRunaheadFrames->setItemText(2, QApplication::translate("GamePropertiesDialog", "1 Frame", nullptr));
        userRunaheadFrames->setItemText(3, QApplication::translate("GamePropertiesDialog", "2 Frames", nullptr));
        userRunaheadFrames->setItemText(4, QApplication::translate("GamePropertiesDialog", "3 Frames", nullptr));
        userRunaheadFrames->setItemText(5, QApplication::translate("GamePropertiesDialog", "4 Frames", nullptr));
        userRunaheadFrames->setItemText(6, QApplication::translate("GamePropertiesDialog", "5 Frames", nullptr));
        userRunaheadFrames->setItemText(7, QApplication::translate("GamePropertiesDialog", "6 Frames", nullptr));
        userRunaheadFrames->setItemText(8, QApplication::translate("GamePropertiesDialog", "7 Frames", nullptr));
        userRunaheadFrames->setItemText(9, QApplication::translate("GamePropertiesDialog", "8 Frames", nullptr));
        userRunaheadFrames->setItemText(10, QApplication::translate("GamePropertiesDialog", "9 Frames", nullptr));
        userRunaheadFrames->setItemText(11, QApplication::translate("GamePropertiesDialog", "10 Frames", nullptr));

        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("GamePropertiesDialog", "User Settings (Console)", nullptr));
        groupBox_3->setTitle(QApplication::translate("GamePropertiesDialog", "Controller Settings", nullptr));
        label_15->setText(QApplication::translate("GamePropertiesDialog", "Controller 1 Type:", nullptr));
        label_16->setText(QApplication::translate("GamePropertiesDialog", "Controller 2 Type:", nullptr));
        label_19->setText(QApplication::translate("GamePropertiesDialog", "Input Profile For Bindings:", nullptr));
        label_33->setText(QApplication::translate("GamePropertiesDialog", "Multitap Mode:", nullptr));
        groupBox_6->setTitle(QApplication::translate("GamePropertiesDialog", "Memory Card Settings", nullptr));
        label_21->setText(QApplication::translate("GamePropertiesDialog", "Memory Card 1 Type:", nullptr));
        label_11->setText(QApplication::translate("GamePropertiesDialog", "Memory Card 1 Shared Path:", nullptr));
        userMemoryCard1SharedPathBrowse->setText(QApplication::translate("GamePropertiesDialog", "Browse...", nullptr));
        label_22->setText(QApplication::translate("GamePropertiesDialog", "Memory Card 2 Type:", nullptr));
        label_12->setText(QApplication::translate("GamePropertiesDialog", "Memory Card 2 Shared Path:", nullptr));
        userMemoryCard2SharedPathBrowse->setText(QApplication::translate("GamePropertiesDialog", "Browse...", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("GamePropertiesDialog", "User Settings (Input)", nullptr));
        compatibilityTraits->setTitle(QApplication::translate("GamePropertiesDialog", "Traits", nullptr));
        compatibilityOverrides->setTitle(QApplication::translate("GamePropertiesDialog", "Overrides", nullptr));
        label_10->setText(QApplication::translate("GamePropertiesDialog", "Display Active Offset:", nullptr));
        label_29->setText(QApplication::translate("GamePropertiesDialog", "Display Line Offset:", nullptr));
        label_14->setText(QApplication::translate("GamePropertiesDialog", "DMA Max Slice Ticks:", nullptr));
        label_25->setText(QApplication::translate("GamePropertiesDialog", "DMA Halt Ticks:", nullptr));
        label_26->setText(QApplication::translate("GamePropertiesDialog", "GPU FIFO Size:", nullptr));
        label_27->setText(QApplication::translate("GamePropertiesDialog", "GPU Max Run Ahead:", nullptr));
        label_28->setText(QApplication::translate("GamePropertiesDialog", "PGXP Geometry Tolerance:", nullptr));
        label_30->setText(QApplication::translate("GamePropertiesDialog", "PGXP Depth Threshold:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("GamePropertiesDialog", "Compatibility Settings", nullptr));
        computeHashes->setText(QApplication::translate("GamePropertiesDialog", "Compute Hashes", nullptr));
        verifyDump->setText(QApplication::translate("GamePropertiesDialog", "Verify Dump", nullptr));
        exportCompatibilityInfo->setText(QApplication::translate("GamePropertiesDialog", "Export Compatibility Info", nullptr));
        close->setText(QApplication::translate("GamePropertiesDialog", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GamePropertiesDialog: public Ui_GamePropertiesDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMEPROPERTIESDIALOG_H
