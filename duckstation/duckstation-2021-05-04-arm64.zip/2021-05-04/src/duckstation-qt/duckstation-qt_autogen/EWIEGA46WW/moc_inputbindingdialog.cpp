/****************************************************************************
** Meta object code from reading C++ file 'inputbindingdialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "duckstation-qt/inputbindingdialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'inputbindingdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_InputBindingDialog_t {
    QByteArrayData data[17];
    char stringdata0[307];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputBindingDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputBindingDialog_t qt_meta_stringdata_InputBindingDialog = {
    {
QT_MOC_LITERAL(0, 0, 18), // "InputBindingDialog"
QT_MOC_LITERAL(1, 19, 20), // "bindToControllerAxis"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 16), // "controller_index"
QT_MOC_LITERAL(4, 58, 10), // "axis_index"
QT_MOC_LITERAL(5, 69, 8), // "inverted"
QT_MOC_LITERAL(6, 78, 19), // "std::optional<bool>"
QT_MOC_LITERAL(7, 98, 18), // "half_axis_positive"
QT_MOC_LITERAL(8, 117, 22), // "bindToControllerButton"
QT_MOC_LITERAL(9, 140, 12), // "button_index"
QT_MOC_LITERAL(10, 153, 19), // "bindToControllerHat"
QT_MOC_LITERAL(11, 173, 9), // "hat_index"
QT_MOC_LITERAL(12, 183, 13), // "hat_direction"
QT_MOC_LITERAL(13, 197, 25), // "onAddBindingButtonClicked"
QT_MOC_LITERAL(14, 223, 28), // "onRemoveBindingButtonClicked"
QT_MOC_LITERAL(15, 252, 28), // "onClearBindingsButtonClicked"
QT_MOC_LITERAL(16, 281, 25) // "onInputListenTimerTimeout"

    },
    "InputBindingDialog\0bindToControllerAxis\0"
    "\0controller_index\0axis_index\0inverted\0"
    "std::optional<bool>\0half_axis_positive\0"
    "bindToControllerButton\0button_index\0"
    "bindToControllerHat\0hat_index\0"
    "hat_direction\0onAddBindingButtonClicked\0"
    "onRemoveBindingButtonClicked\0"
    "onClearBindingsButtonClicked\0"
    "onInputListenTimerTimeout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputBindingDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    4,   49,    2, 0x09 /* Protected */,
       8,    2,   58,    2, 0x09 /* Protected */,
      10,    3,   63,    2, 0x09 /* Protected */,
      13,    0,   70,    2, 0x09 /* Protected */,
      14,    0,   71,    2, 0x09 /* Protected */,
      15,    0,   72,    2, 0x09 /* Protected */,
      16,    0,   73,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Bool, 0x80000000 | 6,    3,    4,    5,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    9,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    3,   11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void InputBindingDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InputBindingDialog *_t = static_cast<InputBindingDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->bindToControllerAxis((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< std::optional<bool>(*)>(_a[4]))); break;
        case 1: _t->bindToControllerButton((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->bindToControllerHat((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 3: _t->onAddBindingButtonClicked(); break;
        case 4: _t->onRemoveBindingButtonClicked(); break;
        case 5: _t->onClearBindingsButtonClicked(); break;
        case 6: _t->onInputListenTimerTimeout(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject InputBindingDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_InputBindingDialog.data,
      qt_meta_data_InputBindingDialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputBindingDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputBindingDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputBindingDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int InputBindingDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
struct qt_meta_stringdata_InputButtonBindingDialog_t {
    QByteArrayData data[1];
    char stringdata0[25];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputButtonBindingDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputButtonBindingDialog_t qt_meta_stringdata_InputButtonBindingDialog = {
    {
QT_MOC_LITERAL(0, 0, 24) // "InputButtonBindingDialog"

    },
    "InputButtonBindingDialog"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputButtonBindingDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InputButtonBindingDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject InputButtonBindingDialog::staticMetaObject = {
    { &InputBindingDialog::staticMetaObject, qt_meta_stringdata_InputButtonBindingDialog.data,
      qt_meta_data_InputButtonBindingDialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputButtonBindingDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputButtonBindingDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputButtonBindingDialog.stringdata0))
        return static_cast<void*>(this);
    return InputBindingDialog::qt_metacast(_clname);
}

int InputButtonBindingDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InputBindingDialog::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_InputAxisBindingDialog_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InputAxisBindingDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InputAxisBindingDialog_t qt_meta_stringdata_InputAxisBindingDialog = {
    {
QT_MOC_LITERAL(0, 0, 22) // "InputAxisBindingDialog"

    },
    "InputAxisBindingDialog"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InputAxisBindingDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InputAxisBindingDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject InputAxisBindingDialog::staticMetaObject = {
    { &InputBindingDialog::staticMetaObject, qt_meta_stringdata_InputAxisBindingDialog.data,
      qt_meta_data_InputAxisBindingDialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *InputAxisBindingDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InputAxisBindingDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InputAxisBindingDialog.stringdata0))
        return static_cast<void*>(this);
    return InputBindingDialog::qt_metacast(_clname);
}

int InputAxisBindingDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InputBindingDialog::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
