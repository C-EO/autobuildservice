// 844c8e916f8ea8ffda53376d87f80020fb9fecda master 0.1-3877-g844c8e91 2021-04-24T16:25:35+10:00
const char* g_scm_hash_str = "844c8e916f8ea8ffda53376d87f80020fb9fecda";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3877-g844c8e91";
const char* g_scm_date_str = "2021-04-24T16:25:35+10:00";

