/********************************************************************************
** Form generated from reading UI file 'aboutdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUTDIALOG_H
#define UI_ABOUTDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AboutDialog
{
public:
    QHBoxLayout *horizontalLayout;
    QWidget *iconWidget;
    QVBoxLayout *iconLayout;
    QLabel *icon;
    QSpacerItem *iconSpacer;
    QVBoxLayout *textLayout;
    QLabel *title;
    QLabel *scmversion;
    QLabel *description;

    void setupUi(QDialog *AboutDialog)
    {
        if (AboutDialog->objectName().isEmpty())
            AboutDialog->setObjectName(QStringLiteral("AboutDialog"));
        AboutDialog->resize(600, 320);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/duck.png"), QSize(), QIcon::Normal, QIcon::Off);
        AboutDialog->setWindowIcon(icon1);
        horizontalLayout = new QHBoxLayout(AboutDialog);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        iconWidget = new QWidget(AboutDialog);
        iconWidget->setObjectName(QStringLiteral("iconWidget"));
        iconLayout = new QVBoxLayout(iconWidget);
        iconLayout->setObjectName(QStringLiteral("iconLayout"));
        iconLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        iconLayout->setContentsMargins(1, 1, 1, 1);
        icon = new QLabel(iconWidget);
        icon->setObjectName(QStringLiteral("icon"));
        icon->setMaximumSize(QSize(260, 260));
        icon->setPixmap(QPixmap(QString::fromUtf8(":/icons/duck.png")));
        icon->setAlignment(Qt::AlignCenter);

        iconLayout->addWidget(icon);

        iconSpacer = new QSpacerItem(17, 156, QSizePolicy::Minimum, QSizePolicy::Expanding);

        iconLayout->addItem(iconSpacer);


        horizontalLayout->addWidget(iconWidget);

        textLayout = new QVBoxLayout();
        textLayout->setSpacing(9);
        textLayout->setObjectName(QStringLiteral("textLayout"));
        textLayout->setContentsMargins(9, 9, 9, 9);
        title = new QLabel(AboutDialog);
        title->setObjectName(QStringLiteral("title"));
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        font.setWeight(50);
        title->setFont(font);

        textLayout->addWidget(title);

        scmversion = new QLabel(AboutDialog);
        scmversion->setObjectName(QStringLiteral("scmversion"));

        textLayout->addWidget(scmversion);

        description = new QLabel(AboutDialog);
        description->setObjectName(QStringLiteral("description"));
        description->setWordWrap(true);

        textLayout->addWidget(description);


        horizontalLayout->addLayout(textLayout);


        retranslateUi(AboutDialog);

        QMetaObject::connectSlotsByName(AboutDialog);
    } // setupUi

    void retranslateUi(QDialog *AboutDialog)
    {
        AboutDialog->setWindowTitle(QApplication::translate("AboutDialog", "About DuckStation", nullptr));
        icon->setText(QString());
        title->setText(QApplication::translate("AboutDialog", "DuckStation", nullptr));
        scmversion->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AboutDialog: public Ui_AboutDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUTDIALOG_H
