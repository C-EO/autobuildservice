/********************************************************************************
** Form generated from reading UI file 'postprocessingsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_POSTPROCESSINGSETTINGSWIDGET_H
#define UI_POSTPROCESSINGSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "duckstation-qt/postprocessingchainconfigwidget.h"

QT_BEGIN_NAMESPACE

class Ui_PostProcessingSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QCheckBox *enablePostProcessing;
    QSpacerItem *horizontalSpacer;
    QPushButton *reload;
    QPushButton *loadPreset;
    QPushButton *savePreset;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    PostProcessingChainConfigWidget *widget;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *PostProcessingSettingsWidget)
    {
        if (PostProcessingSettingsWidget->objectName().isEmpty())
            PostProcessingSettingsWidget->setObjectName(QStringLiteral("PostProcessingSettingsWidget"));
        PostProcessingSettingsWidget->resize(683, 514);
        verticalLayout = new QVBoxLayout(PostProcessingSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        enablePostProcessing = new QCheckBox(PostProcessingSettingsWidget);
        enablePostProcessing->setObjectName(QStringLiteral("enablePostProcessing"));

        horizontalLayout->addWidget(enablePostProcessing);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        reload = new QPushButton(PostProcessingSettingsWidget);
        reload->setObjectName(QStringLiteral("reload"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/view-refresh.png"), QSize(), QIcon::Normal, QIcon::Off);
        reload->setIcon(icon);

        horizontalLayout->addWidget(reload);

        loadPreset = new QPushButton(PostProcessingSettingsWidget);
        loadPreset->setObjectName(QStringLiteral("loadPreset"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/document-save.png"), QSize(), QIcon::Normal, QIcon::Off);
        loadPreset->setIcon(icon1);

        horizontalLayout->addWidget(loadPreset);

        savePreset = new QPushButton(PostProcessingSettingsWidget);
        savePreset->setObjectName(QStringLiteral("savePreset"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/document-open.png"), QSize(), QIcon::Normal, QIcon::Off);
        savePreset->setIcon(icon2);

        horizontalLayout->addWidget(savePreset);


        verticalLayout->addLayout(horizontalLayout);

        groupBox_2 = new QGroupBox(PostProcessingSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        widget = new PostProcessingChainConfigWidget(groupBox_2);
        widget->setObjectName(QStringLiteral("widget"));

        gridLayout_2->addWidget(widget, 0, 0, 1, 1);


        verticalLayout->addWidget(groupBox_2);

        scrollArea = new QScrollArea(PostProcessingSettingsWidget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 681, 390));
        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout->addWidget(scrollArea);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(PostProcessingSettingsWidget);

        QMetaObject::connectSlotsByName(PostProcessingSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *PostProcessingSettingsWidget)
    {
        PostProcessingSettingsWidget->setWindowTitle(QApplication::translate("PostProcessingSettingsWidget", "Form", nullptr));
        enablePostProcessing->setText(QApplication::translate("PostProcessingSettingsWidget", "Enable Post Processing", nullptr));
        reload->setText(QApplication::translate("PostProcessingSettingsWidget", "&Reload Shaders", nullptr));
        loadPreset->setText(QApplication::translate("PostProcessingSettingsWidget", "Load Preset", nullptr));
        savePreset->setText(QApplication::translate("PostProcessingSettingsWidget", "Save Preset", nullptr));
        groupBox_2->setTitle(QApplication::translate("PostProcessingSettingsWidget", "Post Processing Chain", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PostProcessingSettingsWidget: public Ui_PostProcessingSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_POSTPROCESSINGSETTINGSWIDGET_H
