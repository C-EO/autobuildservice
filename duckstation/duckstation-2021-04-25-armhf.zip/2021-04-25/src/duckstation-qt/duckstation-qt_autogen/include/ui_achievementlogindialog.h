/********************************************************************************
** Form generated from reading UI file 'achievementlogindialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACHIEVEMENTLOGINDIALOG_H
#define UI_ACHIEVEMENTLOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AchievementLoginDialog
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QSpacerItem *verticalSpacer;
    QFormLayout *formLayout;
    QLabel *label_4;
    QLineEdit *userName;
    QLabel *label_5;
    QLineEdit *password;
    QHBoxLayout *horizontalLayout_2;
    QLabel *status;
    QPushButton *login;
    QPushButton *cancel;

    void setupUi(QDialog *AchievementLoginDialog)
    {
        if (AchievementLoginDialog->objectName().isEmpty())
            AchievementLoginDialog->setObjectName(QStringLiteral("AchievementLoginDialog"));
        AchievementLoginDialog->setWindowModality(Qt::WindowModal);
        AchievementLoginDialog->resize(410, 190);
        AchievementLoginDialog->setMinimumSize(QSize(410, 190));
        AchievementLoginDialog->setMaximumSize(QSize(410, 190));
        AchievementLoginDialog->setModal(true);
        verticalLayout = new QVBoxLayout(AchievementLoginDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(AchievementLoginDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setPixmap(QPixmap(QString::fromUtf8(":/icons/emblem-person-blue.png")));

        horizontalLayout->addWidget(label);

        label_2 = new QLabel(AchievementLoginDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        font.setWeight(50);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        horizontalLayout->addWidget(label_2);

        horizontalLayout->setStretch(1, 1);

        verticalLayout->addLayout(horizontalLayout);

        label_3 = new QLabel(AchievementLoginDialog);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setWordWrap(true);

        verticalLayout->addWidget(label_3);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label_4 = new QLabel(AchievementLoginDialog);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_4);

        userName = new QLineEdit(AchievementLoginDialog);
        userName->setObjectName(QStringLiteral("userName"));

        formLayout->setWidget(0, QFormLayout::FieldRole, userName);

        label_5 = new QLabel(AchievementLoginDialog);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_5);

        password = new QLineEdit(AchievementLoginDialog);
        password->setObjectName(QStringLiteral("password"));
        password->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(1, QFormLayout::FieldRole, password);


        verticalLayout->addLayout(formLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        status = new QLabel(AchievementLoginDialog);
        status->setObjectName(QStringLiteral("status"));

        horizontalLayout_2->addWidget(status);

        login = new QPushButton(AchievementLoginDialog);
        login->setObjectName(QStringLiteral("login"));
        login->setEnabled(false);

        horizontalLayout_2->addWidget(login);

        cancel = new QPushButton(AchievementLoginDialog);
        cancel->setObjectName(QStringLiteral("cancel"));

        horizontalLayout_2->addWidget(cancel);

        horizontalLayout_2->setStretch(0, 1);

        verticalLayout->addLayout(horizontalLayout_2);


        retranslateUi(AchievementLoginDialog);

        login->setDefault(true);


        QMetaObject::connectSlotsByName(AchievementLoginDialog);
    } // setupUi

    void retranslateUi(QDialog *AchievementLoginDialog)
    {
        AchievementLoginDialog->setWindowTitle(QApplication::translate("AchievementLoginDialog", "RetroAchievements Login", "Window title"));
        label->setText(QString());
        label_2->setText(QApplication::translate("AchievementLoginDialog", "RetroAchievements Login", "Header text"));
        label_3->setText(QApplication::translate("AchievementLoginDialog", "Please enter user name and password for retroachievements.org below. Your password will not be saved in DuckStation, an access token will be generated and used instead.", nullptr));
        label_4->setText(QApplication::translate("AchievementLoginDialog", "User Name:", nullptr));
        label_5->setText(QApplication::translate("AchievementLoginDialog", "Password:", nullptr));
        status->setText(QApplication::translate("AchievementLoginDialog", "Ready...", nullptr));
        login->setText(QApplication::translate("AchievementLoginDialog", "&Login", nullptr));
        cancel->setText(QApplication::translate("AchievementLoginDialog", "&Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AchievementLoginDialog: public Ui_AchievementLoginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACHIEVEMENTLOGINDIALOG_H
