/* */
#include <android/log.h>


int main(void){return 0;}

