/* */
#include <sys/soundcard.h>


int main(void){return 0;}

