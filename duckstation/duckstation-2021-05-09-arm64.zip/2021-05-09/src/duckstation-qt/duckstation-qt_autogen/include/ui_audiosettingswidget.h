/********************************************************************************
** Form generated from reading UI file 'audiosettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUDIOSETTINGSWIDGET_H
#define UI_AUDIOSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AudioSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QFormLayout *formLayout;
    QLabel *label;
    QComboBox *audioBackend;
    QLabel *label_2;
    QSlider *bufferSize;
    QSpacerItem *horizontalSpacer;
    QLabel *bufferingLabel;
    QCheckBox *syncToOutput;
    QCheckBox *resampling;
    QCheckBox *startDumpingOnBoot;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout_2;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout;
    QSlider *volume;
    QLabel *volumeLabel;
    QHBoxLayout *horizontalLayout_2;
    QSlider *fastForwardVolume;
    QLabel *fastForwardVolumeLabel;
    QLabel *label_4;
    QCheckBox *muted;
    QCheckBox *muteCDAudio;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *AudioSettingsWidget)
    {
        if (AudioSettingsWidget->objectName().isEmpty())
            AudioSettingsWidget->setObjectName(QStringLiteral("AudioSettingsWidget"));
        AudioSettingsWidget->resize(502, 312);
        verticalLayout = new QVBoxLayout(AudioSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(AudioSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        formLayout = new QFormLayout(groupBox);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        audioBackend = new QComboBox(groupBox);
        audioBackend->setObjectName(QStringLiteral("audioBackend"));

        formLayout->setWidget(0, QFormLayout::FieldRole, audioBackend);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        bufferSize = new QSlider(groupBox);
        bufferSize->setObjectName(QStringLiteral("bufferSize"));
        bufferSize->setMinimum(1024);
        bufferSize->setMaximum(8192);
        bufferSize->setSingleStep(128);
        bufferSize->setPageStep(1024);
        bufferSize->setOrientation(Qt::Horizontal);
        bufferSize->setTickPosition(QSlider::TicksBothSides);
        bufferSize->setTickInterval(1024);

        formLayout->setWidget(1, QFormLayout::FieldRole, bufferSize);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        formLayout->setItem(2, QFormLayout::LabelRole, horizontalSpacer);

        bufferingLabel = new QLabel(groupBox);
        bufferingLabel->setObjectName(QStringLiteral("bufferingLabel"));
        bufferingLabel->setAlignment(Qt::AlignCenter);

        formLayout->setWidget(2, QFormLayout::FieldRole, bufferingLabel);

        syncToOutput = new QCheckBox(groupBox);
        syncToOutput->setObjectName(QStringLiteral("syncToOutput"));

        formLayout->setWidget(3, QFormLayout::SpanningRole, syncToOutput);

        resampling = new QCheckBox(groupBox);
        resampling->setObjectName(QStringLiteral("resampling"));

        formLayout->setWidget(4, QFormLayout::SpanningRole, resampling);

        startDumpingOnBoot = new QCheckBox(groupBox);
        startDumpingOnBoot->setObjectName(QStringLiteral("startDumpingOnBoot"));

        formLayout->setWidget(5, QFormLayout::SpanningRole, startDumpingOnBoot);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(AudioSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        formLayout_2 = new QFormLayout(groupBox_2);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        volume = new QSlider(groupBox_2);
        volume->setObjectName(QStringLiteral("volume"));
        volume->setMaximum(100);
        volume->setValue(100);
        volume->setOrientation(Qt::Horizontal);
        volume->setTickPosition(QSlider::TicksBothSides);
        volume->setTickInterval(10);

        horizontalLayout->addWidget(volume);

        volumeLabel = new QLabel(groupBox_2);
        volumeLabel->setObjectName(QStringLiteral("volumeLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(volumeLabel->sizePolicy().hasHeightForWidth());
        volumeLabel->setSizePolicy(sizePolicy);
        volumeLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(volumeLabel);


        formLayout_2->setLayout(0, QFormLayout::FieldRole, horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        fastForwardVolume = new QSlider(groupBox_2);
        fastForwardVolume->setObjectName(QStringLiteral("fastForwardVolume"));
        fastForwardVolume->setMaximum(100);
        fastForwardVolume->setValue(100);
        fastForwardVolume->setOrientation(Qt::Horizontal);
        fastForwardVolume->setTickPosition(QSlider::TicksBothSides);
        fastForwardVolume->setTickInterval(10);

        horizontalLayout_2->addWidget(fastForwardVolume);

        fastForwardVolumeLabel = new QLabel(groupBox_2);
        fastForwardVolumeLabel->setObjectName(QStringLiteral("fastForwardVolumeLabel"));
        sizePolicy.setHeightForWidth(fastForwardVolumeLabel->sizePolicy().hasHeightForWidth());
        fastForwardVolumeLabel->setSizePolicy(sizePolicy);
        fastForwardVolumeLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(fastForwardVolumeLabel);


        formLayout_2->setLayout(1, QFormLayout::FieldRole, horizontalLayout_2);

        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_4);

        muted = new QCheckBox(groupBox_2);
        muted->setObjectName(QStringLiteral("muted"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, muted);

        muteCDAudio = new QCheckBox(groupBox_2);
        muteCDAudio->setObjectName(QStringLiteral("muteCDAudio"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, muteCDAudio);


        verticalLayout->addWidget(groupBox_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(AudioSettingsWidget);

        QMetaObject::connectSlotsByName(AudioSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *AudioSettingsWidget)
    {
        AudioSettingsWidget->setWindowTitle(QApplication::translate("AudioSettingsWidget", "Form", nullptr));
        groupBox->setTitle(QApplication::translate("AudioSettingsWidget", "Configuration", nullptr));
        label->setText(QApplication::translate("AudioSettingsWidget", "Backend:", nullptr));
        label_2->setText(QApplication::translate("AudioSettingsWidget", "Buffer Size:", nullptr));
        bufferingLabel->setText(QApplication::translate("AudioSettingsWidget", "Maximum latency: 0 frames (0.00ms)", nullptr));
        syncToOutput->setText(QApplication::translate("AudioSettingsWidget", "Sync To Output", nullptr));
        resampling->setText(QApplication::translate("AudioSettingsWidget", "Resampling", nullptr));
        startDumpingOnBoot->setText(QApplication::translate("AudioSettingsWidget", "Start Dumping On Boot", nullptr));
        groupBox_2->setTitle(QApplication::translate("AudioSettingsWidget", "Controls", nullptr));
        label_3->setText(QApplication::translate("AudioSettingsWidget", "Output Volume:", nullptr));
        volumeLabel->setText(QApplication::translate("AudioSettingsWidget", "100%", nullptr));
        fastForwardVolumeLabel->setText(QApplication::translate("AudioSettingsWidget", "100%", nullptr));
        label_4->setText(QApplication::translate("AudioSettingsWidget", "Fast Forward Volume:", nullptr));
        muted->setText(QApplication::translate("AudioSettingsWidget", "Mute All Sound", nullptr));
        muteCDAudio->setText(QApplication::translate("AudioSettingsWidget", "Mute CD Audio", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AudioSettingsWidget: public Ui_AudioSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUDIOSETTINGSWIDGET_H
