/********************************************************************************
** Form generated from reading UI file 'achievementsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACHIEVEMENTSETTINGSWIDGET_H
#define UI_ACHIEVEMENTSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AchievementSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QCheckBox *enable;
    QCheckBox *richPresence;
    QCheckBox *testMode;
    QCheckBox *useFirstDiscFromPlaylist;
    QCheckBox *challengeMode;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout;
    QLabel *loginStatus;
    QVBoxLayout *verticalLayout_2;
    QPushButton *loginButton;
    QPushButton *viewProfile;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_3;
    QLabel *gameInfo;
    QLabel *label;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *AchievementSettingsWidget)
    {
        if (AchievementSettingsWidget->objectName().isEmpty())
            AchievementSettingsWidget->setObjectName(QStringLiteral("AchievementSettingsWidget"));
        AchievementSettingsWidget->resize(648, 456);
        verticalLayout = new QVBoxLayout(AchievementSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(AchievementSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        enable = new QCheckBox(groupBox);
        enable->setObjectName(QStringLiteral("enable"));

        gridLayout->addWidget(enable, 0, 0, 1, 1);

        richPresence = new QCheckBox(groupBox);
        richPresence->setObjectName(QStringLiteral("richPresence"));

        gridLayout->addWidget(richPresence, 0, 1, 1, 1);

        testMode = new QCheckBox(groupBox);
        testMode->setObjectName(QStringLiteral("testMode"));

        gridLayout->addWidget(testMode, 1, 0, 1, 1);

        useFirstDiscFromPlaylist = new QCheckBox(groupBox);
        useFirstDiscFromPlaylist->setObjectName(QStringLiteral("useFirstDiscFromPlaylist"));

        gridLayout->addWidget(useFirstDiscFromPlaylist, 1, 1, 1, 1);

        challengeMode = new QCheckBox(groupBox);
        challengeMode->setObjectName(QStringLiteral("challengeMode"));

        gridLayout->addWidget(challengeMode, 2, 0, 1, 1);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(AchievementSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        horizontalLayout = new QHBoxLayout(groupBox_2);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        loginStatus = new QLabel(groupBox_2);
        loginStatus->setObjectName(QStringLiteral("loginStatus"));
        loginStatus->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        horizontalLayout->addWidget(loginStatus);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        loginButton = new QPushButton(groupBox_2);
        loginButton->setObjectName(QStringLiteral("loginButton"));

        verticalLayout_2->addWidget(loginButton);

        viewProfile = new QPushButton(groupBox_2);
        viewProfile->setObjectName(QStringLiteral("viewProfile"));

        verticalLayout_2->addWidget(viewProfile);


        horizontalLayout->addLayout(verticalLayout_2);

        horizontalLayout->setStretch(0, 1);

        verticalLayout->addWidget(groupBox_2);

        groupBox_4 = new QGroupBox(AchievementSettingsWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setMinimumSize(QSize(0, 160));
        gridLayout_3 = new QGridLayout(groupBox_4);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gameInfo = new QLabel(groupBox_4);
        gameInfo->setObjectName(QStringLiteral("gameInfo"));
        gameInfo->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        gridLayout_3->addWidget(gameInfo, 0, 0, 1, 1);


        verticalLayout->addWidget(groupBox_4);

        label = new QLabel(AchievementSettingsWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setTextFormat(Qt::RichText);
        label->setWordWrap(true);
        label->setMargin(8);
        label->setOpenExternalLinks(true);

        verticalLayout->addWidget(label);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(AchievementSettingsWidget);

        QMetaObject::connectSlotsByName(AchievementSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *AchievementSettingsWidget)
    {
        AchievementSettingsWidget->setWindowTitle(QApplication::translate("AchievementSettingsWidget", "Form", nullptr));
        groupBox->setTitle(QApplication::translate("AchievementSettingsWidget", "Global Settings", nullptr));
        enable->setText(QApplication::translate("AchievementSettingsWidget", "Enable Achievements", nullptr));
        richPresence->setText(QApplication::translate("AchievementSettingsWidget", "Enable Rich Presence", nullptr));
        testMode->setText(QApplication::translate("AchievementSettingsWidget", "Enable Test Mode", nullptr));
        useFirstDiscFromPlaylist->setText(QApplication::translate("AchievementSettingsWidget", "Use First Disc From Playlist", nullptr));
        challengeMode->setText(QApplication::translate("AchievementSettingsWidget", "Enable Hardcore Mode", nullptr));
        groupBox_2->setTitle(QApplication::translate("AchievementSettingsWidget", "Account", nullptr));
        loginButton->setText(QApplication::translate("AchievementSettingsWidget", "Login...", nullptr));
        viewProfile->setText(QApplication::translate("AchievementSettingsWidget", "View Profile...", nullptr));
        groupBox_4->setTitle(QApplication::translate("AchievementSettingsWidget", "Game Info", nullptr));
        label->setText(QApplication::translate("AchievementSettingsWidget", "<html><head/><body><p align=\"justify\">DuckStation uses RetroAchievements as an achievement database and for tracking progress. To use achievements, please sign up for an account at <a href=\"https://retroachievements.org/\"><span style=\" text-decoration: underline; color:#0000ff;\">retroachievements.org</span></a>.</p><p align=\"justify\">To view the achievement list in-game, press the hotkey for <span style=\" font-weight:600;\">Open Quick Menu</span> and select <span style=\" font-weight:600;\">Achievements</span> from the menu.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AchievementSettingsWidget: public Ui_AchievementSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACHIEVEMENTSETTINGSWIDGET_H
