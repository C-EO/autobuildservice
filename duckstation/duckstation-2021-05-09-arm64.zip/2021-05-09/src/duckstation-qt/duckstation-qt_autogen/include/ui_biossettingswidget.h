/********************************************************************************
** Form generated from reading UI file 'biossettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BIOSSETTINGSWIDGET_H
#define UI_BIOSSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BIOSSettingsWidget
{
public:
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QComboBox *imageNTSCJ;
    QLabel *label_5;
    QLabel *label;
    QLabel *label_2;
    QComboBox *imagePAL;
    QComboBox *imageNTSCU;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *openSearchDirectory;
    QPushButton *refresh;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_2;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout;
    QLineEdit *searchDirectory;
    QPushButton *browseSearchDirectory;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout;
    QCheckBox *fastBoot;
    QCheckBox *enableTTYOutput;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *BIOSSettingsWidget)
    {
        if (BIOSSettingsWidget->objectName().isEmpty())
            BIOSSettingsWidget->setObjectName(QStringLiteral("BIOSSettingsWidget"));
        BIOSSettingsWidget->resize(529, 330);
        verticalLayout_2 = new QVBoxLayout(BIOSSettingsWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(BIOSSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        imageNTSCJ = new QComboBox(groupBox);
        imageNTSCJ->setObjectName(QStringLiteral("imageNTSCJ"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(imageNTSCJ->sizePolicy().hasHeightForWidth());
        imageNTSCJ->setSizePolicy(sizePolicy);

        gridLayout->addWidget(imageNTSCJ, 0, 1, 1, 1);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 2, 0, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        imagePAL = new QComboBox(groupBox);
        imagePAL->setObjectName(QStringLiteral("imagePAL"));
        sizePolicy.setHeightForWidth(imagePAL->sizePolicy().hasHeightForWidth());
        imagePAL->setSizePolicy(sizePolicy);

        gridLayout->addWidget(imagePAL, 2, 1, 1, 1);

        imageNTSCU = new QComboBox(groupBox);
        imageNTSCU->setObjectName(QStringLiteral("imageNTSCU"));
        sizePolicy.setHeightForWidth(imageNTSCU->sizePolicy().hasHeightForWidth());
        imageNTSCU->setSizePolicy(sizePolicy);

        gridLayout->addWidget(imageNTSCU, 1, 1, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        openSearchDirectory = new QPushButton(groupBox);
        openSearchDirectory->setObjectName(QStringLiteral("openSearchDirectory"));

        horizontalLayout_2->addWidget(openSearchDirectory);

        refresh = new QPushButton(groupBox);
        refresh->setObjectName(QStringLiteral("refresh"));

        horizontalLayout_2->addWidget(refresh);


        gridLayout->addLayout(horizontalLayout_2, 3, 1, 1, 1);


        verticalLayout_2->addWidget(groupBox);

        groupBox_3 = new QGroupBox(BIOSSettingsWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_2 = new QGridLayout(groupBox_3);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setWordWrap(true);

        gridLayout_2->addWidget(label_3, 0, 0, 1, 2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        searchDirectory = new QLineEdit(groupBox_3);
        searchDirectory->setObjectName(QStringLiteral("searchDirectory"));

        horizontalLayout->addWidget(searchDirectory);

        browseSearchDirectory = new QPushButton(groupBox_3);
        browseSearchDirectory->setObjectName(QStringLiteral("browseSearchDirectory"));

        horizontalLayout->addWidget(browseSearchDirectory);


        gridLayout_2->addLayout(horizontalLayout, 1, 0, 1, 2);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_2 = new QGroupBox(BIOSSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        verticalLayout = new QVBoxLayout(groupBox_2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        fastBoot = new QCheckBox(groupBox_2);
        fastBoot->setObjectName(QStringLiteral("fastBoot"));

        verticalLayout->addWidget(fastBoot);

        enableTTYOutput = new QCheckBox(groupBox_2);
        enableTTYOutput->setObjectName(QStringLiteral("enableTTYOutput"));

        verticalLayout->addWidget(enableTTYOutput);


        verticalLayout_2->addWidget(groupBox_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        retranslateUi(BIOSSettingsWidget);

        QMetaObject::connectSlotsByName(BIOSSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *BIOSSettingsWidget)
    {
        BIOSSettingsWidget->setWindowTitle(QApplication::translate("BIOSSettingsWidget", "Form", nullptr));
        groupBox->setTitle(QApplication::translate("BIOSSettingsWidget", "BIOS Selection", nullptr));
        label_5->setText(QApplication::translate("BIOSSettingsWidget", "PAL (Europe, Australia):", nullptr));
        label->setText(QApplication::translate("BIOSSettingsWidget", "NTSC-J (Japan):", nullptr));
        label_2->setText(QApplication::translate("BIOSSettingsWidget", "NTSC-U/C (US/Canada):", nullptr));
        openSearchDirectory->setText(QApplication::translate("BIOSSettingsWidget", "Open in Explorer...", nullptr));
        refresh->setText(QApplication::translate("BIOSSettingsWidget", "Refresh List", nullptr));
        groupBox_3->setTitle(QApplication::translate("BIOSSettingsWidget", "BIOS Directory", nullptr));
        label_3->setText(QApplication::translate("BIOSSettingsWidget", "DuckStation will search for BIOS images in this directory.", nullptr));
        browseSearchDirectory->setText(QApplication::translate("BIOSSettingsWidget", "Browse...", nullptr));
        groupBox_2->setTitle(QApplication::translate("BIOSSettingsWidget", "Options and Patches", nullptr));
        fastBoot->setText(QApplication::translate("BIOSSettingsWidget", "Fast Boot", nullptr));
        enableTTYOutput->setText(QApplication::translate("BIOSSettingsWidget", "Enable TTY Output", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BIOSSettingsWidget: public Ui_BIOSSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BIOSSETTINGSWIDGET_H
