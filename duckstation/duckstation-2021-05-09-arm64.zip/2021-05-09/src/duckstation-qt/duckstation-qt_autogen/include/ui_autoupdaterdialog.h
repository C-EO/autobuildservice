/********************************************************************************
** Form generated from reading UI file 'autoupdaterdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTOUPDATERDIALOG_H
#define UI_AUTOUPDATERDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AutoUpdaterDialog
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *label;
    QLabel *currentVersion;
    QLabel *newVersion;
    QTextBrowser *updateNotes;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *downloadAndInstall;
    QPushButton *skipThisUpdate;
    QPushButton *remindMeLater;

    void setupUi(QDialog *AutoUpdaterDialog)
    {
        if (AutoUpdaterDialog->objectName().isEmpty())
            AutoUpdaterDialog->setObjectName(QStringLiteral("AutoUpdaterDialog"));
        AutoUpdaterDialog->setWindowModality(Qt::ApplicationModal);
        AutoUpdaterDialog->resize(651, 474);
        AutoUpdaterDialog->setModal(true);
        verticalLayout = new QVBoxLayout(AutoUpdaterDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(AutoUpdaterDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/icons/software-update-available.png")));

        horizontalLayout_2->addWidget(label_2);

        label = new QLabel(AutoUpdaterDialog);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        horizontalLayout_2->setStretch(1, 1);

        verticalLayout->addLayout(horizontalLayout_2);

        currentVersion = new QLabel(AutoUpdaterDialog);
        currentVersion->setObjectName(QStringLiteral("currentVersion"));

        verticalLayout->addWidget(currentVersion);

        newVersion = new QLabel(AutoUpdaterDialog);
        newVersion->setObjectName(QStringLiteral("newVersion"));

        verticalLayout->addWidget(newVersion);

        updateNotes = new QTextBrowser(AutoUpdaterDialog);
        updateNotes->setObjectName(QStringLiteral("updateNotes"));

        verticalLayout->addWidget(updateNotes);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        downloadAndInstall = new QPushButton(AutoUpdaterDialog);
        downloadAndInstall->setObjectName(QStringLiteral("downloadAndInstall"));
        downloadAndInstall->setEnabled(false);

        horizontalLayout->addWidget(downloadAndInstall);

        skipThisUpdate = new QPushButton(AutoUpdaterDialog);
        skipThisUpdate->setObjectName(QStringLiteral("skipThisUpdate"));

        horizontalLayout->addWidget(skipThisUpdate);

        remindMeLater = new QPushButton(AutoUpdaterDialog);
        remindMeLater->setObjectName(QStringLiteral("remindMeLater"));

        horizontalLayout->addWidget(remindMeLater);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(AutoUpdaterDialog);

        remindMeLater->setDefault(true);


        QMetaObject::connectSlotsByName(AutoUpdaterDialog);
    } // setupUi

    void retranslateUi(QDialog *AutoUpdaterDialog)
    {
        AutoUpdaterDialog->setWindowTitle(QApplication::translate("AutoUpdaterDialog", "Automatic Updater", nullptr));
        label_2->setText(QString());
        label->setText(QApplication::translate("AutoUpdaterDialog", "Update Available", nullptr));
        currentVersion->setText(QApplication::translate("AutoUpdaterDialog", "Current Version: ", nullptr));
        newVersion->setText(QApplication::translate("AutoUpdaterDialog", "New Version: ", nullptr));
        downloadAndInstall->setText(QApplication::translate("AutoUpdaterDialog", "Download and Install...", nullptr));
        skipThisUpdate->setText(QApplication::translate("AutoUpdaterDialog", "Skip This Update", nullptr));
        remindMeLater->setText(QApplication::translate("AutoUpdaterDialog", "Remind Me Later", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AutoUpdaterDialog: public Ui_AutoUpdaterDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTOUPDATERDIALOG_H
