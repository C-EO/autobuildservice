// 77bf7d39028a16e2a7ee13c40d163fd174468bd7 master 0.1-3971-g77bf7d39 2021-05-09T03:30:57+10:00
const char* g_scm_hash_str = "77bf7d39028a16e2a7ee13c40d163fd174468bd7";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3971-g77bf7d39";
const char* g_scm_date_str = "2021-05-09T03:30:57+10:00";

