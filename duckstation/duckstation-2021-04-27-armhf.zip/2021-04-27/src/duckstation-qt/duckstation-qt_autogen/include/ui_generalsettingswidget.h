/********************************************************************************
** Form generated from reading UI file 'generalsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GENERALSETTINGSWIDGET_H
#define UI_GENERALSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GeneralSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_4;
    QGridLayout *formLayout_4;
    QCheckBox *confirmPowerOff;
    QCheckBox *renderToMain;
    QCheckBox *pauseOnStart;
    QCheckBox *pauseOnFocusLoss;
    QCheckBox *startFullscreen;
    QCheckBox *saveStateOnExit;
    QCheckBox *applyGameSettings;
    QCheckBox *autoLoadCheats;
    QCheckBox *loadDevicesFromSaveStates;
    QCheckBox *hideCursorInFullscreen;
    QCheckBox *enableFullscreenUI;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *controllerBackend;
    QGroupBox *automaticUpdaterGroup;
    QFormLayout *formLayout_2;
    QLabel *label_4;
    QComboBox *autoUpdateTag;
    QLabel *label_5;
    QLabel *autoUpdateCurrentVersion;
    QCheckBox *autoUpdateEnabled;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *checkForUpdates;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *GeneralSettingsWidget)
    {
        if (GeneralSettingsWidget->objectName().isEmpty())
            GeneralSettingsWidget->setObjectName(QStringLiteral("GeneralSettingsWidget"));
        GeneralSettingsWidget->resize(652, 483);
        verticalLayout = new QVBoxLayout(GeneralSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox_4 = new QGroupBox(GeneralSettingsWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        formLayout_4 = new QGridLayout(groupBox_4);
        formLayout_4->setObjectName(QStringLiteral("formLayout_4"));
        confirmPowerOff = new QCheckBox(groupBox_4);
        confirmPowerOff->setObjectName(QStringLiteral("confirmPowerOff"));

        formLayout_4->addWidget(confirmPowerOff, 1, 0, 1, 1);

        renderToMain = new QCheckBox(groupBox_4);
        renderToMain->setObjectName(QStringLiteral("renderToMain"));

        formLayout_4->addWidget(renderToMain, 3, 0, 1, 1);

        pauseOnStart = new QCheckBox(groupBox_4);
        pauseOnStart->setObjectName(QStringLiteral("pauseOnStart"));

        formLayout_4->addWidget(pauseOnStart, 0, 0, 1, 1);

        pauseOnFocusLoss = new QCheckBox(groupBox_4);
        pauseOnFocusLoss->setObjectName(QStringLiteral("pauseOnFocusLoss"));

        formLayout_4->addWidget(pauseOnFocusLoss, 0, 1, 1, 1);

        startFullscreen = new QCheckBox(groupBox_4);
        startFullscreen->setObjectName(QStringLiteral("startFullscreen"));

        formLayout_4->addWidget(startFullscreen, 2, 0, 1, 1);

        saveStateOnExit = new QCheckBox(groupBox_4);
        saveStateOnExit->setObjectName(QStringLiteral("saveStateOnExit"));

        formLayout_4->addWidget(saveStateOnExit, 1, 1, 1, 1);

        applyGameSettings = new QCheckBox(groupBox_4);
        applyGameSettings->setObjectName(QStringLiteral("applyGameSettings"));

        formLayout_4->addWidget(applyGameSettings, 4, 0, 1, 1);

        autoLoadCheats = new QCheckBox(groupBox_4);
        autoLoadCheats->setObjectName(QStringLiteral("autoLoadCheats"));

        formLayout_4->addWidget(autoLoadCheats, 4, 1, 1, 1);

        loadDevicesFromSaveStates = new QCheckBox(groupBox_4);
        loadDevicesFromSaveStates->setObjectName(QStringLiteral("loadDevicesFromSaveStates"));

        formLayout_4->addWidget(loadDevicesFromSaveStates, 3, 1, 1, 1);

        hideCursorInFullscreen = new QCheckBox(groupBox_4);
        hideCursorInFullscreen->setObjectName(QStringLiteral("hideCursorInFullscreen"));

        formLayout_4->addWidget(hideCursorInFullscreen, 2, 1, 1, 1);

        enableFullscreenUI = new QCheckBox(groupBox_4);
        enableFullscreenUI->setObjectName(QStringLiteral("enableFullscreenUI"));

        formLayout_4->addWidget(enableFullscreenUI, 5, 0, 1, 1);


        verticalLayout->addWidget(groupBox_4);

        groupBox = new QGroupBox(GeneralSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        controllerBackend = new QComboBox(groupBox);
        controllerBackend->setObjectName(QStringLiteral("controllerBackend"));

        horizontalLayout->addWidget(controllerBackend);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);


        verticalLayout->addWidget(groupBox);

        automaticUpdaterGroup = new QGroupBox(GeneralSettingsWidget);
        automaticUpdaterGroup->setObjectName(QStringLiteral("automaticUpdaterGroup"));
        formLayout_2 = new QFormLayout(automaticUpdaterGroup);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_4 = new QLabel(automaticUpdaterGroup);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_4);

        autoUpdateTag = new QComboBox(automaticUpdaterGroup);
        autoUpdateTag->setObjectName(QStringLiteral("autoUpdateTag"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, autoUpdateTag);

        label_5 = new QLabel(automaticUpdaterGroup);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_5);

        autoUpdateCurrentVersion = new QLabel(automaticUpdaterGroup);
        autoUpdateCurrentVersion->setObjectName(QStringLiteral("autoUpdateCurrentVersion"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, autoUpdateCurrentVersion);

        autoUpdateEnabled = new QCheckBox(automaticUpdaterGroup);
        autoUpdateEnabled->setObjectName(QStringLiteral("autoUpdateEnabled"));

        formLayout_2->setWidget(3, QFormLayout::SpanningRole, autoUpdateEnabled);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        checkForUpdates = new QPushButton(automaticUpdaterGroup);
        checkForUpdates->setObjectName(QStringLiteral("checkForUpdates"));

        horizontalLayout_2->addWidget(checkForUpdates);


        formLayout_2->setLayout(5, QFormLayout::SpanningRole, horizontalLayout_2);


        verticalLayout->addWidget(automaticUpdaterGroup);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(GeneralSettingsWidget);

        QMetaObject::connectSlotsByName(GeneralSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *GeneralSettingsWidget)
    {
        GeneralSettingsWidget->setWindowTitle(QApplication::translate("GeneralSettingsWidget", "Form", nullptr));
        groupBox_4->setTitle(QApplication::translate("GeneralSettingsWidget", "Behaviour", nullptr));
        confirmPowerOff->setText(QApplication::translate("GeneralSettingsWidget", "Confirm Power Off", nullptr));
        renderToMain->setText(QApplication::translate("GeneralSettingsWidget", "Render To Main Window", nullptr));
        pauseOnStart->setText(QApplication::translate("GeneralSettingsWidget", "Pause On Start", nullptr));
        pauseOnFocusLoss->setText(QApplication::translate("GeneralSettingsWidget", "Pause On Focus Loss", nullptr));
        startFullscreen->setText(QApplication::translate("GeneralSettingsWidget", "Start Fullscreen", nullptr));
        saveStateOnExit->setText(QApplication::translate("GeneralSettingsWidget", "Save State On Exit", nullptr));
        applyGameSettings->setText(QApplication::translate("GeneralSettingsWidget", "Apply Per-Game Settings", nullptr));
        autoLoadCheats->setText(QApplication::translate("GeneralSettingsWidget", "Automatically Load Cheats", nullptr));
        loadDevicesFromSaveStates->setText(QApplication::translate("GeneralSettingsWidget", "Load Devices From Save States", nullptr));
        hideCursorInFullscreen->setText(QApplication::translate("GeneralSettingsWidget", "Hide Cursor In Fullscreen", nullptr));
        enableFullscreenUI->setText(QApplication::translate("GeneralSettingsWidget", "Enable Fullscreen UI", nullptr));
        groupBox->setTitle(QApplication::translate("GeneralSettingsWidget", "Miscellaneous", nullptr));
        label->setText(QApplication::translate("GeneralSettingsWidget", "Controller Backend:", nullptr));
        automaticUpdaterGroup->setTitle(QApplication::translate("GeneralSettingsWidget", "Automatic Updater", nullptr));
        label_4->setText(QApplication::translate("GeneralSettingsWidget", "Update Channel:", nullptr));
        label_5->setText(QApplication::translate("GeneralSettingsWidget", "Current Version:", nullptr));
        autoUpdateCurrentVersion->setText(QString());
        autoUpdateEnabled->setText(QApplication::translate("GeneralSettingsWidget", "Enable Automatic Update Check", nullptr));
        checkForUpdates->setText(QApplication::translate("GeneralSettingsWidget", "Check for Updates...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GeneralSettingsWidget: public Ui_GeneralSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GENERALSETTINGSWIDGET_H
