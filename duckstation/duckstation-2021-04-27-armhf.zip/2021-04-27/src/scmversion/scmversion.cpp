// 1e44c2f3d0fad0c56d6412884329fb22afba7dbf master 0.1-3885-g1e44c2f3 2021-04-27T03:16:44+10:00
const char* g_scm_hash_str = "1e44c2f3d0fad0c56d6412884329fb22afba7dbf";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3885-g1e44c2f3";
const char* g_scm_date_str = "2021-04-27T03:16:44+10:00";

