/****************************************************************************
** Meta object code from reading C++ file 'qthostinterface.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "duckstation-qt/qthostinterface.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qthostinterface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtHostInterface_t {
    QByteArrayData data[125];
    char stringdata0[1896];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtHostInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtHostInterface_t qt_meta_stringdata_QtHostInterface = {
    {
QT_MOC_LITERAL(0, 0, 15), // "QtHostInterface"
QT_MOC_LITERAL(1, 16, 13), // "errorReported"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 7), // "message"
QT_MOC_LITERAL(4, 39, 15), // "messageReported"
QT_MOC_LITERAL(5, 55, 23), // "debuggerMessageReported"
QT_MOC_LITERAL(6, 79, 16), // "messageConfirmed"
QT_MOC_LITERAL(7, 96, 17), // "emulationStarting"
QT_MOC_LITERAL(8, 114, 16), // "emulationStarted"
QT_MOC_LITERAL(9, 131, 16), // "emulationStopped"
QT_MOC_LITERAL(10, 148, 15), // "emulationPaused"
QT_MOC_LITERAL(11, 164, 6), // "paused"
QT_MOC_LITERAL(12, 171, 10), // "stateSaved"
QT_MOC_LITERAL(13, 182, 9), // "game_code"
QT_MOC_LITERAL(14, 192, 6), // "global"
QT_MOC_LITERAL(15, 199, 4), // "slot"
QT_MOC_LITERAL(16, 204, 17), // "gameListRefreshed"
QT_MOC_LITERAL(17, 222, 22), // "createDisplayRequested"
QT_MOC_LITERAL(18, 245, 16), // "QtDisplayWidget*"
QT_MOC_LITERAL(19, 262, 8), // "QThread*"
QT_MOC_LITERAL(20, 271, 13), // "worker_thread"
QT_MOC_LITERAL(21, 285, 10), // "fullscreen"
QT_MOC_LITERAL(22, 296, 14), // "render_to_main"
QT_MOC_LITERAL(23, 311, 22), // "updateDisplayRequested"
QT_MOC_LITERAL(24, 334, 20), // "displaySizeRequested"
QT_MOC_LITERAL(25, 355, 5), // "width"
QT_MOC_LITERAL(26, 361, 6), // "height"
QT_MOC_LITERAL(27, 368, 27), // "focusDisplayWidgetRequested"
QT_MOC_LITERAL(28, 396, 23), // "destroyDisplayRequested"
QT_MOC_LITERAL(29, 420, 32), // "systemPerformanceCountersUpdated"
QT_MOC_LITERAL(30, 453, 5), // "speed"
QT_MOC_LITERAL(31, 459, 3), // "fps"
QT_MOC_LITERAL(32, 463, 3), // "vps"
QT_MOC_LITERAL(33, 467, 14), // "avg_frame_time"
QT_MOC_LITERAL(34, 482, 16), // "worst_frame_time"
QT_MOC_LITERAL(35, 499, 11), // "GPURenderer"
QT_MOC_LITERAL(36, 511, 8), // "renderer"
QT_MOC_LITERAL(37, 520, 12), // "render_width"
QT_MOC_LITERAL(38, 533, 13), // "render_height"
QT_MOC_LITERAL(39, 547, 17), // "render_interlaced"
QT_MOC_LITERAL(40, 565, 18), // "runningGameChanged"
QT_MOC_LITERAL(41, 584, 8), // "filename"
QT_MOC_LITERAL(42, 593, 10), // "game_title"
QT_MOC_LITERAL(43, 604, 13), // "exitRequested"
QT_MOC_LITERAL(44, 618, 18), // "inputProfileLoaded"
QT_MOC_LITERAL(45, 637, 18), // "mouseModeRequested"
QT_MOC_LITERAL(46, 656, 8), // "relative"
QT_MOC_LITERAL(47, 665, 11), // "hide_cursor"
QT_MOC_LITERAL(48, 677, 18), // "achievementsLoaded"
QT_MOC_LITERAL(49, 696, 2), // "id"
QT_MOC_LITERAL(50, 699, 16), // "game_info_string"
QT_MOC_LITERAL(51, 716, 5), // "total"
QT_MOC_LITERAL(52, 722, 6), // "points"
QT_MOC_LITERAL(53, 729, 11), // "ReportError"
QT_MOC_LITERAL(54, 741, 11), // "const char*"
QT_MOC_LITERAL(55, 753, 13), // "ReportMessage"
QT_MOC_LITERAL(56, 767, 21), // "ReportDebuggerMessage"
QT_MOC_LITERAL(57, 789, 14), // "ConfirmMessage"
QT_MOC_LITERAL(58, 804, 18), // "setDefaultSettings"
QT_MOC_LITERAL(59, 823, 13), // "applySettings"
QT_MOC_LITERAL(60, 837, 20), // "display_osd_messages"
QT_MOC_LITERAL(61, 858, 14), // "updateInputMap"
QT_MOC_LITERAL(62, 873, 17), // "applyInputProfile"
QT_MOC_LITERAL(63, 891, 12), // "profile_path"
QT_MOC_LITERAL(64, 904, 10), // "bootSystem"
QT_MOC_LITERAL(65, 915, 43), // "std::shared_ptr<const SystemB..."
QT_MOC_LITERAL(66, 959, 6), // "params"
QT_MOC_LITERAL(67, 966, 21), // "resumeSystemFromState"
QT_MOC_LITERAL(68, 988, 15), // "boot_on_failure"
QT_MOC_LITERAL(69, 1004, 31), // "resumeSystemFromMostRecentState"
QT_MOC_LITERAL(70, 1036, 14), // "powerOffSystem"
QT_MOC_LITERAL(71, 1051, 27), // "powerOffSystemWithoutSaving"
QT_MOC_LITERAL(72, 1079, 25), // "synchronousPowerOffSystem"
QT_MOC_LITERAL(73, 1105, 11), // "resetSystem"
QT_MOC_LITERAL(74, 1117, 11), // "pauseSystem"
QT_MOC_LITERAL(75, 1129, 17), // "wait_until_paused"
QT_MOC_LITERAL(76, 1147, 10), // "changeDisc"
QT_MOC_LITERAL(77, 1158, 17), // "new_disc_filename"
QT_MOC_LITERAL(78, 1176, 22), // "changeDiscFromPlaylist"
QT_MOC_LITERAL(79, 1199, 5), // "index"
QT_MOC_LITERAL(80, 1205, 9), // "loadState"
QT_MOC_LITERAL(81, 1215, 9), // "saveState"
QT_MOC_LITERAL(82, 1225, 16), // "block_until_done"
QT_MOC_LITERAL(83, 1242, 20), // "setAudioOutputVolume"
QT_MOC_LITERAL(84, 1263, 6), // "volume"
QT_MOC_LITERAL(85, 1270, 19), // "fast_forward_volume"
QT_MOC_LITERAL(86, 1290, 19), // "setAudioOutputMuted"
QT_MOC_LITERAL(87, 1310, 5), // "muted"
QT_MOC_LITERAL(88, 1316, 17), // "startDumpingAudio"
QT_MOC_LITERAL(89, 1334, 16), // "stopDumpingAudio"
QT_MOC_LITERAL(90, 1351, 13), // "singleStepCPU"
QT_MOC_LITERAL(91, 1365, 7), // "dumpRAM"
QT_MOC_LITERAL(92, 1373, 8), // "dumpVRAM"
QT_MOC_LITERAL(93, 1382, 10), // "dumpSPURAM"
QT_MOC_LITERAL(94, 1393, 14), // "saveScreenshot"
QT_MOC_LITERAL(95, 1408, 19), // "redrawDisplayWindow"
QT_MOC_LITERAL(96, 1428, 16), // "toggleFullscreen"
QT_MOC_LITERAL(97, 1445, 13), // "loadCheatList"
QT_MOC_LITERAL(98, 1459, 15), // "setCheatEnabled"
QT_MOC_LITERAL(99, 1475, 7), // "enabled"
QT_MOC_LITERAL(100, 1483, 10), // "applyCheat"
QT_MOC_LITERAL(101, 1494, 27), // "reloadPostProcessingShaders"
QT_MOC_LITERAL(102, 1522, 24), // "requestRenderWindowScale"
QT_MOC_LITERAL(103, 1547, 5), // "scale"
QT_MOC_LITERAL(104, 1553, 24), // "executeOnEmulationThread"
QT_MOC_LITERAL(105, 1578, 21), // "std::function<void()>"
QT_MOC_LITERAL(106, 1600, 8), // "callback"
QT_MOC_LITERAL(107, 1609, 4), // "wait"
QT_MOC_LITERAL(108, 1614, 23), // "OnAchievementsRefreshed"
QT_MOC_LITERAL(109, 1638, 12), // "doStopThread"
QT_MOC_LITERAL(110, 1651, 29), // "onDisplayWindowMouseMoveEvent"
QT_MOC_LITERAL(111, 1681, 1), // "x"
QT_MOC_LITERAL(112, 1683, 1), // "y"
QT_MOC_LITERAL(113, 1685, 31), // "onDisplayWindowMouseButtonEvent"
QT_MOC_LITERAL(114, 1717, 6), // "button"
QT_MOC_LITERAL(115, 1724, 7), // "pressed"
QT_MOC_LITERAL(116, 1732, 30), // "onDisplayWindowMouseWheelEvent"
QT_MOC_LITERAL(117, 1763, 11), // "delta_angle"
QT_MOC_LITERAL(118, 1775, 22), // "onDisplayWindowResized"
QT_MOC_LITERAL(119, 1798, 22), // "onDisplayWindowFocused"
QT_MOC_LITERAL(120, 1821, 23), // "onDisplayWindowKeyEvent"
QT_MOC_LITERAL(121, 1845, 3), // "key"
QT_MOC_LITERAL(122, 1849, 4), // "mods"
QT_MOC_LITERAL(123, 1854, 26), // "doBackgroundControllerPoll"
QT_MOC_LITERAL(124, 1881, 14) // "doSaveSettings"

    },
    "QtHostInterface\0errorReported\0\0message\0"
    "messageReported\0debuggerMessageReported\0"
    "messageConfirmed\0emulationStarting\0"
    "emulationStarted\0emulationStopped\0"
    "emulationPaused\0paused\0stateSaved\0"
    "game_code\0global\0slot\0gameListRefreshed\0"
    "createDisplayRequested\0QtDisplayWidget*\0"
    "QThread*\0worker_thread\0fullscreen\0"
    "render_to_main\0updateDisplayRequested\0"
    "displaySizeRequested\0width\0height\0"
    "focusDisplayWidgetRequested\0"
    "destroyDisplayRequested\0"
    "systemPerformanceCountersUpdated\0speed\0"
    "fps\0vps\0avg_frame_time\0worst_frame_time\0"
    "GPURenderer\0renderer\0render_width\0"
    "render_height\0render_interlaced\0"
    "runningGameChanged\0filename\0game_title\0"
    "exitRequested\0inputProfileLoaded\0"
    "mouseModeRequested\0relative\0hide_cursor\0"
    "achievementsLoaded\0id\0game_info_string\0"
    "total\0points\0ReportError\0const char*\0"
    "ReportMessage\0ReportDebuggerMessage\0"
    "ConfirmMessage\0setDefaultSettings\0"
    "applySettings\0display_osd_messages\0"
    "updateInputMap\0applyInputProfile\0"
    "profile_path\0bootSystem\0"
    "std::shared_ptr<const SystemBootParameters>\0"
    "params\0resumeSystemFromState\0"
    "boot_on_failure\0resumeSystemFromMostRecentState\0"
    "powerOffSystem\0powerOffSystemWithoutSaving\0"
    "synchronousPowerOffSystem\0resetSystem\0"
    "pauseSystem\0wait_until_paused\0changeDisc\0"
    "new_disc_filename\0changeDiscFromPlaylist\0"
    "index\0loadState\0saveState\0block_until_done\0"
    "setAudioOutputVolume\0volume\0"
    "fast_forward_volume\0setAudioOutputMuted\0"
    "muted\0startDumpingAudio\0stopDumpingAudio\0"
    "singleStepCPU\0dumpRAM\0dumpVRAM\0"
    "dumpSPURAM\0saveScreenshot\0redrawDisplayWindow\0"
    "toggleFullscreen\0loadCheatList\0"
    "setCheatEnabled\0enabled\0applyCheat\0"
    "reloadPostProcessingShaders\0"
    "requestRenderWindowScale\0scale\0"
    "executeOnEmulationThread\0std::function<void()>\0"
    "callback\0wait\0OnAchievementsRefreshed\0"
    "doStopThread\0onDisplayWindowMouseMoveEvent\0"
    "x\0y\0onDisplayWindowMouseButtonEvent\0"
    "button\0pressed\0onDisplayWindowMouseWheelEvent\0"
    "delta_angle\0onDisplayWindowResized\0"
    "onDisplayWindowFocused\0onDisplayWindowKeyEvent\0"
    "key\0mods\0doBackgroundControllerPoll\0"
    "doSaveSettings"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtHostInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      73,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      21,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  379,    2, 0x06 /* Public */,
       4,    1,  382,    2, 0x06 /* Public */,
       5,    1,  385,    2, 0x06 /* Public */,
       6,    1,  388,    2, 0x06 /* Public */,
       7,    0,  391,    2, 0x06 /* Public */,
       8,    0,  392,    2, 0x06 /* Public */,
       9,    0,  393,    2, 0x06 /* Public */,
      10,    1,  394,    2, 0x06 /* Public */,
      12,    3,  397,    2, 0x06 /* Public */,
      16,    0,  404,    2, 0x06 /* Public */,
      17,    3,  405,    2, 0x06 /* Public */,
      23,    3,  412,    2, 0x06 /* Public */,
      24,    2,  419,    2, 0x06 /* Public */,
      27,    0,  424,    2, 0x06 /* Public */,
      28,    0,  425,    2, 0x06 /* Public */,
      29,    9,  426,    2, 0x06 /* Public */,
      40,    3,  445,    2, 0x06 /* Public */,
      43,    0,  452,    2, 0x06 /* Public */,
      44,    0,  453,    2, 0x06 /* Public */,
      45,    2,  454,    2, 0x06 /* Public */,
      48,    4,  459,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      53,    1,  468,    2, 0x0a /* Public */,
      55,    1,  471,    2, 0x0a /* Public */,
      56,    1,  474,    2, 0x0a /* Public */,
      57,    1,  477,    2, 0x0a /* Public */,
      58,    0,  480,    2, 0x0a /* Public */,
      59,    1,  481,    2, 0x0a /* Public */,
      59,    0,  484,    2, 0x2a /* Public | MethodCloned */,
      61,    0,  485,    2, 0x0a /* Public */,
      62,    1,  486,    2, 0x0a /* Public */,
      64,    1,  489,    2, 0x0a /* Public */,
      67,    2,  492,    2, 0x0a /* Public */,
      69,    0,  497,    2, 0x0a /* Public */,
      70,    0,  498,    2, 0x0a /* Public */,
      71,    0,  499,    2, 0x0a /* Public */,
      72,    0,  500,    2, 0x0a /* Public */,
      73,    0,  501,    2, 0x0a /* Public */,
      74,    2,  502,    2, 0x0a /* Public */,
      74,    1,  507,    2, 0x2a /* Public | MethodCloned */,
      76,    1,  510,    2, 0x0a /* Public */,
      78,    1,  513,    2, 0x0a /* Public */,
      80,    1,  516,    2, 0x0a /* Public */,
      80,    2,  519,    2, 0x0a /* Public */,
      81,    3,  524,    2, 0x0a /* Public */,
      81,    2,  531,    2, 0x2a /* Public | MethodCloned */,
      83,    2,  536,    2, 0x0a /* Public */,
      86,    1,  541,    2, 0x0a /* Public */,
      88,    0,  544,    2, 0x0a /* Public */,
      89,    0,  545,    2, 0x0a /* Public */,
      90,    0,  546,    2, 0x0a /* Public */,
      91,    1,  547,    2, 0x0a /* Public */,
      92,    1,  550,    2, 0x0a /* Public */,
      93,    1,  553,    2, 0x0a /* Public */,
      94,    0,  556,    2, 0x0a /* Public */,
      95,    0,  557,    2, 0x0a /* Public */,
      96,    0,  558,    2, 0x0a /* Public */,
      97,    1,  559,    2, 0x0a /* Public */,
      98,    2,  562,    2, 0x0a /* Public */,
     100,    1,  567,    2, 0x0a /* Public */,
     101,    0,  570,    2, 0x0a /* Public */,
     102,    1,  571,    2, 0x0a /* Public */,
     104,    2,  574,    2, 0x0a /* Public */,
     104,    1,  579,    2, 0x2a /* Public | MethodCloned */,
     108,    0,  582,    2, 0x0a /* Public */,
     109,    0,  583,    2, 0x08 /* Private */,
     110,    2,  584,    2, 0x08 /* Private */,
     113,    2,  589,    2, 0x08 /* Private */,
     116,    1,  594,    2, 0x08 /* Private */,
     118,    2,  597,    2, 0x08 /* Private */,
     119,    0,  602,    2, 0x08 /* Private */,
     120,    3,  603,    2, 0x08 /* Private */,
     123,    0,  610,    2, 0x08 /* Private */,
     124,    0,  611,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Bool, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool, QMetaType::Int,   13,   14,   15,
    QMetaType::Void,
    0x80000000 | 18, 0x80000000 | 19, QMetaType::Bool, QMetaType::Bool,   20,   21,   22,
    0x80000000 | 18, 0x80000000 | 19, QMetaType::Bool, QMetaType::Bool,   20,   21,   22,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   25,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Float, 0x80000000 | 35, QMetaType::UInt, QMetaType::UInt, QMetaType::Bool,   30,   31,   32,   33,   34,   36,   37,   38,   39,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   41,   13,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   46,   47,
    QMetaType::Void, QMetaType::UInt, QMetaType::QString, QMetaType::UInt, QMetaType::UInt,   49,   50,   51,   52,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 54,    3,
    QMetaType::Void, 0x80000000 | 54,    3,
    QMetaType::Void, 0x80000000 | 54,    3,
    QMetaType::Bool, 0x80000000 | 54,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   60,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   63,
    QMetaType::Void, 0x80000000 | 65,   66,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   41,   68,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   11,   75,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::QString,   77,
    QMetaType::Void, QMetaType::UInt,   79,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int,   14,   15,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int, QMetaType::Bool,   14,   15,   82,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int,   14,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   84,   85,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::UInt, QMetaType::Bool,   79,   99,
    QMetaType::Void, QMetaType::UInt,   79,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,  103,
    QMetaType::Void, 0x80000000 | 105, QMetaType::Bool,  106,  107,
    QMetaType::Void, 0x80000000 | 105,  106,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,  111,  112,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,  114,  115,
    QMetaType::Void, QMetaType::QPoint,  117,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   25,   26,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Bool,  121,  122,  115,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void QtHostInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QtHostInterface *_t = static_cast<QtHostInterface *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->errorReported((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->messageReported((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->debuggerMessageReported((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: { bool _r = _t->messageConfirmed((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->emulationStarting(); break;
        case 5: _t->emulationStarted(); break;
        case 6: _t->emulationStopped(); break;
        case 7: _t->emulationPaused((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->stateSaved((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 9: _t->gameListRefreshed(); break;
        case 10: { QtDisplayWidget* _r = _t->createDisplayRequested((*reinterpret_cast< QThread*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QtDisplayWidget**>(_a[0]) = std::move(_r); }  break;
        case 11: { QtDisplayWidget* _r = _t->updateDisplayRequested((*reinterpret_cast< QThread*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QtDisplayWidget**>(_a[0]) = std::move(_r); }  break;
        case 12: _t->displaySizeRequested((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 13: _t->focusDisplayWidgetRequested(); break;
        case 14: _t->destroyDisplayRequested(); break;
        case 15: _t->systemPerformanceCountersUpdated((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5])),(*reinterpret_cast< GPURenderer(*)>(_a[6])),(*reinterpret_cast< quint32(*)>(_a[7])),(*reinterpret_cast< quint32(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9]))); break;
        case 16: _t->runningGameChanged((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 17: _t->exitRequested(); break;
        case 18: _t->inputProfileLoaded(); break;
        case 19: _t->mouseModeRequested((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 20: _t->achievementsLoaded((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< quint32(*)>(_a[3])),(*reinterpret_cast< quint32(*)>(_a[4]))); break;
        case 21: _t->ReportError((*reinterpret_cast< const char*(*)>(_a[1]))); break;
        case 22: _t->ReportMessage((*reinterpret_cast< const char*(*)>(_a[1]))); break;
        case 23: _t->ReportDebuggerMessage((*reinterpret_cast< const char*(*)>(_a[1]))); break;
        case 24: { bool _r = _t->ConfirmMessage((*reinterpret_cast< const char*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 25: _t->setDefaultSettings(); break;
        case 26: _t->applySettings((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->applySettings(); break;
        case 28: _t->updateInputMap(); break;
        case 29: _t->applyInputProfile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 30: _t->bootSystem((*reinterpret_cast< std::shared_ptr<const SystemBootParameters>(*)>(_a[1]))); break;
        case 31: _t->resumeSystemFromState((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 32: _t->resumeSystemFromMostRecentState(); break;
        case 33: _t->powerOffSystem(); break;
        case 34: _t->powerOffSystemWithoutSaving(); break;
        case 35: _t->synchronousPowerOffSystem(); break;
        case 36: _t->resetSystem(); break;
        case 37: _t->pauseSystem((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 38: _t->pauseSystem((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 39: _t->changeDisc((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 40: _t->changeDiscFromPlaylist((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 41: _t->loadState((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 42: _t->loadState((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 43: _t->saveState((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 44: _t->saveState((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 45: _t->setAudioOutputVolume((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 46: _t->setAudioOutputMuted((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 47: _t->startDumpingAudio(); break;
        case 48: _t->stopDumpingAudio(); break;
        case 49: _t->singleStepCPU(); break;
        case 50: _t->dumpRAM((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 51: _t->dumpVRAM((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 52: _t->dumpSPURAM((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 53: _t->saveScreenshot(); break;
        case 54: _t->redrawDisplayWindow(); break;
        case 55: _t->toggleFullscreen(); break;
        case 56: _t->loadCheatList((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 57: _t->setCheatEnabled((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 58: _t->applyCheat((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 59: _t->reloadPostProcessingShaders(); break;
        case 60: _t->requestRenderWindowScale((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 61: _t->executeOnEmulationThread((*reinterpret_cast< std::function<void()>(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 62: _t->executeOnEmulationThread((*reinterpret_cast< std::function<void()>(*)>(_a[1]))); break;
        case 63: _t->OnAchievementsRefreshed(); break;
        case 64: _t->doStopThread(); break;
        case 65: _t->onDisplayWindowMouseMoveEvent((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 66: _t->onDisplayWindowMouseButtonEvent((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 67: _t->onDisplayWindowMouseWheelEvent((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 68: _t->onDisplayWindowResized((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 69: _t->onDisplayWindowFocused(); break;
        case 70: _t->onDisplayWindowKeyEvent((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 71: _t->doBackgroundControllerPoll(); break;
        case 72: _t->doSaveSettings(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QThread* >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QThread* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 5:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< GPURenderer >(); break;
            }
            break;
        case 30:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< std::shared_ptr<const SystemBootParameters> >(); break;
            }
            break;
        case 61:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< std::function<void()> >(); break;
            }
            break;
        case 62:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< std::function<void()> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QtHostInterface::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::errorReported)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::messageReported)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::debuggerMessageReported)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = bool (QtHostInterface::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::messageConfirmed)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::emulationStarting)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::emulationStarted)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::emulationStopped)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::emulationPaused)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(const QString & , bool , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::stateSaved)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::gameListRefreshed)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = QtDisplayWidget * (QtHostInterface::*)(QThread * , bool , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::createDisplayRequested)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = QtDisplayWidget * (QtHostInterface::*)(QThread * , bool , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::updateDisplayRequested)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::displaySizeRequested)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::focusDisplayWidgetRequested)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::destroyDisplayRequested)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(float , float , float , float , float , GPURenderer , quint32 , quint32 , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::systemPerformanceCountersUpdated)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(const QString & , const QString & , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::runningGameChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::exitRequested)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::inputProfileLoaded)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(bool , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::mouseModeRequested)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (QtHostInterface::*)(quint32 , const QString & , quint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtHostInterface::achievementsLoaded)) {
                *result = 20;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject QtHostInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QtHostInterface.data,
      qt_meta_data_QtHostInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QtHostInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtHostInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtHostInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "CommonHostInterface"))
        return static_cast< CommonHostInterface*>(this);
    return QObject::qt_metacast(_clname);
}

int QtHostInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 73)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 73;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 73)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 73;
    }
    return _id;
}

// SIGNAL 0
void QtHostInterface::errorReported(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtHostInterface::messageReported(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QtHostInterface::debuggerMessageReported(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
bool QtHostInterface::messageConfirmed(const QString & _t1)
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)), const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
    return _t0;
}

// SIGNAL 4
void QtHostInterface::emulationStarting()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QtHostInterface::emulationStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QtHostInterface::emulationStopped()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QtHostInterface::emulationPaused(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QtHostInterface::stateSaved(const QString & _t1, bool _t2, qint32 _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QtHostInterface::gameListRefreshed()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
QtDisplayWidget * QtHostInterface::createDisplayRequested(QThread * _t1, bool _t2, bool _t3)
{
    QtDisplayWidget* _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)), const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
    return _t0;
}

// SIGNAL 11
QtDisplayWidget * QtHostInterface::updateDisplayRequested(QThread * _t1, bool _t2, bool _t3)
{
    QtDisplayWidget* _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)), const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
    return _t0;
}

// SIGNAL 12
void QtHostInterface::displaySizeRequested(qint32 _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void QtHostInterface::focusDisplayWidgetRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QtHostInterface::destroyDisplayRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QtHostInterface::systemPerformanceCountersUpdated(float _t1, float _t2, float _t3, float _t4, float _t5, GPURenderer _t6, quint32 _t7, quint32 _t8, bool _t9)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)), const_cast<void*>(reinterpret_cast<const void*>(&_t6)), const_cast<void*>(reinterpret_cast<const void*>(&_t7)), const_cast<void*>(reinterpret_cast<const void*>(&_t8)), const_cast<void*>(reinterpret_cast<const void*>(&_t9)) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void QtHostInterface::runningGameChanged(const QString & _t1, const QString & _t2, const QString & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void QtHostInterface::exitRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void QtHostInterface::inputProfileLoaded()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void QtHostInterface::mouseModeRequested(bool _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void QtHostInterface::achievementsLoaded(quint32 _t1, const QString & _t2, quint32 _t3, quint32 _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
