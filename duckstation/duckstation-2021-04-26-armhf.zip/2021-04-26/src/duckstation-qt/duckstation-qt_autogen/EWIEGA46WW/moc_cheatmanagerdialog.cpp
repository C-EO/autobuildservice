/****************************************************************************
** Meta object code from reading C++ file 'cheatmanagerdialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "duckstation-qt/cheatmanagerdialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'cheatmanagerdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CheatManagerDialog_t {
    QByteArrayData data[39];
    char stringdata0[613];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CheatManagerDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CheatManagerDialog_t qt_meta_stringdata_CheatManagerDialog = {
    {
QT_MOC_LITERAL(0, 0, 18), // "CheatManagerDialog"
QT_MOC_LITERAL(1, 19, 13), // "resizeColumns"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 12), // "getCheatList"
QT_MOC_LITERAL(4, 47, 10), // "CheatList*"
QT_MOC_LITERAL(5, 58, 15), // "updateCheatList"
QT_MOC_LITERAL(6, 74, 13), // "saveCheatList"
QT_MOC_LITERAL(7, 88, 27), // "cheatListCurrentItemChanged"
QT_MOC_LITERAL(8, 116, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(9, 133, 7), // "current"
QT_MOC_LITERAL(10, 141, 8), // "previous"
QT_MOC_LITERAL(11, 150, 22), // "cheatListItemActivated"
QT_MOC_LITERAL(12, 173, 4), // "item"
QT_MOC_LITERAL(13, 178, 20), // "cheatListItemChanged"
QT_MOC_LITERAL(14, 199, 6), // "column"
QT_MOC_LITERAL(15, 206, 13), // "activateCheat"
QT_MOC_LITERAL(16, 220, 3), // "u32"
QT_MOC_LITERAL(17, 224, 5), // "index"
QT_MOC_LITERAL(18, 230, 18), // "newCategoryClicked"
QT_MOC_LITERAL(19, 249, 14), // "addCodeClicked"
QT_MOC_LITERAL(20, 264, 15), // "editCodeClicked"
QT_MOC_LITERAL(21, 280, 17), // "deleteCodeClicked"
QT_MOC_LITERAL(22, 298, 19), // "activateCodeClicked"
QT_MOC_LITERAL(23, 318, 13), // "importClicked"
QT_MOC_LITERAL(24, 332, 23), // "importFromFileTriggered"
QT_MOC_LITERAL(25, 356, 23), // "importFromTextTriggered"
QT_MOC_LITERAL(26, 380, 13), // "exportClicked"
QT_MOC_LITERAL(27, 394, 12), // "clearClicked"
QT_MOC_LITERAL(28, 407, 12), // "resetClicked"
QT_MOC_LITERAL(29, 420, 17), // "addToWatchClicked"
QT_MOC_LITERAL(30, 438, 28), // "addManualWatchAddressClicked"
QT_MOC_LITERAL(31, 467, 18), // "removeWatchClicked"
QT_MOC_LITERAL(32, 486, 22), // "scanCurrentItemChanged"
QT_MOC_LITERAL(33, 509, 17), // "QTableWidgetItem*"
QT_MOC_LITERAL(34, 527, 23), // "watchCurrentItemChanged"
QT_MOC_LITERAL(35, 551, 15), // "scanItemChanged"
QT_MOC_LITERAL(36, 567, 16), // "watchItemChanged"
QT_MOC_LITERAL(37, 584, 15), // "updateScanValue"
QT_MOC_LITERAL(38, 600, 12) // "updateScanUi"

    },
    "CheatManagerDialog\0resizeColumns\0\0"
    "getCheatList\0CheatList*\0updateCheatList\0"
    "saveCheatList\0cheatListCurrentItemChanged\0"
    "QTreeWidgetItem*\0current\0previous\0"
    "cheatListItemActivated\0item\0"
    "cheatListItemChanged\0column\0activateCheat\0"
    "u32\0index\0newCategoryClicked\0"
    "addCodeClicked\0editCodeClicked\0"
    "deleteCodeClicked\0activateCodeClicked\0"
    "importClicked\0importFromFileTriggered\0"
    "importFromTextTriggered\0exportClicked\0"
    "clearClicked\0resetClicked\0addToWatchClicked\0"
    "addManualWatchAddressClicked\0"
    "removeWatchClicked\0scanCurrentItemChanged\0"
    "QTableWidgetItem*\0watchCurrentItemChanged\0"
    "scanItemChanged\0watchItemChanged\0"
    "updateScanValue\0updateScanUi"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CheatManagerDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x08 /* Private */,
       3,    0,  155,    2, 0x08 /* Private */,
       5,    0,  156,    2, 0x08 /* Private */,
       6,    0,  157,    2, 0x08 /* Private */,
       7,    2,  158,    2, 0x08 /* Private */,
      11,    1,  163,    2, 0x08 /* Private */,
      13,    2,  166,    2, 0x08 /* Private */,
      15,    1,  171,    2, 0x08 /* Private */,
      18,    0,  174,    2, 0x08 /* Private */,
      19,    0,  175,    2, 0x08 /* Private */,
      20,    0,  176,    2, 0x08 /* Private */,
      21,    0,  177,    2, 0x08 /* Private */,
      22,    0,  178,    2, 0x08 /* Private */,
      23,    0,  179,    2, 0x08 /* Private */,
      24,    0,  180,    2, 0x08 /* Private */,
      25,    0,  181,    2, 0x08 /* Private */,
      26,    0,  182,    2, 0x08 /* Private */,
      27,    0,  183,    2, 0x08 /* Private */,
      28,    0,  184,    2, 0x08 /* Private */,
      29,    0,  185,    2, 0x08 /* Private */,
      30,    0,  186,    2, 0x08 /* Private */,
      31,    0,  187,    2, 0x08 /* Private */,
      32,    2,  188,    2, 0x08 /* Private */,
      34,    2,  193,    2, 0x08 /* Private */,
      35,    1,  198,    2, 0x08 /* Private */,
      36,    1,  201,    2, 0x08 /* Private */,
      37,    0,  204,    2, 0x08 /* Private */,
      38,    0,  205,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    0x80000000 | 4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 8,    9,   10,
    QMetaType::Void, 0x80000000 | 8,   12,
    QMetaType::Void, 0x80000000 | 8, QMetaType::Int,   12,   14,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 33, 0x80000000 | 33,    9,   10,
    QMetaType::Void, 0x80000000 | 33, 0x80000000 | 33,    9,   10,
    QMetaType::Void, 0x80000000 | 33,   12,
    QMetaType::Void, 0x80000000 | 33,   12,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CheatManagerDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CheatManagerDialog *_t = static_cast<CheatManagerDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->resizeColumns(); break;
        case 1: { CheatList* _r = _t->getCheatList();
            if (_a[0]) *reinterpret_cast< CheatList**>(_a[0]) = std::move(_r); }  break;
        case 2: _t->updateCheatList(); break;
        case 3: _t->saveCheatList(); break;
        case 4: _t->cheatListCurrentItemChanged((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QTreeWidgetItem*(*)>(_a[2]))); break;
        case 5: _t->cheatListItemActivated((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1]))); break;
        case 6: _t->cheatListItemChanged((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->activateCheat((*reinterpret_cast< u32(*)>(_a[1]))); break;
        case 8: _t->newCategoryClicked(); break;
        case 9: _t->addCodeClicked(); break;
        case 10: _t->editCodeClicked(); break;
        case 11: _t->deleteCodeClicked(); break;
        case 12: _t->activateCodeClicked(); break;
        case 13: _t->importClicked(); break;
        case 14: _t->importFromFileTriggered(); break;
        case 15: _t->importFromTextTriggered(); break;
        case 16: _t->exportClicked(); break;
        case 17: _t->clearClicked(); break;
        case 18: _t->resetClicked(); break;
        case 19: _t->addToWatchClicked(); break;
        case 20: _t->addManualWatchAddressClicked(); break;
        case 21: _t->removeWatchClicked(); break;
        case 22: _t->scanCurrentItemChanged((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QTableWidgetItem*(*)>(_a[2]))); break;
        case 23: _t->watchCurrentItemChanged((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QTableWidgetItem*(*)>(_a[2]))); break;
        case 24: _t->scanItemChanged((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1]))); break;
        case 25: _t->watchItemChanged((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1]))); break;
        case 26: _t->updateScanValue(); break;
        case 27: _t->updateScanUi(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CheatManagerDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_CheatManagerDialog.data,
      qt_meta_data_CheatManagerDialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *CheatManagerDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CheatManagerDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CheatManagerDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int CheatManagerDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
