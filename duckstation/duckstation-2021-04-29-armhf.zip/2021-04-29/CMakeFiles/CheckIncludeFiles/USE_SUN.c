/* */
#include <sys/audioio.h>


int main(void){return 0;}

