/********************************************************************************
** Form generated from reading UI file 'cheatmanagerdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHEATMANAGERDIALOG_H
#define UI_CHEATMANAGERDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CheatManagerDialog
{
public:
    QGridLayout *gridLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *cheatListNewCategory;
    QPushButton *cheatListAdd;
    QPushButton *cheatListEdit;
    QPushButton *cheatListRemove;
    QPushButton *cheatListActivate;
    QPushButton *cheatListImport;
    QPushButton *cheatListExport;
    QPushButton *cheatListClear;
    QPushButton *cheatListReset;
    QSpacerItem *horizontalSpacer;
    QTreeWidget *cheatList;
    QWidget *tab_2;
    QGridLayout *gridLayout_3;
    QSplitter *splitter;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_5;
    QTableWidget *scanTable;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *scanValue;
    QComboBox *scanValueSigned;
    QComboBox *scanValueBase;
    QLabel *label_3;
    QComboBox *scanSize;
    QLabel *label_2;
    QComboBox *scanOperator;
    QLabel *label_4;
    QLineEdit *scanStartAddress;
    QLabel *label_5;
    QLineEdit *scanEndAddress;
    QLabel *label_6;
    QComboBox *scanPresetRange;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *scanNewSearch;
    QPushButton *scanSearchAgain;
    QPushButton *scanResetSearch;
    QSpacerItem *verticalSpacer;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QTableWidget *watchTable;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *scanAddWatch;
    QPushButton *scanAddManualAddress;
    QPushButton *scanRemoveWatch;
    QPushButton *scanLoadWatch;
    QPushButton *scanSaveWatch;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QDialog *CheatManagerDialog)
    {
        if (CheatManagerDialog->objectName().isEmpty())
            CheatManagerDialog->setObjectName(QStringLiteral("CheatManagerDialog"));
        CheatManagerDialog->resize(864, 599);
        gridLayout = new QGridLayout(CheatManagerDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        tabWidget = new QTabWidget(CheatManagerDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout_2 = new QGridLayout(tab);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        cheatListNewCategory = new QPushButton(tab);
        cheatListNewCategory->setObjectName(QStringLiteral("cheatListNewCategory"));

        horizontalLayout->addWidget(cheatListNewCategory);

        cheatListAdd = new QPushButton(tab);
        cheatListAdd->setObjectName(QStringLiteral("cheatListAdd"));

        horizontalLayout->addWidget(cheatListAdd);

        cheatListEdit = new QPushButton(tab);
        cheatListEdit->setObjectName(QStringLiteral("cheatListEdit"));

        horizontalLayout->addWidget(cheatListEdit);

        cheatListRemove = new QPushButton(tab);
        cheatListRemove->setObjectName(QStringLiteral("cheatListRemove"));
        cheatListRemove->setEnabled(false);

        horizontalLayout->addWidget(cheatListRemove);

        cheatListActivate = new QPushButton(tab);
        cheatListActivate->setObjectName(QStringLiteral("cheatListActivate"));
        cheatListActivate->setEnabled(false);

        horizontalLayout->addWidget(cheatListActivate);

        cheatListImport = new QPushButton(tab);
        cheatListImport->setObjectName(QStringLiteral("cheatListImport"));

        horizontalLayout->addWidget(cheatListImport);

        cheatListExport = new QPushButton(tab);
        cheatListExport->setObjectName(QStringLiteral("cheatListExport"));
        cheatListExport->setEnabled(false);

        horizontalLayout->addWidget(cheatListExport);

        cheatListClear = new QPushButton(tab);
        cheatListClear->setObjectName(QStringLiteral("cheatListClear"));

        horizontalLayout->addWidget(cheatListClear);

        cheatListReset = new QPushButton(tab);
        cheatListReset->setObjectName(QStringLiteral("cheatListReset"));

        horizontalLayout->addWidget(cheatListReset);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        gridLayout_2->addLayout(horizontalLayout, 1, 0, 1, 1);

        cheatList = new QTreeWidget(tab);
        cheatList->setObjectName(QStringLiteral("cheatList"));
        cheatList->setSelectionMode(QAbstractItemView::SingleSelection);
        cheatList->setSelectionBehavior(QAbstractItemView::SelectRows);

        gridLayout_2->addWidget(cheatList, 0, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayout_3 = new QGridLayout(tab_2);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        splitter = new QSplitter(tab_2);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Vertical);
        layoutWidget2 = new QWidget(splitter);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        scanTable = new QTableWidget(layoutWidget2);
        if (scanTable->columnCount() < 3)
            scanTable->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        scanTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        scanTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        scanTable->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        scanTable->setObjectName(QStringLiteral("scanTable"));
        scanTable->setAlternatingRowColors(true);
        scanTable->setSelectionMode(QAbstractItemView::SingleSelection);
        scanTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        scanTable->setShowGrid(false);
        scanTable->horizontalHeader()->setHighlightSections(false);
        scanTable->verticalHeader()->setVisible(false);

        horizontalLayout_5->addWidget(scanTable);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        groupBox_2 = new QGroupBox(layoutWidget2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        formLayout = new QFormLayout(groupBox_2);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        scanValue = new QLineEdit(groupBox_2);
        scanValue->setObjectName(QStringLiteral("scanValue"));

        horizontalLayout_2->addWidget(scanValue);

        scanValueSigned = new QComboBox(groupBox_2);
        scanValueSigned->addItem(QString());
        scanValueSigned->addItem(QString());
        scanValueSigned->setObjectName(QStringLiteral("scanValueSigned"));

        horizontalLayout_2->addWidget(scanValueSigned);

        scanValueBase = new QComboBox(groupBox_2);
        scanValueBase->addItem(QString());
        scanValueBase->addItem(QString());
        scanValueBase->setObjectName(QStringLiteral("scanValueBase"));

        horizontalLayout_2->addWidget(scanValueBase);


        formLayout->setLayout(0, QFormLayout::FieldRole, horizontalLayout_2);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        scanSize = new QComboBox(groupBox_2);
        scanSize->addItem(QString());
        scanSize->addItem(QString());
        scanSize->addItem(QString());
        scanSize->setObjectName(QStringLiteral("scanSize"));

        formLayout->setWidget(2, QFormLayout::FieldRole, scanSize);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_2);

        scanOperator = new QComboBox(groupBox_2);
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->addItem(QString());
        scanOperator->setObjectName(QStringLiteral("scanOperator"));

        formLayout->setWidget(4, QFormLayout::FieldRole, scanOperator);

        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(5, QFormLayout::LabelRole, label_4);

        scanStartAddress = new QLineEdit(groupBox_2);
        scanStartAddress->setObjectName(QStringLiteral("scanStartAddress"));

        formLayout->setWidget(5, QFormLayout::FieldRole, scanStartAddress);

        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(6, QFormLayout::LabelRole, label_5);

        scanEndAddress = new QLineEdit(groupBox_2);
        scanEndAddress->setObjectName(QStringLiteral("scanEndAddress"));

        formLayout->setWidget(6, QFormLayout::FieldRole, scanEndAddress);

        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout->setWidget(7, QFormLayout::LabelRole, label_6);

        scanPresetRange = new QComboBox(groupBox_2);
        scanPresetRange->addItem(QString());
        scanPresetRange->addItem(QString());
        scanPresetRange->addItem(QString());
        scanPresetRange->setObjectName(QStringLiteral("scanPresetRange"));

        formLayout->setWidget(7, QFormLayout::FieldRole, scanPresetRange);


        verticalLayout->addWidget(groupBox_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        scanNewSearch = new QPushButton(layoutWidget2);
        scanNewSearch->setObjectName(QStringLiteral("scanNewSearch"));

        horizontalLayout_3->addWidget(scanNewSearch);

        scanSearchAgain = new QPushButton(layoutWidget2);
        scanSearchAgain->setObjectName(QStringLiteral("scanSearchAgain"));
        scanSearchAgain->setEnabled(false);

        horizontalLayout_3->addWidget(scanSearchAgain);

        scanResetSearch = new QPushButton(layoutWidget2);
        scanResetSearch->setObjectName(QStringLiteral("scanResetSearch"));
        scanResetSearch->setEnabled(false);

        horizontalLayout_3->addWidget(scanResetSearch);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout_5->addLayout(verticalLayout);

        splitter->addWidget(layoutWidget2);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        watchTable = new QTableWidget(layoutWidget);
        if (watchTable->columnCount() < 5)
            watchTable->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        watchTable->setHorizontalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        watchTable->setHorizontalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        watchTable->setHorizontalHeaderItem(2, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        watchTable->setHorizontalHeaderItem(3, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        watchTable->setHorizontalHeaderItem(4, __qtablewidgetitem7);
        watchTable->setObjectName(QStringLiteral("watchTable"));
        watchTable->setAlternatingRowColors(true);
        watchTable->setSelectionMode(QAbstractItemView::SingleSelection);
        watchTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        watchTable->setShowGrid(false);
        watchTable->horizontalHeader()->setHighlightSections(false);
        watchTable->verticalHeader()->setVisible(false);

        verticalLayout_2->addWidget(watchTable);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        scanAddWatch = new QPushButton(layoutWidget);
        scanAddWatch->setObjectName(QStringLiteral("scanAddWatch"));
        scanAddWatch->setEnabled(false);

        horizontalLayout_4->addWidget(scanAddWatch);

        scanAddManualAddress = new QPushButton(layoutWidget);
        scanAddManualAddress->setObjectName(QStringLiteral("scanAddManualAddress"));

        horizontalLayout_4->addWidget(scanAddManualAddress);

        scanRemoveWatch = new QPushButton(layoutWidget);
        scanRemoveWatch->setObjectName(QStringLiteral("scanRemoveWatch"));
        scanRemoveWatch->setEnabled(false);

        horizontalLayout_4->addWidget(scanRemoveWatch);

        scanLoadWatch = new QPushButton(layoutWidget);
        scanLoadWatch->setObjectName(QStringLiteral("scanLoadWatch"));
        scanLoadWatch->setEnabled(false);

        horizontalLayout_4->addWidget(scanLoadWatch);

        scanSaveWatch = new QPushButton(layoutWidget);
        scanSaveWatch->setObjectName(QStringLiteral("scanSaveWatch"));
        scanSaveWatch->setEnabled(false);

        horizontalLayout_4->addWidget(scanSaveWatch);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_4);

        splitter->addWidget(layoutWidget);

        gridLayout_3->addWidget(splitter, 0, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());

        gridLayout->addWidget(tabWidget, 0, 0, 1, 1);


        retranslateUi(CheatManagerDialog);

        tabWidget->setCurrentIndex(0);
        scanValueSigned->setCurrentIndex(1);
        scanValueBase->setCurrentIndex(1);
        scanSize->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(CheatManagerDialog);
    } // setupUi

    void retranslateUi(QDialog *CheatManagerDialog)
    {
        CheatManagerDialog->setWindowTitle(QApplication::translate("CheatManagerDialog", "Cheat Manager", nullptr));
        cheatListNewCategory->setText(QApplication::translate("CheatManagerDialog", "&Add Group...", nullptr));
        cheatListAdd->setText(QApplication::translate("CheatManagerDialog", "&Add Code...", nullptr));
        cheatListEdit->setText(QApplication::translate("CheatManagerDialog", "&Edit Code...", nullptr));
        cheatListRemove->setText(QApplication::translate("CheatManagerDialog", "&Delete Code", nullptr));
        cheatListActivate->setText(QApplication::translate("CheatManagerDialog", "Activate", nullptr));
        cheatListImport->setText(QApplication::translate("CheatManagerDialog", "Import...", nullptr));
        cheatListExport->setText(QApplication::translate("CheatManagerDialog", "Export...", nullptr));
        cheatListClear->setText(QApplication::translate("CheatManagerDialog", "Clear", nullptr));
        cheatListReset->setText(QApplication::translate("CheatManagerDialog", "Reset", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = cheatList->headerItem();
        ___qtreewidgetitem->setText(3, QApplication::translate("CheatManagerDialog", "Instructions", nullptr));
        ___qtreewidgetitem->setText(2, QApplication::translate("CheatManagerDialog", "Activation", nullptr));
        ___qtreewidgetitem->setText(1, QApplication::translate("CheatManagerDialog", "Type", nullptr));
        ___qtreewidgetitem->setText(0, QApplication::translate("CheatManagerDialog", "Name", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("CheatManagerDialog", "Cheat List", nullptr));
        QTableWidgetItem *___qtablewidgetitem = scanTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("CheatManagerDialog", "Address", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = scanTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("CheatManagerDialog", "Value", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = scanTable->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("CheatManagerDialog", "Previous Value", nullptr));
        groupBox_2->setTitle(QApplication::translate("CheatManagerDialog", "Search Parameters", nullptr));
        label->setText(QApplication::translate("CheatManagerDialog", "Value:", nullptr));
        scanValueSigned->setItemText(0, QApplication::translate("CheatManagerDialog", "Signed", nullptr));
        scanValueSigned->setItemText(1, QApplication::translate("CheatManagerDialog", "Unsigned", nullptr));

        scanValueBase->setItemText(0, QApplication::translate("CheatManagerDialog", "Decimal", nullptr));
        scanValueBase->setItemText(1, QApplication::translate("CheatManagerDialog", "Hex", nullptr));

        label_3->setText(QApplication::translate("CheatManagerDialog", "Data Size:", nullptr));
        scanSize->setItemText(0, QApplication::translate("CheatManagerDialog", "Byte (1 byte)", nullptr));
        scanSize->setItemText(1, QApplication::translate("CheatManagerDialog", "Halfword (2 bytes)", nullptr));
        scanSize->setItemText(2, QApplication::translate("CheatManagerDialog", "Word (4 bytes)", nullptr));

        label_2->setText(QApplication::translate("CheatManagerDialog", "Operator:", nullptr));
        scanOperator->setItemText(0, QApplication::translate("CheatManagerDialog", "Equal to...", nullptr));
        scanOperator->setItemText(1, QApplication::translate("CheatManagerDialog", "Not Equal to...", nullptr));
        scanOperator->setItemText(2, QApplication::translate("CheatManagerDialog", "Greater Than...", nullptr));
        scanOperator->setItemText(3, QApplication::translate("CheatManagerDialog", "Greater or Equal...", nullptr));
        scanOperator->setItemText(4, QApplication::translate("CheatManagerDialog", "Less Than...", nullptr));
        scanOperator->setItemText(5, QApplication::translate("CheatManagerDialog", "Less or Equal...", nullptr));
        scanOperator->setItemText(6, QApplication::translate("CheatManagerDialog", "Increased By...", nullptr));
        scanOperator->setItemText(7, QApplication::translate("CheatManagerDialog", "Decreased By...", nullptr));
        scanOperator->setItemText(8, QApplication::translate("CheatManagerDialog", "Changed By...", nullptr));
        scanOperator->setItemText(9, QApplication::translate("CheatManagerDialog", "Equal to Previous (Unchanged Value)", nullptr));
        scanOperator->setItemText(10, QApplication::translate("CheatManagerDialog", "Not Equal to Previous (Changed Value)", nullptr));
        scanOperator->setItemText(11, QApplication::translate("CheatManagerDialog", "Greater Than Previous", nullptr));
        scanOperator->setItemText(12, QApplication::translate("CheatManagerDialog", "Greater or Equal to Previous", nullptr));
        scanOperator->setItemText(13, QApplication::translate("CheatManagerDialog", "Less Than Previous", nullptr));
        scanOperator->setItemText(14, QApplication::translate("CheatManagerDialog", "Less or Equal to Previous", nullptr));
        scanOperator->setItemText(15, QApplication::translate("CheatManagerDialog", "Any Value", nullptr));

        label_4->setText(QApplication::translate("CheatManagerDialog", "Start Address:", nullptr));
        label_5->setText(QApplication::translate("CheatManagerDialog", "End Address:", nullptr));
        label_6->setText(QApplication::translate("CheatManagerDialog", "Preset Range:", nullptr));
        scanPresetRange->setItemText(0, QApplication::translate("CheatManagerDialog", "RAM", nullptr));
        scanPresetRange->setItemText(1, QApplication::translate("CheatManagerDialog", "Scratchpad", nullptr));
        scanPresetRange->setItemText(2, QApplication::translate("CheatManagerDialog", "BIOS", nullptr));

        scanNewSearch->setText(QApplication::translate("CheatManagerDialog", "New Search", nullptr));
        scanSearchAgain->setText(QApplication::translate("CheatManagerDialog", "Search Again", nullptr));
        scanResetSearch->setText(QApplication::translate("CheatManagerDialog", "Clear Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = watchTable->horizontalHeaderItem(0);
        ___qtablewidgetitem3->setText(QApplication::translate("CheatManagerDialog", "Freeze", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = watchTable->horizontalHeaderItem(1);
        ___qtablewidgetitem4->setText(QApplication::translate("CheatManagerDialog", "Description", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = watchTable->horizontalHeaderItem(2);
        ___qtablewidgetitem5->setText(QApplication::translate("CheatManagerDialog", "Address", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = watchTable->horizontalHeaderItem(3);
        ___qtablewidgetitem6->setText(QApplication::translate("CheatManagerDialog", "Type", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = watchTable->horizontalHeaderItem(4);
        ___qtablewidgetitem7->setText(QApplication::translate("CheatManagerDialog", "Value", nullptr));
        scanAddWatch->setText(QApplication::translate("CheatManagerDialog", "Add To Watch", nullptr));
        scanAddManualAddress->setText(QApplication::translate("CheatManagerDialog", "Add Manual Address", nullptr));
        scanRemoveWatch->setText(QApplication::translate("CheatManagerDialog", "Remove Watch", nullptr));
        scanLoadWatch->setText(QApplication::translate("CheatManagerDialog", "Load Watch", nullptr));
        scanSaveWatch->setText(QApplication::translate("CheatManagerDialog", "Save Watch", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("CheatManagerDialog", "Memory Scanner", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CheatManagerDialog: public Ui_CheatManagerDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHEATMANAGERDIALOG_H
