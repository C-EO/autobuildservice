/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "duckstation-qt/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[88];
    char stringdata0[1647];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 25), // "updateDebugMenuVisibility"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 15), // "checkForUpdates"
QT_MOC_LITERAL(4, 54, 15), // "display_message"
QT_MOC_LITERAL(5, 70, 11), // "reportError"
QT_MOC_LITERAL(6, 82, 7), // "message"
QT_MOC_LITERAL(7, 90, 13), // "reportMessage"
QT_MOC_LITERAL(8, 104, 14), // "confirmMessage"
QT_MOC_LITERAL(9, 119, 13), // "createDisplay"
QT_MOC_LITERAL(10, 133, 16), // "QtDisplayWidget*"
QT_MOC_LITERAL(11, 150, 8), // "QThread*"
QT_MOC_LITERAL(12, 159, 13), // "worker_thread"
QT_MOC_LITERAL(13, 173, 10), // "fullscreen"
QT_MOC_LITERAL(14, 184, 14), // "render_to_main"
QT_MOC_LITERAL(15, 199, 13), // "updateDisplay"
QT_MOC_LITERAL(16, 213, 20), // "displaySizeRequested"
QT_MOC_LITERAL(17, 234, 5), // "width"
QT_MOC_LITERAL(18, 240, 6), // "height"
QT_MOC_LITERAL(19, 247, 14), // "destroyDisplay"
QT_MOC_LITERAL(20, 262, 18), // "focusDisplayWidget"
QT_MOC_LITERAL(21, 281, 20), // "onMouseModeRequested"
QT_MOC_LITERAL(22, 302, 13), // "relative_mode"
QT_MOC_LITERAL(23, 316, 11), // "hide_cursor"
QT_MOC_LITERAL(24, 328, 15), // "updateMouseMode"
QT_MOC_LITERAL(25, 344, 6), // "paused"
QT_MOC_LITERAL(26, 351, 8), // "setTheme"
QT_MOC_LITERAL(27, 360, 5), // "theme"
QT_MOC_LITERAL(28, 366, 11), // "updateTheme"
QT_MOC_LITERAL(29, 378, 19), // "onEmulationStarting"
QT_MOC_LITERAL(30, 398, 18), // "onEmulationStarted"
QT_MOC_LITERAL(31, 417, 18), // "onEmulationStopped"
QT_MOC_LITERAL(32, 436, 17), // "onEmulationPaused"
QT_MOC_LITERAL(33, 454, 12), // "onStateSaved"
QT_MOC_LITERAL(34, 467, 9), // "game_code"
QT_MOC_LITERAL(35, 477, 6), // "global"
QT_MOC_LITERAL(36, 484, 4), // "slot"
QT_MOC_LITERAL(37, 489, 34), // "onSystemPerformanceCountersUp..."
QT_MOC_LITERAL(38, 524, 5), // "speed"
QT_MOC_LITERAL(39, 530, 3), // "fps"
QT_MOC_LITERAL(40, 534, 3), // "vps"
QT_MOC_LITERAL(41, 538, 18), // "average_frame_time"
QT_MOC_LITERAL(42, 557, 16), // "worst_frame_time"
QT_MOC_LITERAL(43, 574, 11), // "GPURenderer"
QT_MOC_LITERAL(44, 586, 8), // "renderer"
QT_MOC_LITERAL(45, 595, 12), // "render_width"
QT_MOC_LITERAL(46, 608, 13), // "render_height"
QT_MOC_LITERAL(47, 622, 17), // "render_interlaced"
QT_MOC_LITERAL(48, 640, 20), // "onRunningGameChanged"
QT_MOC_LITERAL(49, 661, 8), // "filename"
QT_MOC_LITERAL(50, 670, 10), // "game_title"
QT_MOC_LITERAL(51, 681, 25), // "onApplicationStateChanged"
QT_MOC_LITERAL(52, 707, 20), // "Qt::ApplicationState"
QT_MOC_LITERAL(53, 728, 5), // "state"
QT_MOC_LITERAL(54, 734, 26), // "onStartDiscActionTriggered"
QT_MOC_LITERAL(55, 761, 26), // "onStartBIOSActionTriggered"
QT_MOC_LITERAL(56, 788, 35), // "onChangeDiscFromFileActionTri..."
QT_MOC_LITERAL(57, 824, 39), // "onChangeDiscFromGameListActio..."
QT_MOC_LITERAL(58, 864, 27), // "onChangeDiscMenuAboutToShow"
QT_MOC_LITERAL(59, 892, 27), // "onChangeDiscMenuAboutToHide"
QT_MOC_LITERAL(60, 920, 23), // "onCheatsMenuAboutToShow"
QT_MOC_LITERAL(61, 944, 27), // "onRemoveDiscActionTriggered"
QT_MOC_LITERAL(62, 972, 26), // "onViewToolbarActionToggled"
QT_MOC_LITERAL(63, 999, 7), // "checked"
QT_MOC_LITERAL(64, 1007, 30), // "onViewLockToolbarActionToggled"
QT_MOC_LITERAL(65, 1038, 28), // "onViewStatusBarActionToggled"
QT_MOC_LITERAL(66, 1067, 29), // "onViewGameListActionTriggered"
QT_MOC_LITERAL(67, 1097, 29), // "onViewGameGridActionTriggered"
QT_MOC_LITERAL(68, 1127, 28), // "onViewSystemDisplayTriggered"
QT_MOC_LITERAL(69, 1156, 35), // "onViewGamePropertiesActionTri..."
QT_MOC_LITERAL(70, 1192, 33), // "onGitHubRepositoryActionTrigg..."
QT_MOC_LITERAL(71, 1226, 29), // "onIssueTrackerActionTriggered"
QT_MOC_LITERAL(72, 1256, 30), // "onDiscordServerActionTriggered"
QT_MOC_LITERAL(73, 1287, 22), // "onAboutActionTriggered"
QT_MOC_LITERAL(74, 1310, 32), // "onCheckForUpdatesActionTriggered"
QT_MOC_LITERAL(75, 1343, 32), // "onToolsMemoryCardEditorTriggered"
QT_MOC_LITERAL(76, 1376, 28), // "onToolsCheatManagerTriggered"
QT_MOC_LITERAL(77, 1405, 33), // "onToolsOpenDataDirectoryTrigg..."
QT_MOC_LITERAL(78, 1439, 23), // "onGameListEntrySelected"
QT_MOC_LITERAL(79, 1463, 20), // "const GameListEntry*"
QT_MOC_LITERAL(80, 1484, 5), // "entry"
QT_MOC_LITERAL(81, 1490, 28), // "onGameListEntryDoubleClicked"
QT_MOC_LITERAL(82, 1519, 30), // "onGameListContextMenuRequested"
QT_MOC_LITERAL(83, 1550, 5), // "point"
QT_MOC_LITERAL(84, 1556, 32), // "onGameListSetCoverImageRequested"
QT_MOC_LITERAL(85, 1589, 21), // "onUpdateCheckComplete"
QT_MOC_LITERAL(86, 1611, 15), // "openCPUDebugger"
QT_MOC_LITERAL(87, 1627, 19) // "onCPUDebuggerClosed"

    },
    "MainWindow\0updateDebugMenuVisibility\0"
    "\0checkForUpdates\0display_message\0"
    "reportError\0message\0reportMessage\0"
    "confirmMessage\0createDisplay\0"
    "QtDisplayWidget*\0QThread*\0worker_thread\0"
    "fullscreen\0render_to_main\0updateDisplay\0"
    "displaySizeRequested\0width\0height\0"
    "destroyDisplay\0focusDisplayWidget\0"
    "onMouseModeRequested\0relative_mode\0"
    "hide_cursor\0updateMouseMode\0paused\0"
    "setTheme\0theme\0updateTheme\0"
    "onEmulationStarting\0onEmulationStarted\0"
    "onEmulationStopped\0onEmulationPaused\0"
    "onStateSaved\0game_code\0global\0slot\0"
    "onSystemPerformanceCountersUpdated\0"
    "speed\0fps\0vps\0average_frame_time\0"
    "worst_frame_time\0GPURenderer\0renderer\0"
    "render_width\0render_height\0render_interlaced\0"
    "onRunningGameChanged\0filename\0game_title\0"
    "onApplicationStateChanged\0"
    "Qt::ApplicationState\0state\0"
    "onStartDiscActionTriggered\0"
    "onStartBIOSActionTriggered\0"
    "onChangeDiscFromFileActionTriggered\0"
    "onChangeDiscFromGameListActionTriggered\0"
    "onChangeDiscMenuAboutToShow\0"
    "onChangeDiscMenuAboutToHide\0"
    "onCheatsMenuAboutToShow\0"
    "onRemoveDiscActionTriggered\0"
    "onViewToolbarActionToggled\0checked\0"
    "onViewLockToolbarActionToggled\0"
    "onViewStatusBarActionToggled\0"
    "onViewGameListActionTriggered\0"
    "onViewGameGridActionTriggered\0"
    "onViewSystemDisplayTriggered\0"
    "onViewGamePropertiesActionTriggered\0"
    "onGitHubRepositoryActionTriggered\0"
    "onIssueTrackerActionTriggered\0"
    "onDiscordServerActionTriggered\0"
    "onAboutActionTriggered\0"
    "onCheckForUpdatesActionTriggered\0"
    "onToolsMemoryCardEditorTriggered\0"
    "onToolsCheatManagerTriggered\0"
    "onToolsOpenDataDirectoryTriggered\0"
    "onGameListEntrySelected\0const GameListEntry*\0"
    "entry\0onGameListEntryDoubleClicked\0"
    "onGameListContextMenuRequested\0point\0"
    "onGameListSetCoverImageRequested\0"
    "onUpdateCheckComplete\0openCPUDebugger\0"
    "onCPUDebuggerClosed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      52,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  274,    2, 0x0a /* Public */,
       3,    1,  275,    2, 0x0a /* Public */,
       5,    1,  278,    2, 0x08 /* Private */,
       7,    1,  281,    2, 0x08 /* Private */,
       8,    1,  284,    2, 0x08 /* Private */,
       9,    3,  287,    2, 0x08 /* Private */,
      15,    3,  294,    2, 0x08 /* Private */,
      16,    2,  301,    2, 0x08 /* Private */,
      19,    0,  306,    2, 0x08 /* Private */,
      20,    0,  307,    2, 0x08 /* Private */,
      21,    2,  308,    2, 0x08 /* Private */,
      24,    1,  313,    2, 0x08 /* Private */,
      26,    1,  316,    2, 0x08 /* Private */,
      28,    0,  319,    2, 0x08 /* Private */,
      29,    0,  320,    2, 0x08 /* Private */,
      30,    0,  321,    2, 0x08 /* Private */,
      31,    0,  322,    2, 0x08 /* Private */,
      32,    1,  323,    2, 0x08 /* Private */,
      33,    3,  326,    2, 0x08 /* Private */,
      37,    9,  333,    2, 0x08 /* Private */,
      48,    3,  352,    2, 0x08 /* Private */,
      51,    1,  359,    2, 0x08 /* Private */,
      54,    0,  362,    2, 0x08 /* Private */,
      55,    0,  363,    2, 0x08 /* Private */,
      56,    0,  364,    2, 0x08 /* Private */,
      57,    0,  365,    2, 0x08 /* Private */,
      58,    0,  366,    2, 0x08 /* Private */,
      59,    0,  367,    2, 0x08 /* Private */,
      60,    0,  368,    2, 0x08 /* Private */,
      61,    0,  369,    2, 0x08 /* Private */,
      62,    1,  370,    2, 0x08 /* Private */,
      64,    1,  373,    2, 0x08 /* Private */,
      65,    1,  376,    2, 0x08 /* Private */,
      66,    0,  379,    2, 0x08 /* Private */,
      67,    0,  380,    2, 0x08 /* Private */,
      68,    0,  381,    2, 0x08 /* Private */,
      69,    0,  382,    2, 0x08 /* Private */,
      70,    0,  383,    2, 0x08 /* Private */,
      71,    0,  384,    2, 0x08 /* Private */,
      72,    0,  385,    2, 0x08 /* Private */,
      73,    0,  386,    2, 0x08 /* Private */,
      74,    0,  387,    2, 0x08 /* Private */,
      75,    0,  388,    2, 0x08 /* Private */,
      76,    0,  389,    2, 0x08 /* Private */,
      77,    0,  390,    2, 0x08 /* Private */,
      78,    1,  391,    2, 0x08 /* Private */,
      81,    1,  394,    2, 0x08 /* Private */,
      82,    2,  397,    2, 0x08 /* Private */,
      84,    1,  402,    2, 0x08 /* Private */,
      85,    0,  405,    2, 0x08 /* Private */,
      86,    0,  406,    2, 0x08 /* Private */,
      87,    0,  407,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Bool, QMetaType::QString,    6,
    0x80000000 | 10, 0x80000000 | 11, QMetaType::Bool, QMetaType::Bool,   12,   13,   14,
    0x80000000 | 10, 0x80000000 | 11, QMetaType::Bool, QMetaType::Bool,   12,   13,   14,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   17,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   22,   23,
    QMetaType::Void, QMetaType::Bool,   25,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   25,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool, QMetaType::Int,   34,   35,   36,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Float, 0x80000000 | 43, QMetaType::UInt, QMetaType::UInt, QMetaType::Bool,   38,   39,   40,   41,   42,   44,   45,   46,   47,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   49,   34,   50,
    QMetaType::Void, 0x80000000 | 52,   53,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   63,
    QMetaType::Void, QMetaType::Bool,   63,
    QMetaType::Void, QMetaType::Bool,   63,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 79,   80,
    QMetaType::Void, 0x80000000 | 79,   80,
    QMetaType::Void, QMetaType::QPoint, 0x80000000 | 79,   83,   80,
    QMetaType::Void, 0x80000000 | 79,   80,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateDebugMenuVisibility(); break;
        case 1: _t->checkForUpdates((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->reportError((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->reportMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: { bool _r = _t->confirmMessage((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: { QtDisplayWidget* _r = _t->createDisplay((*reinterpret_cast< QThread*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QtDisplayWidget**>(_a[0]) = std::move(_r); }  break;
        case 6: { QtDisplayWidget* _r = _t->updateDisplay((*reinterpret_cast< QThread*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QtDisplayWidget**>(_a[0]) = std::move(_r); }  break;
        case 7: _t->displaySizeRequested((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 8: _t->destroyDisplay(); break;
        case 9: _t->focusDisplayWidget(); break;
        case 10: _t->onMouseModeRequested((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 11: _t->updateMouseMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->setTheme((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->updateTheme(); break;
        case 14: _t->onEmulationStarting(); break;
        case 15: _t->onEmulationStarted(); break;
        case 16: _t->onEmulationStopped(); break;
        case 17: _t->onEmulationPaused((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->onStateSaved((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 19: _t->onSystemPerformanceCountersUpdated((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5])),(*reinterpret_cast< GPURenderer(*)>(_a[6])),(*reinterpret_cast< quint32(*)>(_a[7])),(*reinterpret_cast< quint32(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9]))); break;
        case 20: _t->onRunningGameChanged((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 21: _t->onApplicationStateChanged((*reinterpret_cast< Qt::ApplicationState(*)>(_a[1]))); break;
        case 22: _t->onStartDiscActionTriggered(); break;
        case 23: _t->onStartBIOSActionTriggered(); break;
        case 24: _t->onChangeDiscFromFileActionTriggered(); break;
        case 25: _t->onChangeDiscFromGameListActionTriggered(); break;
        case 26: _t->onChangeDiscMenuAboutToShow(); break;
        case 27: _t->onChangeDiscMenuAboutToHide(); break;
        case 28: _t->onCheatsMenuAboutToShow(); break;
        case 29: _t->onRemoveDiscActionTriggered(); break;
        case 30: _t->onViewToolbarActionToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->onViewLockToolbarActionToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->onViewStatusBarActionToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->onViewGameListActionTriggered(); break;
        case 34: _t->onViewGameGridActionTriggered(); break;
        case 35: _t->onViewSystemDisplayTriggered(); break;
        case 36: _t->onViewGamePropertiesActionTriggered(); break;
        case 37: _t->onGitHubRepositoryActionTriggered(); break;
        case 38: _t->onIssueTrackerActionTriggered(); break;
        case 39: _t->onDiscordServerActionTriggered(); break;
        case 40: _t->onAboutActionTriggered(); break;
        case 41: _t->onCheckForUpdatesActionTriggered(); break;
        case 42: _t->onToolsMemoryCardEditorTriggered(); break;
        case 43: _t->onToolsCheatManagerTriggered(); break;
        case 44: _t->onToolsOpenDataDirectoryTriggered(); break;
        case 45: _t->onGameListEntrySelected((*reinterpret_cast< const GameListEntry*(*)>(_a[1]))); break;
        case 46: _t->onGameListEntryDoubleClicked((*reinterpret_cast< const GameListEntry*(*)>(_a[1]))); break;
        case 47: _t->onGameListContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1])),(*reinterpret_cast< const GameListEntry*(*)>(_a[2]))); break;
        case 48: _t->onGameListSetCoverImageRequested((*reinterpret_cast< const GameListEntry*(*)>(_a[1]))); break;
        case 49: _t->onUpdateCheckComplete(); break;
        case 50: _t->openCPUDebugger(); break;
        case 51: _t->onCPUDebuggerClosed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QThread* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QThread* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 52)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 52;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 52)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 52;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
