/********************************************************************************
** Form generated from reading UI file 'memorycardeditordialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEMORYCARDEDITORDIALOG_H
#define UI_MEMORYCARDEDITORDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_MemoryCardEditorDialog
{
public:
    QGridLayout *gridLayout;
    QTableWidget *cardA;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *cardBPath;
    QToolButton *newCardB;
    QToolButton *openCardB;
    QHBoxLayout *horizontalLayout_3;
    QLabel *cardBUsage;
    QPushButton *importFileToCardB;
    QPushButton *importCardB;
    QPushButton *saveCardB;
    QHBoxLayout *horizontalLayout_4;
    QLabel *cardAUsage;
    QPushButton *importFileToCardA;
    QPushButton *importCardA;
    QPushButton *saveCardA;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *cardAPath;
    QToolButton *newCardA;
    QToolButton *openCardA;
    QTableWidget *cardB;
    QVBoxLayout *verticalLayout_3;
    QPushButton *deleteFile;
    QPushButton *exportFile;
    QPushButton *moveLeft;
    QPushButton *moveRight;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QDialog *MemoryCardEditorDialog)
    {
        if (MemoryCardEditorDialog->objectName().isEmpty())
            MemoryCardEditorDialog->setObjectName(QStringLiteral("MemoryCardEditorDialog"));
        MemoryCardEditorDialog->resize(889, 515);
        gridLayout = new QGridLayout(MemoryCardEditorDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        cardA = new QTableWidget(MemoryCardEditorDialog);
        if (cardA->columnCount() < 4)
            cardA->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        cardA->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        cardA->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        cardA->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        cardA->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        cardA->setObjectName(QStringLiteral("cardA"));
        cardA->setSelectionMode(QAbstractItemView::SingleSelection);
        cardA->setSelectionBehavior(QAbstractItemView::SelectRows);
        cardA->setIconSize(QSize(16, 16));
        cardA->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        cardA->verticalHeader()->setVisible(false);

        gridLayout->addWidget(cardA, 1, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(MemoryCardEditorDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_2->addWidget(label_2);

        cardBPath = new QComboBox(MemoryCardEditorDialog);
        cardBPath->setObjectName(QStringLiteral("cardBPath"));

        horizontalLayout_2->addWidget(cardBPath);

        newCardB = new QToolButton(MemoryCardEditorDialog);
        newCardB->setObjectName(QStringLiteral("newCardB"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/document-new.png"), QSize(), QIcon::Normal, QIcon::Off);
        newCardB->setIcon(icon);

        horizontalLayout_2->addWidget(newCardB);

        openCardB = new QToolButton(MemoryCardEditorDialog);
        openCardB->setObjectName(QStringLiteral("openCardB"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/document-open.png"), QSize(), QIcon::Normal, QIcon::Off);
        openCardB->setIcon(icon1);

        horizontalLayout_2->addWidget(openCardB);

        horizontalLayout_2->setStretch(1, 1);

        gridLayout->addLayout(horizontalLayout_2, 0, 3, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        cardBUsage = new QLabel(MemoryCardEditorDialog);
        cardBUsage->setObjectName(QStringLiteral("cardBUsage"));
        cardBUsage->setText(QStringLiteral(""));

        horizontalLayout_3->addWidget(cardBUsage);

        importFileToCardB = new QPushButton(MemoryCardEditorDialog);
        importFileToCardB->setObjectName(QStringLiteral("importFileToCardB"));
        importFileToCardB->setEnabled(false);

        horizontalLayout_3->addWidget(importFileToCardB);

        importCardB = new QPushButton(MemoryCardEditorDialog);
        importCardB->setObjectName(QStringLiteral("importCardB"));
        importCardB->setEnabled(false);

        horizontalLayout_3->addWidget(importCardB);

        saveCardB = new QPushButton(MemoryCardEditorDialog);
        saveCardB->setObjectName(QStringLiteral("saveCardB"));
        saveCardB->setEnabled(false);

        horizontalLayout_3->addWidget(saveCardB);

        horizontalLayout_3->setStretch(0, 1);

        gridLayout->addLayout(horizontalLayout_3, 2, 3, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        cardAUsage = new QLabel(MemoryCardEditorDialog);
        cardAUsage->setObjectName(QStringLiteral("cardAUsage"));
        cardAUsage->setText(QStringLiteral(""));

        horizontalLayout_4->addWidget(cardAUsage);

        importFileToCardA = new QPushButton(MemoryCardEditorDialog);
        importFileToCardA->setObjectName(QStringLiteral("importFileToCardA"));
        importFileToCardA->setEnabled(false);

        horizontalLayout_4->addWidget(importFileToCardA);

        importCardA = new QPushButton(MemoryCardEditorDialog);
        importCardA->setObjectName(QStringLiteral("importCardA"));
        importCardA->setEnabled(false);

        horizontalLayout_4->addWidget(importCardA);

        saveCardA = new QPushButton(MemoryCardEditorDialog);
        saveCardA->setObjectName(QStringLiteral("saveCardA"));
        saveCardA->setEnabled(false);

        horizontalLayout_4->addWidget(saveCardA);

        horizontalLayout_4->setStretch(0, 1);

        gridLayout->addLayout(horizontalLayout_4, 2, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(MemoryCardEditorDialog);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        cardAPath = new QComboBox(MemoryCardEditorDialog);
        cardAPath->setObjectName(QStringLiteral("cardAPath"));

        horizontalLayout->addWidget(cardAPath);

        newCardA = new QToolButton(MemoryCardEditorDialog);
        newCardA->setObjectName(QStringLiteral("newCardA"));
        newCardA->setIcon(icon);

        horizontalLayout->addWidget(newCardA);

        openCardA = new QToolButton(MemoryCardEditorDialog);
        openCardA->setObjectName(QStringLiteral("openCardA"));
        openCardA->setIcon(icon1);

        horizontalLayout->addWidget(openCardA);

        horizontalLayout->setStretch(1, 1);

        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        cardB = new QTableWidget(MemoryCardEditorDialog);
        if (cardB->columnCount() < 4)
            cardB->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        cardB->setHorizontalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        cardB->setHorizontalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        cardB->setHorizontalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        cardB->setHorizontalHeaderItem(3, __qtablewidgetitem7);
        cardB->setObjectName(QStringLiteral("cardB"));
        cardB->setSelectionMode(QAbstractItemView::SingleSelection);
        cardB->setSelectionBehavior(QAbstractItemView::SelectRows);
        cardB->setIconSize(QSize(16, 16));
        cardB->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        cardB->verticalHeader()->setVisible(false);

        gridLayout->addWidget(cardB, 1, 3, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        deleteFile = new QPushButton(MemoryCardEditorDialog);
        deleteFile->setObjectName(QStringLiteral("deleteFile"));
        deleteFile->setEnabled(false);

        verticalLayout_3->addWidget(deleteFile);

        exportFile = new QPushButton(MemoryCardEditorDialog);
        exportFile->setObjectName(QStringLiteral("exportFile"));
        exportFile->setEnabled(false);

        verticalLayout_3->addWidget(exportFile);

        moveLeft = new QPushButton(MemoryCardEditorDialog);
        moveLeft->setObjectName(QStringLiteral("moveLeft"));
        moveLeft->setEnabled(false);

        verticalLayout_3->addWidget(moveLeft);

        moveRight = new QPushButton(MemoryCardEditorDialog);
        moveRight->setObjectName(QStringLiteral("moveRight"));
        moveRight->setEnabled(false);

        verticalLayout_3->addWidget(moveRight);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_2);


        gridLayout->addLayout(verticalLayout_3, 1, 2, 1, 1);


        retranslateUi(MemoryCardEditorDialog);

        QMetaObject::connectSlotsByName(MemoryCardEditorDialog);
    } // setupUi

    void retranslateUi(QDialog *MemoryCardEditorDialog)
    {
        MemoryCardEditorDialog->setWindowTitle(QApplication::translate("MemoryCardEditorDialog", "Memory Card Editor", nullptr));
        QTableWidgetItem *___qtablewidgetitem = cardA->horizontalHeaderItem(1);
        ___qtablewidgetitem->setText(QApplication::translate("MemoryCardEditorDialog", "Title", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = cardA->horizontalHeaderItem(2);
        ___qtablewidgetitem1->setText(QApplication::translate("MemoryCardEditorDialog", "File Name", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = cardA->horizontalHeaderItem(3);
        ___qtablewidgetitem2->setText(QApplication::translate("MemoryCardEditorDialog", "Blocks", nullptr));
        label_2->setText(QApplication::translate("MemoryCardEditorDialog", "Memory Card:", nullptr));
        cardBPath->setCurrentText(QString());
        newCardB->setText(QApplication::translate("MemoryCardEditorDialog", "New...", nullptr));
        openCardB->setText(QApplication::translate("MemoryCardEditorDialog", "Open...", nullptr));
        importFileToCardB->setText(QApplication::translate("MemoryCardEditorDialog", "Import File...", nullptr));
        importCardB->setText(QApplication::translate("MemoryCardEditorDialog", "Import Card...", nullptr));
        saveCardB->setText(QApplication::translate("MemoryCardEditorDialog", "Save", nullptr));
        importFileToCardA->setText(QApplication::translate("MemoryCardEditorDialog", "Import File...", nullptr));
        importCardA->setText(QApplication::translate("MemoryCardEditorDialog", "Import Card...", nullptr));
        saveCardA->setText(QApplication::translate("MemoryCardEditorDialog", "Save", nullptr));
        label->setText(QApplication::translate("MemoryCardEditorDialog", "Memory Card:", nullptr));
        newCardA->setText(QApplication::translate("MemoryCardEditorDialog", "New...", nullptr));
        openCardA->setText(QApplication::translate("MemoryCardEditorDialog", "Open...", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = cardB->horizontalHeaderItem(1);
        ___qtablewidgetitem3->setText(QApplication::translate("MemoryCardEditorDialog", "Title", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = cardB->horizontalHeaderItem(2);
        ___qtablewidgetitem4->setText(QApplication::translate("MemoryCardEditorDialog", "File Name", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = cardB->horizontalHeaderItem(3);
        ___qtablewidgetitem5->setText(QApplication::translate("MemoryCardEditorDialog", "Blocks", nullptr));
        deleteFile->setText(QApplication::translate("MemoryCardEditorDialog", "Delete File", nullptr));
        exportFile->setText(QApplication::translate("MemoryCardEditorDialog", "Export File", nullptr));
        moveLeft->setText(QApplication::translate("MemoryCardEditorDialog", "<<", nullptr));
        moveRight->setText(QApplication::translate("MemoryCardEditorDialog", ">>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MemoryCardEditorDialog: public Ui_MemoryCardEditorDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEMORYCARDEDITORDIALOG_H
