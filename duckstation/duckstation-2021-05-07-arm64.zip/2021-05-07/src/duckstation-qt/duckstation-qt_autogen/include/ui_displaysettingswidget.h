/********************************************************************************
** Form generated from reading UI file 'displaysettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPLAYSETTINGSWIDGET_H
#define UI_DISPLAYSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DisplaySettingsWidget
{
public:
    QVBoxLayout *verticalLayout_2;
    QGroupBox *basicGroupBox;
    QFormLayout *formLayout_2;
    QLabel *label;
    QComboBox *renderer;
    QLabel *label_5;
    QComboBox *adapter;
    QLabel *label_2;
    QComboBox *fullscreenMode;
    QGridLayout *basicCheckboxGridLayout;
    QCheckBox *gpuThread;
    QCheckBox *vsync;
    QCheckBox *threadedPresentation;
    QCheckBox *displayAllFrames;
    QGroupBox *groupBox_3;
    QFormLayout *formLayout;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout;
    QComboBox *displayAspectRatio;
    QSpinBox *customAspectRatioNumerator;
    QLabel *customAspectRatioSeparator;
    QSpinBox *customAspectRatioDenominator;
    QLabel *label_3;
    QComboBox *displayCropMode;
    QLabel *label_6;
    QComboBox *gpuDownsampleMode;
    QGridLayout *gridLayout;
    QCheckBox *displayIntegerScaling;
    QCheckBox *displayStretch;
    QCheckBox *displayLinearFiltering;
    QCheckBox *internalResolutionScreenshots;
    QGroupBox *groupBox_5;
    QGridLayout *formLayout_5;
    QCheckBox *showOSDMessages;
    QCheckBox *showFPS;
    QCheckBox *showSpeed;
    QCheckBox *showVPS;
    QCheckBox *showResolution;
    QCheckBox *showInput;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *DisplaySettingsWidget)
    {
        if (DisplaySettingsWidget->objectName().isEmpty())
            DisplaySettingsWidget->setObjectName(QStringLiteral("DisplaySettingsWidget"));
        DisplaySettingsWidget->resize(485, 525);
        verticalLayout_2 = new QVBoxLayout(DisplaySettingsWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        basicGroupBox = new QGroupBox(DisplaySettingsWidget);
        basicGroupBox->setObjectName(QStringLiteral("basicGroupBox"));
        formLayout_2 = new QFormLayout(basicGroupBox);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label = new QLabel(basicGroupBox);
        label->setObjectName(QStringLiteral("label"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label);

        renderer = new QComboBox(basicGroupBox);
        renderer->setObjectName(QStringLiteral("renderer"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, renderer);

        label_5 = new QLabel(basicGroupBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_5);

        adapter = new QComboBox(basicGroupBox);
        adapter->setObjectName(QStringLiteral("adapter"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, adapter);

        label_2 = new QLabel(basicGroupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_2);

        fullscreenMode = new QComboBox(basicGroupBox);
        fullscreenMode->setObjectName(QStringLiteral("fullscreenMode"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, fullscreenMode);

        basicCheckboxGridLayout = new QGridLayout();
        basicCheckboxGridLayout->setObjectName(QStringLiteral("basicCheckboxGridLayout"));
        gpuThread = new QCheckBox(basicGroupBox);
        gpuThread->setObjectName(QStringLiteral("gpuThread"));

        basicCheckboxGridLayout->addWidget(gpuThread, 0, 0, 1, 1);

        vsync = new QCheckBox(basicGroupBox);
        vsync->setObjectName(QStringLiteral("vsync"));

        basicCheckboxGridLayout->addWidget(vsync, 0, 1, 1, 1);

        threadedPresentation = new QCheckBox(basicGroupBox);
        threadedPresentation->setObjectName(QStringLiteral("threadedPresentation"));

        basicCheckboxGridLayout->addWidget(threadedPresentation, 1, 0, 1, 1);

        displayAllFrames = new QCheckBox(basicGroupBox);
        displayAllFrames->setObjectName(QStringLiteral("displayAllFrames"));

        basicCheckboxGridLayout->addWidget(displayAllFrames, 1, 1, 1, 1);


        formLayout_2->setLayout(3, QFormLayout::SpanningRole, basicCheckboxGridLayout);


        verticalLayout_2->addWidget(basicGroupBox);

        groupBox_3 = new QGroupBox(DisplaySettingsWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        formLayout = new QFormLayout(groupBox_3);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        displayAspectRatio = new QComboBox(groupBox_3);
        displayAspectRatio->setObjectName(QStringLiteral("displayAspectRatio"));

        horizontalLayout->addWidget(displayAspectRatio);

        customAspectRatioNumerator = new QSpinBox(groupBox_3);
        customAspectRatioNumerator->setObjectName(QStringLiteral("customAspectRatioNumerator"));
        customAspectRatioNumerator->setMinimum(1);
        customAspectRatioNumerator->setMaximum(9999);

        horizontalLayout->addWidget(customAspectRatioNumerator);

        customAspectRatioSeparator = new QLabel(groupBox_3);
        customAspectRatioSeparator->setObjectName(QStringLiteral("customAspectRatioSeparator"));

        horizontalLayout->addWidget(customAspectRatioSeparator);

        customAspectRatioDenominator = new QSpinBox(groupBox_3);
        customAspectRatioDenominator->setObjectName(QStringLiteral("customAspectRatioDenominator"));
        customAspectRatioDenominator->setMinimum(1);
        customAspectRatioDenominator->setMaximum(9999);

        horizontalLayout->addWidget(customAspectRatioDenominator);

        horizontalLayout->setStretch(0, 1);

        formLayout->setLayout(0, QFormLayout::FieldRole, horizontalLayout);

        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        displayCropMode = new QComboBox(groupBox_3);
        displayCropMode->setObjectName(QStringLiteral("displayCropMode"));

        formLayout->setWidget(1, QFormLayout::FieldRole, displayCropMode);

        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_6);

        gpuDownsampleMode = new QComboBox(groupBox_3);
        gpuDownsampleMode->setObjectName(QStringLiteral("gpuDownsampleMode"));

        formLayout->setWidget(2, QFormLayout::FieldRole, gpuDownsampleMode);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        displayIntegerScaling = new QCheckBox(groupBox_3);
        displayIntegerScaling->setObjectName(QStringLiteral("displayIntegerScaling"));

        gridLayout->addWidget(displayIntegerScaling, 0, 0, 1, 1);

        displayStretch = new QCheckBox(groupBox_3);
        displayStretch->setObjectName(QStringLiteral("displayStretch"));

        gridLayout->addWidget(displayStretch, 0, 1, 1, 1);

        displayLinearFiltering = new QCheckBox(groupBox_3);
        displayLinearFiltering->setObjectName(QStringLiteral("displayLinearFiltering"));

        gridLayout->addWidget(displayLinearFiltering, 1, 0, 1, 1);

        internalResolutionScreenshots = new QCheckBox(groupBox_3);
        internalResolutionScreenshots->setObjectName(QStringLiteral("internalResolutionScreenshots"));

        gridLayout->addWidget(internalResolutionScreenshots, 1, 1, 1, 1);


        formLayout->setLayout(3, QFormLayout::SpanningRole, gridLayout);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_5 = new QGroupBox(DisplaySettingsWidget);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        formLayout_5 = new QGridLayout(groupBox_5);
        formLayout_5->setObjectName(QStringLiteral("formLayout_5"));
        showOSDMessages = new QCheckBox(groupBox_5);
        showOSDMessages->setObjectName(QStringLiteral("showOSDMessages"));

        formLayout_5->addWidget(showOSDMessages, 2, 0, 1, 1);

        showFPS = new QCheckBox(groupBox_5);
        showFPS->setObjectName(QStringLiteral("showFPS"));

        formLayout_5->addWidget(showFPS, 2, 1, 1, 1);

        showSpeed = new QCheckBox(groupBox_5);
        showSpeed->setObjectName(QStringLiteral("showSpeed"));

        formLayout_5->addWidget(showSpeed, 3, 0, 1, 1);

        showVPS = new QCheckBox(groupBox_5);
        showVPS->setObjectName(QStringLiteral("showVPS"));

        formLayout_5->addWidget(showVPS, 3, 1, 1, 1);

        showResolution = new QCheckBox(groupBox_5);
        showResolution->setObjectName(QStringLiteral("showResolution"));

        formLayout_5->addWidget(showResolution, 4, 0, 1, 1);

        showInput = new QCheckBox(groupBox_5);
        showInput->setObjectName(QStringLiteral("showInput"));

        formLayout_5->addWidget(showInput, 4, 1, 1, 1);


        verticalLayout_2->addWidget(groupBox_5);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        retranslateUi(DisplaySettingsWidget);

        QMetaObject::connectSlotsByName(DisplaySettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *DisplaySettingsWidget)
    {
        DisplaySettingsWidget->setWindowTitle(QApplication::translate("DisplaySettingsWidget", "Form", nullptr));
        basicGroupBox->setTitle(QApplication::translate("DisplaySettingsWidget", "Basic", nullptr));
        label->setText(QApplication::translate("DisplaySettingsWidget", "Renderer:", nullptr));
        label_5->setText(QApplication::translate("DisplaySettingsWidget", "Adapter:", nullptr));
        label_2->setText(QApplication::translate("DisplaySettingsWidget", "Fullscreen Mode:", nullptr));
        gpuThread->setText(QApplication::translate("DisplaySettingsWidget", "Threaded Rendering", nullptr));
        vsync->setText(QApplication::translate("DisplaySettingsWidget", "VSync", nullptr));
        threadedPresentation->setText(QApplication::translate("DisplaySettingsWidget", "Threaded Presentation", nullptr));
        displayAllFrames->setText(QApplication::translate("DisplaySettingsWidget", "Optimal Frame Pacing", nullptr));
        groupBox_3->setTitle(QApplication::translate("DisplaySettingsWidget", "Screen Display", nullptr));
        label_4->setText(QApplication::translate("DisplaySettingsWidget", "Aspect Ratio:", nullptr));
        customAspectRatioSeparator->setText(QApplication::translate("DisplaySettingsWidget", ":", nullptr));
        label_3->setText(QApplication::translate("DisplaySettingsWidget", "Crop:", nullptr));
        label_6->setText(QApplication::translate("DisplaySettingsWidget", "Downsampling:", nullptr));
        displayIntegerScaling->setText(QApplication::translate("DisplaySettingsWidget", "Integer Upscaling", nullptr));
        displayStretch->setText(QApplication::translate("DisplaySettingsWidget", "Stretch To Fill", nullptr));
        displayLinearFiltering->setText(QApplication::translate("DisplaySettingsWidget", "Linear Upscaling", nullptr));
        internalResolutionScreenshots->setText(QApplication::translate("DisplaySettingsWidget", "Internal Resolution Screenshots", nullptr));
        groupBox_5->setTitle(QApplication::translate("DisplaySettingsWidget", "On-Screen Display", nullptr));
        showOSDMessages->setText(QApplication::translate("DisplaySettingsWidget", "Show OSD Messages", nullptr));
        showFPS->setText(QApplication::translate("DisplaySettingsWidget", "Show Game Frame Rate", nullptr));
        showSpeed->setText(QApplication::translate("DisplaySettingsWidget", "Show Emulation Speed", nullptr));
        showVPS->setText(QApplication::translate("DisplaySettingsWidget", "Show Display FPS", nullptr));
        showResolution->setText(QApplication::translate("DisplaySettingsWidget", "Show Resolution", nullptr));
        showInput->setText(QApplication::translate("DisplaySettingsWidget", "Show Controller Input", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DisplaySettingsWidget: public Ui_DisplaySettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPLAYSETTINGSWIDGET_H
