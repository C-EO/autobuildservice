/********************************************************************************
** Form generated from reading UI file 'consolesettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONSOLESETTINGSWIDGET_H
#define UI_CONSOLESETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConsoleSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QFormLayout *formLayout;
    QLabel *label;
    QComboBox *region;
    QCheckBox *enable8MBRAM;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout_3;
    QLabel *label_3;
    QComboBox *cpuExecutionMode;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QCheckBox *enableCPUClockSpeedControl;
    QSpacerItem *horizontalSpacer;
    QLabel *cpuClockSpeedLabel;
    QSlider *cpuClockSpeed;
    QGroupBox *groupBox_4;
    QFormLayout *formLayout_4;
    QLabel *label_2;
    QComboBox *cdromReadSpeedup;
    QGridLayout *gridLayout;
    QCheckBox *cdromReadThread;
    QCheckBox *cdromRegionCheck;
    QCheckBox *cdromLoadImageToRAM;
    QGroupBox *groupBox_3;
    QFormLayout *formLayout_2;
    QLabel *label_4;
    QComboBox *multitapMode;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *ConsoleSettingsWidget)
    {
        if (ConsoleSettingsWidget->objectName().isEmpty())
            ConsoleSettingsWidget->setObjectName(QStringLiteral("ConsoleSettingsWidget"));
        ConsoleSettingsWidget->resize(648, 456);
        verticalLayout = new QVBoxLayout(ConsoleSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(ConsoleSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        formLayout = new QFormLayout(groupBox);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        region = new QComboBox(groupBox);
        region->setObjectName(QStringLiteral("region"));

        formLayout->setWidget(0, QFormLayout::FieldRole, region);

        enable8MBRAM = new QCheckBox(groupBox);
        enable8MBRAM->setObjectName(QStringLiteral("enable8MBRAM"));

        formLayout->setWidget(1, QFormLayout::SpanningRole, enable8MBRAM);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(ConsoleSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        formLayout_3 = new QFormLayout(groupBox_2);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_3);

        cpuExecutionMode = new QComboBox(groupBox_2);
        cpuExecutionMode->setObjectName(QStringLiteral("cpuExecutionMode"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, cpuExecutionMode);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        enableCPUClockSpeedControl = new QCheckBox(groupBox_2);
        enableCPUClockSpeedControl->setObjectName(QStringLiteral("enableCPUClockSpeedControl"));

        horizontalLayout->addWidget(enableCPUClockSpeedControl);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        cpuClockSpeedLabel = new QLabel(groupBox_2);
        cpuClockSpeedLabel->setObjectName(QStringLiteral("cpuClockSpeedLabel"));
        cpuClockSpeedLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(cpuClockSpeedLabel);


        verticalLayout_2->addLayout(horizontalLayout);

        cpuClockSpeed = new QSlider(groupBox_2);
        cpuClockSpeed->setObjectName(QStringLiteral("cpuClockSpeed"));
        cpuClockSpeed->setMinimum(10);
        cpuClockSpeed->setMaximum(1000);
        cpuClockSpeed->setValue(100);
        cpuClockSpeed->setOrientation(Qt::Horizontal);
        cpuClockSpeed->setTickPosition(QSlider::TicksBothSides);
        cpuClockSpeed->setTickInterval(50);

        verticalLayout_2->addWidget(cpuClockSpeed);


        formLayout_3->setLayout(1, QFormLayout::SpanningRole, verticalLayout_2);


        verticalLayout->addWidget(groupBox_2);

        groupBox_4 = new QGroupBox(ConsoleSettingsWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        formLayout_4 = new QFormLayout(groupBox_4);
        formLayout_4->setObjectName(QStringLiteral("formLayout_4"));
        label_2 = new QLabel(groupBox_4);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label_2);

        cdromReadSpeedup = new QComboBox(groupBox_4);
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->addItem(QString());
        cdromReadSpeedup->setObjectName(QStringLiteral("cdromReadSpeedup"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, cdromReadSpeedup);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        cdromReadThread = new QCheckBox(groupBox_4);
        cdromReadThread->setObjectName(QStringLiteral("cdromReadThread"));

        gridLayout->addWidget(cdromReadThread, 0, 0, 1, 1);

        cdromRegionCheck = new QCheckBox(groupBox_4);
        cdromRegionCheck->setObjectName(QStringLiteral("cdromRegionCheck"));

        gridLayout->addWidget(cdromRegionCheck, 0, 1, 1, 1);

        cdromLoadImageToRAM = new QCheckBox(groupBox_4);
        cdromLoadImageToRAM->setObjectName(QStringLiteral("cdromLoadImageToRAM"));

        gridLayout->addWidget(cdromLoadImageToRAM, 1, 0, 1, 1);


        formLayout_4->setLayout(1, QFormLayout::SpanningRole, gridLayout);


        verticalLayout->addWidget(groupBox_4);

        groupBox_3 = new QGroupBox(ConsoleSettingsWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        formLayout_2 = new QFormLayout(groupBox_3);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_4);

        multitapMode = new QComboBox(groupBox_3);
        multitapMode->setObjectName(QStringLiteral("multitapMode"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, multitapMode);


        verticalLayout->addWidget(groupBox_3);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(ConsoleSettingsWidget);

        QMetaObject::connectSlotsByName(ConsoleSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *ConsoleSettingsWidget)
    {
        ConsoleSettingsWidget->setWindowTitle(QApplication::translate("ConsoleSettingsWidget", "Form", nullptr));
        groupBox->setTitle(QApplication::translate("ConsoleSettingsWidget", "Console", nullptr));
        label->setText(QApplication::translate("ConsoleSettingsWidget", "Region:", nullptr));
        enable8MBRAM->setText(QApplication::translate("ConsoleSettingsWidget", "Enable 8MB RAM (Dev Console)", nullptr));
        groupBox_2->setTitle(QApplication::translate("ConsoleSettingsWidget", "CPU Emulation", nullptr));
        label_3->setText(QApplication::translate("ConsoleSettingsWidget", "Execution Mode:", nullptr));
        enableCPUClockSpeedControl->setText(QApplication::translate("ConsoleSettingsWidget", "Enable Clock Speed Control (Overclocking/Underclocking)", nullptr));
        cpuClockSpeedLabel->setText(QApplication::translate("ConsoleSettingsWidget", "100% (effective 33.3mhz)", nullptr));
        groupBox_4->setTitle(QApplication::translate("ConsoleSettingsWidget", "CD-ROM Emulation", nullptr));
        label_2->setText(QApplication::translate("ConsoleSettingsWidget", "Read Speedup:", nullptr));
        cdromReadSpeedup->setItemText(0, QApplication::translate("ConsoleSettingsWidget", "None (Double Speed)", nullptr));
        cdromReadSpeedup->setItemText(1, QApplication::translate("ConsoleSettingsWidget", "2x (Quad Speed)", nullptr));
        cdromReadSpeedup->setItemText(2, QApplication::translate("ConsoleSettingsWidget", "3x (6x Speed)", nullptr));
        cdromReadSpeedup->setItemText(3, QApplication::translate("ConsoleSettingsWidget", "4x (8x Speed)", nullptr));
        cdromReadSpeedup->setItemText(4, QApplication::translate("ConsoleSettingsWidget", "5x (10x Speed)", nullptr));
        cdromReadSpeedup->setItemText(5, QApplication::translate("ConsoleSettingsWidget", "6x (12x Speed)", nullptr));
        cdromReadSpeedup->setItemText(6, QApplication::translate("ConsoleSettingsWidget", "7x (14x Speed)", nullptr));
        cdromReadSpeedup->setItemText(7, QApplication::translate("ConsoleSettingsWidget", "8x (16x Speed)", nullptr));
        cdromReadSpeedup->setItemText(8, QApplication::translate("ConsoleSettingsWidget", "9x (18x Speed)", nullptr));
        cdromReadSpeedup->setItemText(9, QApplication::translate("ConsoleSettingsWidget", "10x (20x Speed)", nullptr));

        cdromReadThread->setText(QApplication::translate("ConsoleSettingsWidget", "Use Read Thread (Asynchronous)", nullptr));
        cdromRegionCheck->setText(QApplication::translate("ConsoleSettingsWidget", "Enable Region Check", nullptr));
        cdromLoadImageToRAM->setText(QApplication::translate("ConsoleSettingsWidget", "Preload Image To RAM", nullptr));
        groupBox_3->setTitle(QApplication::translate("ConsoleSettingsWidget", "Controller Ports", nullptr));
        label_4->setText(QApplication::translate("ConsoleSettingsWidget", "Multitap:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ConsoleSettingsWidget: public Ui_ConsoleSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONSOLESETTINGSWIDGET_H
