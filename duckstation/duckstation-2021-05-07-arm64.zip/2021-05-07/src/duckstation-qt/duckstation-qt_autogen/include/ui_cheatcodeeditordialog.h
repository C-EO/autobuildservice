/********************************************************************************
** Form generated from reading UI file 'cheatcodeeditordialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHEATCODEEDITORDIALOG_H
#define UI_CHEATCODEEDITORDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_CheatCodeEditorDialog
{
public:
    QFormLayout *formLayout;
    QLabel *label_2;
    QLineEdit *description;
    QLabel *label;
    QComboBox *group;
    QLabel *label_3;
    QComboBox *type;
    QLabel *label_4;
    QComboBox *activation;
    QPlainTextEdit *instructions;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *save;
    QPushButton *cancel;

    void setupUi(QDialog *CheatCodeEditorDialog)
    {
        if (CheatCodeEditorDialog->objectName().isEmpty())
            CheatCodeEditorDialog->setObjectName(QStringLiteral("CheatCodeEditorDialog"));
        CheatCodeEditorDialog->resize(491, 284);
        CheatCodeEditorDialog->setModal(true);
        formLayout = new QFormLayout(CheatCodeEditorDialog);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label_2 = new QLabel(CheatCodeEditorDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        description = new QLineEdit(CheatCodeEditorDialog);
        description->setObjectName(QStringLiteral("description"));

        formLayout->setWidget(0, QFormLayout::FieldRole, description);

        label = new QLabel(CheatCodeEditorDialog);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label);

        group = new QComboBox(CheatCodeEditorDialog);
        group->setObjectName(QStringLiteral("group"));

        formLayout->setWidget(1, QFormLayout::FieldRole, group);

        label_3 = new QLabel(CheatCodeEditorDialog);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        type = new QComboBox(CheatCodeEditorDialog);
        type->setObjectName(QStringLiteral("type"));

        formLayout->setWidget(2, QFormLayout::FieldRole, type);

        label_4 = new QLabel(CheatCodeEditorDialog);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        activation = new QComboBox(CheatCodeEditorDialog);
        activation->setObjectName(QStringLiteral("activation"));

        formLayout->setWidget(3, QFormLayout::FieldRole, activation);

        instructions = new QPlainTextEdit(CheatCodeEditorDialog);
        instructions->setObjectName(QStringLiteral("instructions"));

        formLayout->setWidget(4, QFormLayout::SpanningRole, instructions);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        save = new QPushButton(CheatCodeEditorDialog);
        save->setObjectName(QStringLiteral("save"));

        horizontalLayout->addWidget(save);

        cancel = new QPushButton(CheatCodeEditorDialog);
        cancel->setObjectName(QStringLiteral("cancel"));

        horizontalLayout->addWidget(cancel);


        formLayout->setLayout(5, QFormLayout::SpanningRole, horizontalLayout);


        retranslateUi(CheatCodeEditorDialog);

        save->setDefault(true);


        QMetaObject::connectSlotsByName(CheatCodeEditorDialog);
    } // setupUi

    void retranslateUi(QDialog *CheatCodeEditorDialog)
    {
        CheatCodeEditorDialog->setWindowTitle(QApplication::translate("CheatCodeEditorDialog", "Cheat Code Editor", nullptr));
        label_2->setText(QApplication::translate("CheatCodeEditorDialog", "Description:", nullptr));
        label->setText(QApplication::translate("CheatCodeEditorDialog", "Group:", nullptr));
        label_3->setText(QApplication::translate("CheatCodeEditorDialog", "Type:", nullptr));
        label_4->setText(QApplication::translate("CheatCodeEditorDialog", "Activation:", nullptr));
        save->setText(QApplication::translate("CheatCodeEditorDialog", "Save", nullptr));
        cancel->setText(QApplication::translate("CheatCodeEditorDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CheatCodeEditorDialog: public Ui_CheatCodeEditorDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHEATCODEEDITORDIALOG_H
