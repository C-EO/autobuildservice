// d3fea7b5a7fff86c5a307aebcc44f9e819ac6d22 master 0.1-3945-gd3fea7b5 2021-05-05T03:26:40+10:00
const char* g_scm_hash_str = "d3fea7b5a7fff86c5a307aebcc44f9e819ac6d22";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3945-gd3fea7b5";
const char* g_scm_date_str = "2021-05-05T03:26:40+10:00";

