// 8f821c776c24f1bb59d5a2c123d6e6a5c9b6dc14 master 0.1-3862-g8f821c77 2021-04-22T15:52:11+10:00
const char* g_scm_hash_str = "8f821c776c24f1bb59d5a2c123d6e6a5c9b6dc14";
const char* g_scm_branch_str = "master";
const char* g_scm_tag_str = "0.1-3862-g8f821c77";
const char* g_scm_date_str = "2021-04-22T15:52:11+10:00";

