/********************************************************************************
** Form generated from reading UI file 'settingsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGSDIALOG_H
#define UI_SETTINGSDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SettingsDialog
{
public:
    QGridLayout *gridLayout;
    QListWidget *settingsCategory;
    QStackedWidget *settingsContainer;
    QWidget *page;
    QWidget *page_2;
    QTextEdit *helpText;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *closeButton;

    void setupUi(QDialog *SettingsDialog)
    {
        if (SettingsDialog->objectName().isEmpty())
            SettingsDialog->setObjectName(QStringLiteral("SettingsDialog"));
        SettingsDialog->setWindowModality(Qt::WindowModal);
        SettingsDialog->resize(780, 650);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingsDialog->sizePolicy().hasHeightForWidth());
        SettingsDialog->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/applications-system.png"), QSize(), QIcon::Normal, QIcon::Off);
        SettingsDialog->setWindowIcon(icon);
        gridLayout = new QGridLayout(SettingsDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        settingsCategory = new QListWidget(SettingsDialog);
        QListWidgetItem *__qlistwidgetitem = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem->setIcon(icon);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/media-flash-2.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem1 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem1->setIcon(icon1);
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/utilities-system-monitor.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem2 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem2->setIcon(icon2);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/applications-other.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem3 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem3->setIcon(icon3);
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/system-file-manager.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem4 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem4->setIcon(icon4);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/preferences-desktop-keyboard-shortcuts.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem5 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem5->setIcon(icon5);
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/input-gaming.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem6 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem6->setIcon(icon6);
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/icons/media-flash.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem7 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem7->setIcon(icon7);
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/icons/video-display.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem8 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem8->setIcon(icon8);
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/icons/antialias-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem9 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem9->setIcon(icon9);
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/icons/applications-graphics.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem10 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem10->setIcon(icon10);
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/icons/audio-card.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem11 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem11->setIcon(icon11);
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/icons/trophy.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem12 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem12->setIcon(icon12);
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/icons/applications-development.png"), QSize(), QIcon::Normal, QIcon::Off);
        QListWidgetItem *__qlistwidgetitem13 = new QListWidgetItem(settingsCategory);
        __qlistwidgetitem13->setIcon(icon13);
        settingsCategory->setObjectName(QStringLiteral("settingsCategory"));
        sizePolicy.setHeightForWidth(settingsCategory->sizePolicy().hasHeightForWidth());
        settingsCategory->setSizePolicy(sizePolicy);
        settingsCategory->setMinimumSize(QSize(230, 0));
        settingsCategory->setMaximumSize(QSize(400, 16777215));
        settingsCategory->setIconSize(QSize(32, 32));

        gridLayout->addWidget(settingsCategory, 0, 0, 1, 1);

        settingsContainer = new QStackedWidget(SettingsDialog);
        settingsContainer->setObjectName(QStringLiteral("settingsContainer"));
        settingsContainer->setMinimumSize(QSize(500, 0));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        settingsContainer->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        settingsContainer->addWidget(page_2);

        gridLayout->addWidget(settingsContainer, 0, 1, 1, 1);

        helpText = new QTextEdit(SettingsDialog);
        helpText->setObjectName(QStringLiteral("helpText"));
        helpText->setMinimumSize(QSize(0, 120));
        helpText->setMaximumSize(QSize(16777215, 120));
        helpText->setReadOnly(true);

        gridLayout->addWidget(helpText, 1, 0, 1, 2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        closeButton = new QPushButton(SettingsDialog);
        closeButton->setObjectName(QStringLiteral("closeButton"));

        horizontalLayout_2->addWidget(closeButton);


        gridLayout->addLayout(horizontalLayout_2, 2, 0, 1, 2);


        retranslateUi(SettingsDialog);

        settingsContainer->setCurrentIndex(0);
        closeButton->setDefault(true);


        QMetaObject::connectSlotsByName(SettingsDialog);
    } // setupUi

    void retranslateUi(QDialog *SettingsDialog)
    {
        SettingsDialog->setWindowTitle(QApplication::translate("SettingsDialog", "DuckStation Settings", nullptr));

        const bool __sortingEnabled = settingsCategory->isSortingEnabled();
        settingsCategory->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = settingsCategory->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("SettingsDialog", "General Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = settingsCategory->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("SettingsDialog", "BIOS Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = settingsCategory->item(2);
        ___qlistwidgetitem2->setText(QApplication::translate("SettingsDialog", "Console Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = settingsCategory->item(3);
        ___qlistwidgetitem3->setText(QApplication::translate("SettingsDialog", "Emulation Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = settingsCategory->item(4);
        ___qlistwidgetitem4->setText(QApplication::translate("SettingsDialog", "Game List Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem5 = settingsCategory->item(5);
        ___qlistwidgetitem5->setText(QApplication::translate("SettingsDialog", "Hotkey Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem6 = settingsCategory->item(6);
        ___qlistwidgetitem6->setText(QApplication::translate("SettingsDialog", "Controller Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem7 = settingsCategory->item(7);
        ___qlistwidgetitem7->setText(QApplication::translate("SettingsDialog", "Memory Card Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem8 = settingsCategory->item(8);
        ___qlistwidgetitem8->setText(QApplication::translate("SettingsDialog", "Display Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem9 = settingsCategory->item(9);
        ___qlistwidgetitem9->setText(QApplication::translate("SettingsDialog", "Enhancement Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem10 = settingsCategory->item(10);
        ___qlistwidgetitem10->setText(QApplication::translate("SettingsDialog", "Post-Processing Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem11 = settingsCategory->item(11);
        ___qlistwidgetitem11->setText(QApplication::translate("SettingsDialog", "Audio Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem12 = settingsCategory->item(12);
        ___qlistwidgetitem12->setText(QApplication::translate("SettingsDialog", "Achievement Settings", nullptr));
        QListWidgetItem *___qlistwidgetitem13 = settingsCategory->item(13);
        ___qlistwidgetitem13->setText(QApplication::translate("SettingsDialog", "Advanced Settings", nullptr));
        settingsCategory->setSortingEnabled(__sortingEnabled);

        closeButton->setText(QApplication::translate("SettingsDialog", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SettingsDialog: public Ui_SettingsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGSDIALOG_H
