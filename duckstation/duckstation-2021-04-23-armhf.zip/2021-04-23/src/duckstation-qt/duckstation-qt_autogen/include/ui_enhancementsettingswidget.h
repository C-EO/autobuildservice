/********************************************************************************
** Form generated from reading UI file 'enhancementsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENHANCEMENTSETTINGSWIDGET_H
#define UI_ENHANCEMENTSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EnhancementSettingsWidget
{
public:
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_2;
    QFormLayout *formLayout_2;
    QLabel *label_2;
    QComboBox *resolutionScale;
    QLabel *label_3;
    QComboBox *textureFiltering;
    QCheckBox *trueColor;
    QCheckBox *scaledDithering;
    QCheckBox *widescreenHack;
    QLabel *label;
    QComboBox *msaaMode;
    QGroupBox *groupBox_3;
    QFormLayout *formLayout_3;
    QCheckBox *disableInterlacing;
    QCheckBox *forceNTSCTimings;
    QCheckBox *force43For24Bit;
    QCheckBox *chromaSmoothingFor24Bit;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout;
    QCheckBox *pgxpEnable;
    QCheckBox *pgxpCulling;
    QCheckBox *pgxpTextureCorrection;
    QCheckBox *pgxpPreserveProjPrecision;
    QCheckBox *pgxpDepthBuffer;
    QCheckBox *pgxpCPU;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *EnhancementSettingsWidget)
    {
        if (EnhancementSettingsWidget->objectName().isEmpty())
            EnhancementSettingsWidget->setObjectName(QStringLiteral("EnhancementSettingsWidget"));
        EnhancementSettingsWidget->resize(448, 720);
        verticalLayout_2 = new QVBoxLayout(EnhancementSettingsWidget);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        groupBox_2 = new QGroupBox(EnhancementSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        formLayout_2 = new QFormLayout(groupBox_2);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_2);

        resolutionScale = new QComboBox(groupBox_2);
        resolutionScale->setObjectName(QStringLiteral("resolutionScale"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, resolutionScale);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_3);

        textureFiltering = new QComboBox(groupBox_2);
        textureFiltering->setObjectName(QStringLiteral("textureFiltering"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, textureFiltering);

        trueColor = new QCheckBox(groupBox_2);
        trueColor->setObjectName(QStringLiteral("trueColor"));

        formLayout_2->setWidget(3, QFormLayout::SpanningRole, trueColor);

        scaledDithering = new QCheckBox(groupBox_2);
        scaledDithering->setObjectName(QStringLiteral("scaledDithering"));

        formLayout_2->setWidget(4, QFormLayout::SpanningRole, scaledDithering);

        widescreenHack = new QCheckBox(groupBox_2);
        widescreenHack->setObjectName(QStringLiteral("widescreenHack"));

        formLayout_2->setWidget(5, QFormLayout::SpanningRole, widescreenHack);

        label = new QLabel(groupBox_2);
        label->setObjectName(QStringLiteral("label"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label);

        msaaMode = new QComboBox(groupBox_2);
        msaaMode->setObjectName(QStringLiteral("msaaMode"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, msaaMode);


        verticalLayout_2->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(EnhancementSettingsWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        formLayout_3 = new QFormLayout(groupBox_3);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        disableInterlacing = new QCheckBox(groupBox_3);
        disableInterlacing->setObjectName(QStringLiteral("disableInterlacing"));

        formLayout_3->setWidget(0, QFormLayout::SpanningRole, disableInterlacing);

        forceNTSCTimings = new QCheckBox(groupBox_3);
        forceNTSCTimings->setObjectName(QStringLiteral("forceNTSCTimings"));

        formLayout_3->setWidget(1, QFormLayout::SpanningRole, forceNTSCTimings);

        force43For24Bit = new QCheckBox(groupBox_3);
        force43For24Bit->setObjectName(QStringLiteral("force43For24Bit"));

        formLayout_3->setWidget(2, QFormLayout::SpanningRole, force43For24Bit);

        chromaSmoothingFor24Bit = new QCheckBox(groupBox_3);
        chromaSmoothingFor24Bit->setObjectName(QStringLiteral("chromaSmoothingFor24Bit"));

        formLayout_3->setWidget(3, QFormLayout::SpanningRole, chromaSmoothingFor24Bit);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(EnhancementSettingsWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayout = new QGridLayout(groupBox_4);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pgxpEnable = new QCheckBox(groupBox_4);
        pgxpEnable->setObjectName(QStringLiteral("pgxpEnable"));

        gridLayout->addWidget(pgxpEnable, 0, 0, 1, 1);

        pgxpCulling = new QCheckBox(groupBox_4);
        pgxpCulling->setObjectName(QStringLiteral("pgxpCulling"));

        gridLayout->addWidget(pgxpCulling, 0, 1, 1, 1);

        pgxpTextureCorrection = new QCheckBox(groupBox_4);
        pgxpTextureCorrection->setObjectName(QStringLiteral("pgxpTextureCorrection"));

        gridLayout->addWidget(pgxpTextureCorrection, 1, 0, 1, 1);

        pgxpPreserveProjPrecision = new QCheckBox(groupBox_4);
        pgxpPreserveProjPrecision->setObjectName(QStringLiteral("pgxpPreserveProjPrecision"));

        gridLayout->addWidget(pgxpPreserveProjPrecision, 1, 1, 1, 1);

        pgxpDepthBuffer = new QCheckBox(groupBox_4);
        pgxpDepthBuffer->setObjectName(QStringLiteral("pgxpDepthBuffer"));

        gridLayout->addWidget(pgxpDepthBuffer, 2, 0, 1, 1);

        pgxpCPU = new QCheckBox(groupBox_4);
        pgxpCPU->setObjectName(QStringLiteral("pgxpCPU"));

        gridLayout->addWidget(pgxpCPU, 2, 1, 1, 1);


        verticalLayout_2->addWidget(groupBox_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        retranslateUi(EnhancementSettingsWidget);

        QMetaObject::connectSlotsByName(EnhancementSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *EnhancementSettingsWidget)
    {
        EnhancementSettingsWidget->setWindowTitle(QApplication::translate("EnhancementSettingsWidget", "Form", nullptr));
        groupBox_2->setTitle(QApplication::translate("EnhancementSettingsWidget", "Rendering Enhancements", nullptr));
        label_2->setText(QApplication::translate("EnhancementSettingsWidget", "Internal Resolution Scale:", nullptr));
        label_3->setText(QApplication::translate("EnhancementSettingsWidget", "Texture Filtering:", nullptr));
        trueColor->setText(QApplication::translate("EnhancementSettingsWidget", "True Color Rendering (24-bit, disables dithering)", nullptr));
        scaledDithering->setText(QApplication::translate("EnhancementSettingsWidget", "Scaled Dithering (scale dither pattern to resolution)", nullptr));
        widescreenHack->setText(QApplication::translate("EnhancementSettingsWidget", "Widescreen Hack (render 3D in display aspect ratio)", nullptr));
        label->setText(QApplication::translate("EnhancementSettingsWidget", "Multisample Antialiasing:", nullptr));
        groupBox_3->setTitle(QApplication::translate("EnhancementSettingsWidget", "Display Enhancements", nullptr));
        disableInterlacing->setText(QApplication::translate("EnhancementSettingsWidget", "Disable Interlacing (force progressive render/scan)", nullptr));
        forceNTSCTimings->setText(QApplication::translate("EnhancementSettingsWidget", "Force NTSC Timings (60hz-on-PAL)", nullptr));
        force43For24Bit->setText(QApplication::translate("EnhancementSettingsWidget", "Force 4:3 For 24-Bit Display (disable widescreen for FMVs)", nullptr));
        chromaSmoothingFor24Bit->setText(QApplication::translate("EnhancementSettingsWidget", "Chroma Smoothing For 24-Bit Display (reduce FMV color blockyness)", nullptr));
        groupBox_4->setTitle(QApplication::translate("EnhancementSettingsWidget", "PGXP (Precision Geometry Transform Pipeline)", nullptr));
        pgxpEnable->setText(QApplication::translate("EnhancementSettingsWidget", "Geometry Correction", nullptr));
        pgxpCulling->setText(QApplication::translate("EnhancementSettingsWidget", "Culling Correction", nullptr));
        pgxpTextureCorrection->setText(QApplication::translate("EnhancementSettingsWidget", "Texture Correction", nullptr));
        pgxpPreserveProjPrecision->setText(QApplication::translate("EnhancementSettingsWidget", "Preserve Projection Precision", nullptr));
        pgxpDepthBuffer->setText(QApplication::translate("EnhancementSettingsWidget", "Depth Buffer (Low Compatibility)", nullptr));
        pgxpCPU->setText(QApplication::translate("EnhancementSettingsWidget", "CPU Mode (Very Slow)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EnhancementSettingsWidget: public Ui_EnhancementSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENHANCEMENTSETTINGSWIDGET_H
