/********************************************************************************
** Form generated from reading UI file 'inputbindingdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INPUTBINDINGDIALOG_H
#define UI_INPUTBINDINGDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_InputBindingDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *title;
    QListWidget *bindingList;
    QLabel *status;
    QHBoxLayout *horizontalLayout;
    QPushButton *addBinding;
    QPushButton *removeBinding;
    QPushButton *clearBindings;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *InputBindingDialog)
    {
        if (InputBindingDialog->objectName().isEmpty())
            InputBindingDialog->setObjectName(QStringLiteral("InputBindingDialog"));
        InputBindingDialog->setWindowModality(Qt::WindowModal);
        InputBindingDialog->resize(533, 283);
        InputBindingDialog->setModal(true);
        verticalLayout = new QVBoxLayout(InputBindingDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        title = new QLabel(InputBindingDialog);
        title->setObjectName(QStringLiteral("title"));

        verticalLayout->addWidget(title);

        bindingList = new QListWidget(InputBindingDialog);
        bindingList->setObjectName(QStringLiteral("bindingList"));

        verticalLayout->addWidget(bindingList);

        status = new QLabel(InputBindingDialog);
        status->setObjectName(QStringLiteral("status"));

        verticalLayout->addWidget(status);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        addBinding = new QPushButton(InputBindingDialog);
        addBinding->setObjectName(QStringLiteral("addBinding"));

        horizontalLayout->addWidget(addBinding);

        removeBinding = new QPushButton(InputBindingDialog);
        removeBinding->setObjectName(QStringLiteral("removeBinding"));

        horizontalLayout->addWidget(removeBinding);

        clearBindings = new QPushButton(InputBindingDialog);
        clearBindings->setObjectName(QStringLiteral("clearBindings"));

        horizontalLayout->addWidget(clearBindings);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        buttonBox = new QDialogButtonBox(InputBindingDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setStandardButtons(QDialogButtonBox::Close);

        horizontalLayout->addWidget(buttonBox);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(InputBindingDialog);

        QMetaObject::connectSlotsByName(InputBindingDialog);
    } // setupUi

    void retranslateUi(QDialog *InputBindingDialog)
    {
        InputBindingDialog->setWindowTitle(QApplication::translate("InputBindingDialog", "Edit Bindings", nullptr));
        title->setText(QApplication::translate("InputBindingDialog", "Bindings for Controller0/ButtonCircle", nullptr));
        status->setText(QString());
        addBinding->setText(QApplication::translate("InputBindingDialog", "Add Binding", nullptr));
        removeBinding->setText(QApplication::translate("InputBindingDialog", "Remove Binding", nullptr));
        clearBindings->setText(QApplication::translate("InputBindingDialog", "Clear Bindings", nullptr));
    } // retranslateUi

};

namespace Ui {
    class InputBindingDialog: public Ui_InputBindingDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INPUTBINDINGDIALOG_H
