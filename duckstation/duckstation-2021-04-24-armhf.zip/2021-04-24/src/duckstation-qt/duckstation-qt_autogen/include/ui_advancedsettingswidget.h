/********************************************************************************
** Form generated from reading UI file 'advancedsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADVANCEDSETTINGSWIDGET_H
#define UI_ADVANCEDSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdvancedSettingsWidget
{
public:
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_3;
    QFormLayout *formLayout_4;
    QLabel *label;
    QComboBox *logLevel;
    QLabel *label_2;
    QLineEdit *logFilter;
    QGridLayout *gridLayout_2;
    QCheckBox *logToConsole;
    QCheckBox *logToWindow;
    QCheckBox *logToDebug;
    QCheckBox *logToFile;
    QGroupBox *groupBox_2;
    QGridLayout *formLayout;
    QCheckBox *showDebugMenu;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout;
    QTableWidget *tweakOptionTable;
    QPushButton *resetToDefaultButton;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QWidget *AdvancedSettingsWidget)
    {
        if (AdvancedSettingsWidget->objectName().isEmpty())
            AdvancedSettingsWidget->setObjectName(QStringLiteral("AdvancedSettingsWidget"));
        AdvancedSettingsWidget->resize(973, 507);
        verticalLayout_4 = new QVBoxLayout(AdvancedSettingsWidget);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        groupBox_4 = new QGroupBox(AdvancedSettingsWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        verticalLayout_3 = new QVBoxLayout(groupBox_4);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        formLayout_4 = new QFormLayout();
        formLayout_4->setObjectName(QStringLiteral("formLayout_4"));
        label = new QLabel(groupBox_4);
        label->setObjectName(QStringLiteral("label"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label);

        logLevel = new QComboBox(groupBox_4);
        logLevel->setObjectName(QStringLiteral("logLevel"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, logLevel);

        label_2 = new QLabel(groupBox_4);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout_4->setWidget(1, QFormLayout::LabelRole, label_2);

        logFilter = new QLineEdit(groupBox_4);
        logFilter->setObjectName(QStringLiteral("logFilter"));

        formLayout_4->setWidget(1, QFormLayout::FieldRole, logFilter);


        verticalLayout_3->addLayout(formLayout_4);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        logToConsole = new QCheckBox(groupBox_4);
        logToConsole->setObjectName(QStringLiteral("logToConsole"));

        gridLayout_2->addWidget(logToConsole, 0, 0, 1, 1);

        logToWindow = new QCheckBox(groupBox_4);
        logToWindow->setObjectName(QStringLiteral("logToWindow"));

        gridLayout_2->addWidget(logToWindow, 0, 1, 1, 1);

        logToDebug = new QCheckBox(groupBox_4);
        logToDebug->setObjectName(QStringLiteral("logToDebug"));

        gridLayout_2->addWidget(logToDebug, 1, 0, 1, 1);

        logToFile = new QCheckBox(groupBox_4);
        logToFile->setObjectName(QStringLiteral("logToFile"));

        gridLayout_2->addWidget(logToFile, 1, 1, 1, 1);


        verticalLayout_3->addLayout(gridLayout_2);


        verticalLayout_4->addWidget(groupBox_4);

        groupBox_2 = new QGroupBox(AdvancedSettingsWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        formLayout = new QGridLayout(groupBox_2);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        showDebugMenu = new QCheckBox(groupBox_2);
        showDebugMenu->setObjectName(QStringLiteral("showDebugMenu"));

        formLayout->addWidget(showDebugMenu, 0, 0, 1, 1);


        verticalLayout_4->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(AdvancedSettingsWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout = new QGridLayout(groupBox_3);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        tweakOptionTable = new QTableWidget(groupBox_3);
        if (tweakOptionTable->columnCount() < 2)
            tweakOptionTable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tweakOptionTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tweakOptionTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tweakOptionTable->setObjectName(QStringLiteral("tweakOptionTable"));
        tweakOptionTable->setCornerButtonEnabled(false);
        tweakOptionTable->horizontalHeader()->setVisible(false);
        tweakOptionTable->verticalHeader()->setVisible(false);

        gridLayout->addWidget(tweakOptionTable, 0, 0, 1, 1);

        resetToDefaultButton = new QPushButton(groupBox_3);
        resetToDefaultButton->setObjectName(QStringLiteral("resetToDefaultButton"));

        gridLayout->addWidget(resetToDefaultButton, 1, 0, 1, 1);


        verticalLayout_4->addWidget(groupBox_3);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);


        retranslateUi(AdvancedSettingsWidget);

        QMetaObject::connectSlotsByName(AdvancedSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *AdvancedSettingsWidget)
    {
        AdvancedSettingsWidget->setWindowTitle(QApplication::translate("AdvancedSettingsWidget", "Form", nullptr));
        groupBox_4->setTitle(QApplication::translate("AdvancedSettingsWidget", "Logging", nullptr));
        label->setText(QApplication::translate("AdvancedSettingsWidget", "Log Level:", nullptr));
        label_2->setText(QApplication::translate("AdvancedSettingsWidget", "Log Filters:", nullptr));
        logToConsole->setText(QApplication::translate("AdvancedSettingsWidget", "Log To System Console", nullptr));
        logToWindow->setText(QApplication::translate("AdvancedSettingsWidget", "Log To Window", nullptr));
        logToDebug->setText(QApplication::translate("AdvancedSettingsWidget", "Log To Debug Console", nullptr));
        logToFile->setText(QApplication::translate("AdvancedSettingsWidget", "Log To File", nullptr));
        groupBox_2->setTitle(QApplication::translate("AdvancedSettingsWidget", "System Settings", nullptr));
        showDebugMenu->setText(QApplication::translate("AdvancedSettingsWidget", "Show Debug Menu", nullptr));
        groupBox_3->setTitle(QApplication::translate("AdvancedSettingsWidget", "Tweaks/Hacks", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tweakOptionTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("AdvancedSettingsWidget", "Option", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tweakOptionTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("AdvancedSettingsWidget", "Value", nullptr));
        resetToDefaultButton->setText(QApplication::translate("AdvancedSettingsWidget", "Reset To Default", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdvancedSettingsWidget: public Ui_AdvancedSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADVANCEDSETTINGSWIDGET_H
