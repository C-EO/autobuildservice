/********************************************************************************
** Form generated from reading UI file 'emulationsettingswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMULATIONSETTINGSWIDGET_H
#define UI_EMULATIONSETTINGSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EmulationSettingsWidget
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_5;
    QFormLayout *formLayout_2;
    QLabel *label_4;
    QComboBox *emulationSpeed;
    QLabel *label_5;
    QComboBox *fastForwardSpeed;
    QLabel *label_6;
    QComboBox *turboSpeed;
    QCheckBox *syncToHostRefreshRate;
    QGroupBox *groupBox;
    QFormLayout *formLayout;
    QCheckBox *rewindEnable;
    QLabel *label_2;
    QDoubleSpinBox *rewindSaveFrequency;
    QLabel *label;
    QSpinBox *rewindSaveSlots;
    QLabel *label_3;
    QComboBox *runaheadFrames;
    QLabel *rewindSummary;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *EmulationSettingsWidget)
    {
        if (EmulationSettingsWidget->objectName().isEmpty())
            EmulationSettingsWidget->setObjectName(QStringLiteral("EmulationSettingsWidget"));
        EmulationSettingsWidget->resize(672, 518);
        verticalLayout = new QVBoxLayout(EmulationSettingsWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox_5 = new QGroupBox(EmulationSettingsWidget);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        formLayout_2 = new QFormLayout(groupBox_5);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_4 = new QLabel(groupBox_5);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_4);

        emulationSpeed = new QComboBox(groupBox_5);
        emulationSpeed->setObjectName(QStringLiteral("emulationSpeed"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, emulationSpeed);

        label_5 = new QLabel(groupBox_5);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_5);

        fastForwardSpeed = new QComboBox(groupBox_5);
        fastForwardSpeed->setObjectName(QStringLiteral("fastForwardSpeed"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, fastForwardSpeed);

        label_6 = new QLabel(groupBox_5);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_6);

        turboSpeed = new QComboBox(groupBox_5);
        turboSpeed->setObjectName(QStringLiteral("turboSpeed"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, turboSpeed);

        syncToHostRefreshRate = new QCheckBox(groupBox_5);
        syncToHostRefreshRate->setObjectName(QStringLiteral("syncToHostRefreshRate"));

        formLayout_2->setWidget(3, QFormLayout::SpanningRole, syncToHostRefreshRate);


        verticalLayout->addWidget(groupBox_5);

        groupBox = new QGroupBox(EmulationSettingsWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        formLayout = new QFormLayout(groupBox);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        rewindEnable = new QCheckBox(groupBox);
        rewindEnable->setObjectName(QStringLiteral("rewindEnable"));

        formLayout->setWidget(0, QFormLayout::SpanningRole, rewindEnable);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        rewindSaveFrequency = new QDoubleSpinBox(groupBox);
        rewindSaveFrequency->setObjectName(QStringLiteral("rewindSaveFrequency"));
        rewindSaveFrequency->setMaximum(3600);
        rewindSaveFrequency->setSingleStep(0.1);

        formLayout->setWidget(1, QFormLayout::FieldRole, rewindSaveFrequency);

        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label);

        rewindSaveSlots = new QSpinBox(groupBox);
        rewindSaveSlots->setObjectName(QStringLiteral("rewindSaveSlots"));
        rewindSaveSlots->setMinimum(1);
        rewindSaveSlots->setMaximum(10000);

        formLayout->setWidget(2, QFormLayout::FieldRole, rewindSaveSlots);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_3);

        runaheadFrames = new QComboBox(groupBox);
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->addItem(QString());
        runaheadFrames->setObjectName(QStringLiteral("runaheadFrames"));

        formLayout->setWidget(3, QFormLayout::FieldRole, runaheadFrames);

        rewindSummary = new QLabel(groupBox);
        rewindSummary->setObjectName(QStringLiteral("rewindSummary"));
        rewindSummary->setWordWrap(true);

        formLayout->setWidget(4, QFormLayout::SpanningRole, rewindSummary);


        verticalLayout->addWidget(groupBox);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(EmulationSettingsWidget);

        QMetaObject::connectSlotsByName(EmulationSettingsWidget);
    } // setupUi

    void retranslateUi(QWidget *EmulationSettingsWidget)
    {
        EmulationSettingsWidget->setWindowTitle(QApplication::translate("EmulationSettingsWidget", "Form", nullptr));
        groupBox_5->setTitle(QApplication::translate("EmulationSettingsWidget", "Speed Control", nullptr));
        label_4->setText(QApplication::translate("EmulationSettingsWidget", "Emulation Speed:", nullptr));
        label_5->setText(QApplication::translate("EmulationSettingsWidget", "Fast Forward Speed:", nullptr));
        label_6->setText(QApplication::translate("EmulationSettingsWidget", "Turbo Speed:", nullptr));
        syncToHostRefreshRate->setText(QApplication::translate("EmulationSettingsWidget", "Sync To Host Refresh Rate", nullptr));
        groupBox->setTitle(QApplication::translate("EmulationSettingsWidget", "Rewind/Runahead", nullptr));
        rewindEnable->setText(QApplication::translate("EmulationSettingsWidget", "Enable Rewinding", nullptr));
        label_2->setText(QApplication::translate("EmulationSettingsWidget", "Rewind Save Frequency:", nullptr));
        rewindSaveFrequency->setSuffix(QApplication::translate("EmulationSettingsWidget", " Seconds", nullptr));
        label->setText(QApplication::translate("EmulationSettingsWidget", "Rewind Buffer Size:", nullptr));
        rewindSaveSlots->setSuffix(QApplication::translate("EmulationSettingsWidget", " Frames", nullptr));
        label_3->setText(QApplication::translate("EmulationSettingsWidget", "Runahead:", nullptr));
        runaheadFrames->setItemText(0, QApplication::translate("EmulationSettingsWidget", "Disabled", nullptr));
        runaheadFrames->setItemText(1, QApplication::translate("EmulationSettingsWidget", "1 Frame", nullptr));
        runaheadFrames->setItemText(2, QApplication::translate("EmulationSettingsWidget", "2 Frames", nullptr));
        runaheadFrames->setItemText(3, QApplication::translate("EmulationSettingsWidget", "3 Frames", nullptr));
        runaheadFrames->setItemText(4, QApplication::translate("EmulationSettingsWidget", "4 Frames", nullptr));
        runaheadFrames->setItemText(5, QApplication::translate("EmulationSettingsWidget", "5 Frames", nullptr));
        runaheadFrames->setItemText(6, QApplication::translate("EmulationSettingsWidget", "6 Frames", nullptr));
        runaheadFrames->setItemText(7, QApplication::translate("EmulationSettingsWidget", "7 Frames", nullptr));
        runaheadFrames->setItemText(8, QApplication::translate("EmulationSettingsWidget", "8 Frames", nullptr));
        runaheadFrames->setItemText(9, QApplication::translate("EmulationSettingsWidget", "9 Frames", nullptr));
        runaheadFrames->setItemText(10, QApplication::translate("EmulationSettingsWidget", "10 Frames", nullptr));

        rewindSummary->setText(QApplication::translate("EmulationSettingsWidget", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EmulationSettingsWidget: public Ui_EmulationSettingsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMULATIONSETTINGSWIDGET_H
