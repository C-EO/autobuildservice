/********************************************************************************
** Form generated from reading UI file 'debuggerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEBUGGERWINDOW_H
#define UI_DEBUGGERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "duckstation-qt/memoryviewwidget.h"

QT_BEGIN_NAMESPACE

class Ui_DebuggerWindow
{
public:
    QAction *actionPause;
    QAction *actionStepInto;
    QAction *actionStepOver;
    QAction *actionToggleBreakpoint;
    QAction *actionClose;
    QAction *actionStepOut;
    QAction *actionRunToCursor;
    QAction *actionClearBreakpoints;
    QAction *actionAddBreakpoint;
    QAction *actionGoToPC;
    QAction *actionGoToAddress;
    QAction *actionDumpAddress;
    QAction *actionTrace;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menu_Debugger;
    QMenu *menuBreakpoints;
    QStatusBar *statusbar;
    QToolBar *toolBar;
    QDockWidget *dockWidget_2;
    QTreeView *codeView;
    QDockWidget *dockWidget_3;
    QTreeView *registerView;
    QDockWidget *dockWidget;
    QWidget *dockWidgetContents_3;
    QVBoxLayout *verticalLayout;
    MemoryViewWidget *memoryView;
    QHBoxLayout *horizontalLayout;
    QRadioButton *memoryRegionRAM;
    QRadioButton *memoryRegionScratchpad;
    QRadioButton *memoryRegionEXP1;
    QRadioButton *memoryRegionBIOS;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *memorySearchString;
    QPushButton *memorySearch;
    QDockWidget *dockWidget_5;
    QTreeWidget *breakpointsWidget;
    QDockWidget *dockWidget_4;
    QTreeView *stackView;

    void setupUi(QMainWindow *DebuggerWindow)
    {
        if (DebuggerWindow->objectName().isEmpty())
            DebuggerWindow->setObjectName(QStringLiteral("DebuggerWindow"));
        DebuggerWindow->resize(1210, 800);
        DebuggerWindow->setDockNestingEnabled(true);
        actionPause = new QAction(DebuggerWindow);
        actionPause->setObjectName(QStringLiteral("actionPause"));
        actionPause->setCheckable(true);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/media-playback-pause.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPause->setIcon(icon);
        actionStepInto = new QAction(DebuggerWindow);
        actionStepInto->setObjectName(QStringLiteral("actionStepInto"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/debug-step-into-instruction.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStepInto->setIcon(icon1);
        actionStepOver = new QAction(DebuggerWindow);
        actionStepOver->setObjectName(QStringLiteral("actionStepOver"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/debug-step-over.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStepOver->setIcon(icon2);
        actionToggleBreakpoint = new QAction(DebuggerWindow);
        actionToggleBreakpoint->setObjectName(QStringLiteral("actionToggleBreakpoint"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/media-record@2x.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionToggleBreakpoint->setIcon(icon3);
        actionClose = new QAction(DebuggerWindow);
        actionClose->setObjectName(QStringLiteral("actionClose"));
        actionStepOut = new QAction(DebuggerWindow);
        actionStepOut->setObjectName(QStringLiteral("actionStepOut"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/debug-step-out.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStepOut->setIcon(icon4);
        actionRunToCursor = new QAction(DebuggerWindow);
        actionRunToCursor->setObjectName(QStringLiteral("actionRunToCursor"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/debug-run-cursor.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRunToCursor->setIcon(icon5);
        actionClearBreakpoints = new QAction(DebuggerWindow);
        actionClearBreakpoints->setObjectName(QStringLiteral("actionClearBreakpoints"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/edit-clear-16.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionClearBreakpoints->setIcon(icon6);
        actionAddBreakpoint = new QAction(DebuggerWindow);
        actionAddBreakpoint->setObjectName(QStringLiteral("actionAddBreakpoint"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/icons/list-add.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddBreakpoint->setIcon(icon7);
        actionGoToPC = new QAction(DebuggerWindow);
        actionGoToPC->setObjectName(QStringLiteral("actionGoToPC"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/icons/document-open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionGoToPC->setIcon(icon8);
        actionGoToAddress = new QAction(DebuggerWindow);
        actionGoToAddress->setObjectName(QStringLiteral("actionGoToAddress"));
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/icons/applications-system.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionGoToAddress->setIcon(icon9);
        actionDumpAddress = new QAction(DebuggerWindow);
        actionDumpAddress->setObjectName(QStringLiteral("actionDumpAddress"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/icons/antialias-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDumpAddress->setIcon(icon10);
        actionTrace = new QAction(DebuggerWindow);
        actionTrace->setObjectName(QStringLiteral("actionTrace"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/icons/debug-trace.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionTrace->setIcon(icon11);
        centralwidget = new QWidget(DebuggerWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        DebuggerWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(DebuggerWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1210, 21));
        menu_Debugger = new QMenu(menubar);
        menu_Debugger->setObjectName(QStringLiteral("menu_Debugger"));
        menuBreakpoints = new QMenu(menubar);
        menuBreakpoints->setObjectName(QStringLiteral("menuBreakpoints"));
        DebuggerWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(DebuggerWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        DebuggerWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(DebuggerWindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        DebuggerWindow->addToolBar(Qt::TopToolBarArea, toolBar);
        dockWidget_2 = new QDockWidget(DebuggerWindow);
        dockWidget_2->setObjectName(QStringLiteral("dockWidget_2"));
        dockWidget_2->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        codeView = new QTreeView();
        codeView->setObjectName(QStringLiteral("codeView"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(codeView->sizePolicy().hasHeightForWidth());
        codeView->setSizePolicy(sizePolicy);
        dockWidget_2->setWidget(codeView);
        codeView->header()->setVisible(false);
        DebuggerWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(4), dockWidget_2);
        dockWidget_3 = new QDockWidget(DebuggerWindow);
        dockWidget_3->setObjectName(QStringLiteral("dockWidget_3"));
        dockWidget_3->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        registerView = new QTreeView();
        registerView->setObjectName(QStringLiteral("registerView"));
        sizePolicy.setHeightForWidth(registerView->sizePolicy().hasHeightForWidth());
        registerView->setSizePolicy(sizePolicy);
        registerView->setMaximumSize(QSize(220, 16777215));
        dockWidget_3->setWidget(registerView);
        DebuggerWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(4), dockWidget_3);
        dockWidget = new QDockWidget(DebuggerWindow);
        dockWidget->setObjectName(QStringLiteral("dockWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(dockWidget->sizePolicy().hasHeightForWidth());
        dockWidget->setSizePolicy(sizePolicy1);
        dockWidget->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetContents_3 = new QWidget();
        dockWidgetContents_3->setObjectName(QStringLiteral("dockWidgetContents_3"));
        verticalLayout = new QVBoxLayout(dockWidgetContents_3);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        memoryView = new MemoryViewWidget(dockWidgetContents_3);
        memoryView->setObjectName(QStringLiteral("memoryView"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(memoryView->sizePolicy().hasHeightForWidth());
        memoryView->setSizePolicy(sizePolicy2);

        verticalLayout->addWidget(memoryView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        memoryRegionRAM = new QRadioButton(dockWidgetContents_3);
        memoryRegionRAM->setObjectName(QStringLiteral("memoryRegionRAM"));
        memoryRegionRAM->setChecked(true);

        horizontalLayout->addWidget(memoryRegionRAM);

        memoryRegionScratchpad = new QRadioButton(dockWidgetContents_3);
        memoryRegionScratchpad->setObjectName(QStringLiteral("memoryRegionScratchpad"));

        horizontalLayout->addWidget(memoryRegionScratchpad);

        memoryRegionEXP1 = new QRadioButton(dockWidgetContents_3);
        memoryRegionEXP1->setObjectName(QStringLiteral("memoryRegionEXP1"));

        horizontalLayout->addWidget(memoryRegionEXP1);

        memoryRegionBIOS = new QRadioButton(dockWidgetContents_3);
        memoryRegionBIOS->setObjectName(QStringLiteral("memoryRegionBIOS"));

        horizontalLayout->addWidget(memoryRegionBIOS);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        memorySearchString = new QLineEdit(dockWidgetContents_3);
        memorySearchString->setObjectName(QStringLiteral("memorySearchString"));

        horizontalLayout_2->addWidget(memorySearchString);

        memorySearch = new QPushButton(dockWidgetContents_3);
        memorySearch->setObjectName(QStringLiteral("memorySearch"));

        horizontalLayout_2->addWidget(memorySearch);


        horizontalLayout->addLayout(horizontalLayout_2);


        verticalLayout->addLayout(horizontalLayout);

        dockWidget->setWidget(dockWidgetContents_3);
        DebuggerWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(8), dockWidget);
        dockWidget_5 = new QDockWidget(DebuggerWindow);
        dockWidget_5->setObjectName(QStringLiteral("dockWidget_5"));
        QSizePolicy sizePolicy3(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(dockWidget_5->sizePolicy().hasHeightForWidth());
        dockWidget_5->setSizePolicy(sizePolicy3);
        dockWidget_5->setMaximumSize(QSize(200, 524287));
        dockWidget_5->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        breakpointsWidget = new QTreeWidget();
        breakpointsWidget->setObjectName(QStringLiteral("breakpointsWidget"));
        breakpointsWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        breakpointsWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        breakpointsWidget->setSortingEnabled(true);
        dockWidget_5->setWidget(breakpointsWidget);
        breakpointsWidget->header()->setMinimumSectionSize(20);
        DebuggerWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(8), dockWidget_5);
        dockWidget_4 = new QDockWidget(DebuggerWindow);
        dockWidget_4->setObjectName(QStringLiteral("dockWidget_4"));
        dockWidget_4->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        stackView = new QTreeView();
        stackView->setObjectName(QStringLiteral("stackView"));
        stackView->setMaximumSize(QSize(220, 16777215));
        dockWidget_4->setWidget(stackView);
        DebuggerWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(8), dockWidget_4);

        menubar->addAction(menu_Debugger->menuAction());
        menubar->addAction(menuBreakpoints->menuAction());
        menu_Debugger->addAction(actionPause);
        menu_Debugger->addAction(actionRunToCursor);
        menu_Debugger->addSeparator();
        menu_Debugger->addAction(actionGoToPC);
        menu_Debugger->addAction(actionGoToAddress);
        menu_Debugger->addAction(actionDumpAddress);
        menu_Debugger->addSeparator();
        menu_Debugger->addAction(actionTrace);
        menu_Debugger->addSeparator();
        menu_Debugger->addAction(actionStepInto);
        menu_Debugger->addAction(actionStepOver);
        menu_Debugger->addAction(actionStepOut);
        menu_Debugger->addSeparator();
        menu_Debugger->addAction(actionClose);
        menuBreakpoints->addAction(actionAddBreakpoint);
        menuBreakpoints->addAction(actionToggleBreakpoint);
        menuBreakpoints->addAction(actionClearBreakpoints);
        toolBar->addAction(actionPause);
        toolBar->addAction(actionRunToCursor);
        toolBar->addSeparator();
        toolBar->addAction(actionGoToPC);
        toolBar->addAction(actionGoToAddress);
        toolBar->addAction(actionDumpAddress);
        toolBar->addSeparator();
        toolBar->addAction(actionAddBreakpoint);
        toolBar->addAction(actionToggleBreakpoint);
        toolBar->addAction(actionClearBreakpoints);
        toolBar->addSeparator();
        toolBar->addAction(actionStepInto);
        toolBar->addAction(actionStepOver);
        toolBar->addAction(actionStepOut);
        toolBar->addSeparator();
        toolBar->addAction(actionTrace);

        retranslateUi(DebuggerWindow);

        QMetaObject::connectSlotsByName(DebuggerWindow);
    } // setupUi

    void retranslateUi(QMainWindow *DebuggerWindow)
    {
        DebuggerWindow->setWindowTitle(QApplication::translate("DebuggerWindow", "CPU Debugger", nullptr));
        actionPause->setText(QApplication::translate("DebuggerWindow", "Pause/Continue", nullptr));
#ifndef QT_NO_TOOLTIP
        actionPause->setToolTip(QApplication::translate("DebuggerWindow", "&Pause/Continue", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionPause->setShortcut(QApplication::translate("DebuggerWindow", "F5", nullptr));
#endif // QT_NO_SHORTCUT
        actionStepInto->setText(QApplication::translate("DebuggerWindow", "Step Into", nullptr));
#ifndef QT_NO_TOOLTIP
        actionStepInto->setToolTip(QApplication::translate("DebuggerWindow", "&Step Into", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionStepInto->setShortcut(QApplication::translate("DebuggerWindow", "F11", nullptr));
#endif // QT_NO_SHORTCUT
        actionStepOver->setText(QApplication::translate("DebuggerWindow", "Step Over", nullptr));
#ifndef QT_NO_TOOLTIP
        actionStepOver->setToolTip(QApplication::translate("DebuggerWindow", "Step &Over", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionStepOver->setShortcut(QApplication::translate("DebuggerWindow", "F10", nullptr));
#endif // QT_NO_SHORTCUT
        actionToggleBreakpoint->setText(QApplication::translate("DebuggerWindow", "Toggle Breakpoint", nullptr));
#ifndef QT_NO_TOOLTIP
        actionToggleBreakpoint->setToolTip(QApplication::translate("DebuggerWindow", "Toggle &Breakpoint", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionToggleBreakpoint->setShortcut(QApplication::translate("DebuggerWindow", "F9", nullptr));
#endif // QT_NO_SHORTCUT
        actionClose->setText(QApplication::translate("DebuggerWindow", "&Close", nullptr));
        actionStepOut->setText(QApplication::translate("DebuggerWindow", "Step Out", nullptr));
#ifndef QT_NO_TOOLTIP
        actionStepOut->setToolTip(QApplication::translate("DebuggerWindow", "Step O&ut", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionStepOut->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+F11", nullptr));
#endif // QT_NO_SHORTCUT
        actionRunToCursor->setText(QApplication::translate("DebuggerWindow", "Run To Cursor", nullptr));
#ifndef QT_NO_TOOLTIP
        actionRunToCursor->setToolTip(QApplication::translate("DebuggerWindow", "&Run To Cursor", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionRunToCursor->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+F10", nullptr));
#endif // QT_NO_SHORTCUT
        actionClearBreakpoints->setText(QApplication::translate("DebuggerWindow", "Clear Breakpoints", nullptr));
#ifndef QT_NO_TOOLTIP
        actionClearBreakpoints->setToolTip(QApplication::translate("DebuggerWindow", "&Clear Breakpoints", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionClearBreakpoints->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+Del", nullptr));
#endif // QT_NO_SHORTCUT
        actionAddBreakpoint->setText(QApplication::translate("DebuggerWindow", "Add Breakpoint", nullptr));
#ifndef QT_NO_TOOLTIP
        actionAddBreakpoint->setToolTip(QApplication::translate("DebuggerWindow", "Add &Breakpoint", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionAddBreakpoint->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+F9", nullptr));
#endif // QT_NO_SHORTCUT
        actionGoToPC->setText(QApplication::translate("DebuggerWindow", "Go To PC", nullptr));
#ifndef QT_NO_TOOLTIP
        actionGoToPC->setToolTip(QApplication::translate("DebuggerWindow", "&Go To PC", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionGoToPC->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+P", nullptr));
#endif // QT_NO_SHORTCUT
        actionGoToAddress->setText(QApplication::translate("DebuggerWindow", "Go To Address", nullptr));
#ifndef QT_NO_TOOLTIP
        actionGoToAddress->setToolTip(QApplication::translate("DebuggerWindow", "Go To &Address", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionGoToAddress->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+G", nullptr));
#endif // QT_NO_SHORTCUT
        actionDumpAddress->setText(QApplication::translate("DebuggerWindow", "&Dump Address", nullptr));
#ifndef QT_NO_SHORTCUT
        actionDumpAddress->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+D", nullptr));
#endif // QT_NO_SHORTCUT
        actionTrace->setText(QApplication::translate("DebuggerWindow", "Trace", nullptr));
#ifndef QT_NO_TOOLTIP
        actionTrace->setToolTip(QApplication::translate("DebuggerWindow", "&Trace", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionTrace->setShortcut(QApplication::translate("DebuggerWindow", "Ctrl+T", nullptr));
#endif // QT_NO_SHORTCUT
        menu_Debugger->setTitle(QApplication::translate("DebuggerWindow", "&Debug", nullptr));
        menuBreakpoints->setTitle(QApplication::translate("DebuggerWindow", "Breakpoints", nullptr));
        toolBar->setWindowTitle(QApplication::translate("DebuggerWindow", "toolBar", nullptr));
        dockWidget_2->setWindowTitle(QApplication::translate("DebuggerWindow", "Disassembly", nullptr));
        dockWidget_3->setWindowTitle(QApplication::translate("DebuggerWindow", "Registers", nullptr));
        dockWidget->setWindowTitle(QApplication::translate("DebuggerWindow", "Memory", nullptr));
        memoryRegionRAM->setText(QApplication::translate("DebuggerWindow", "RAM", nullptr));
        memoryRegionScratchpad->setText(QApplication::translate("DebuggerWindow", "Scratchpad", nullptr));
        memoryRegionEXP1->setText(QApplication::translate("DebuggerWindow", "EXP1", nullptr));
        memoryRegionBIOS->setText(QApplication::translate("DebuggerWindow", "BIOS", nullptr));
        memorySearch->setText(QApplication::translate("DebuggerWindow", "Search", nullptr));
        dockWidget_5->setWindowTitle(QApplication::translate("DebuggerWindow", "Breakpoints", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = breakpointsWidget->headerItem();
        ___qtreewidgetitem->setText(2, QApplication::translate("DebuggerWindow", "Hit Count", nullptr));
        ___qtreewidgetitem->setText(1, QApplication::translate("DebuggerWindow", "Address", nullptr));
        ___qtreewidgetitem->setText(0, QApplication::translate("DebuggerWindow", "#", nullptr));
        dockWidget_4->setWindowTitle(QApplication::translate("DebuggerWindow", "Stack", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DebuggerWindow: public Ui_DebuggerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEBUGGERWINDOW_H
