/********************************************************************************
** Form generated from reading UI file 'postprocessingchainconfigwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_POSTPROCESSINGCHAINCONFIGWIDGET_H
#define UI_POSTPROCESSINGCHAINCONFIGWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PostProcessingChainConfigWidget
{
public:
    QHBoxLayout *horizontalLayout;
    QListWidget *shaders;
    QVBoxLayout *verticalLayout;
    QToolButton *add;
    QToolButton *remove;
    QToolButton *clear;
    QToolButton *moveUp;
    QToolButton *moveDown;
    QToolButton *shaderSettings;

    void setupUi(QWidget *PostProcessingChainConfigWidget)
    {
        if (PostProcessingChainConfigWidget->objectName().isEmpty())
            PostProcessingChainConfigWidget->setObjectName(QStringLiteral("PostProcessingChainConfigWidget"));
        PostProcessingChainConfigWidget->resize(721, 194);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PostProcessingChainConfigWidget->sizePolicy().hasHeightForWidth());
        PostProcessingChainConfigWidget->setSizePolicy(sizePolicy);
        horizontalLayout = new QHBoxLayout(PostProcessingChainConfigWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        shaders = new QListWidget(PostProcessingChainConfigWidget);
        shaders->setObjectName(QStringLiteral("shaders"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(shaders->sizePolicy().hasHeightForWidth());
        shaders->setSizePolicy(sizePolicy1);
        shaders->setMinimumSize(QSize(0, 80));

        horizontalLayout->addWidget(shaders);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        add = new QToolButton(PostProcessingChainConfigWidget);
        add->setObjectName(QStringLiteral("add"));
        sizePolicy.setHeightForWidth(add->sizePolicy().hasHeightForWidth());
        add->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/list-add.png"), QSize(), QIcon::Normal, QIcon::Off);
        add->setIcon(icon);
        add->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(add);

        remove = new QToolButton(PostProcessingChainConfigWidget);
        remove->setObjectName(QStringLiteral("remove"));
        sizePolicy.setHeightForWidth(remove->sizePolicy().hasHeightForWidth());
        remove->setSizePolicy(sizePolicy);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/list-remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        remove->setIcon(icon1);
        remove->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(remove);

        clear = new QToolButton(PostProcessingChainConfigWidget);
        clear->setObjectName(QStringLiteral("clear"));
        sizePolicy.setHeightForWidth(clear->sizePolicy().hasHeightForWidth());
        clear->setSizePolicy(sizePolicy);
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/edit-clear-16.png"), QSize(), QIcon::Normal, QIcon::Off);
        clear->setIcon(icon2);
        clear->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(clear);

        moveUp = new QToolButton(PostProcessingChainConfigWidget);
        moveUp->setObjectName(QStringLiteral("moveUp"));
        sizePolicy.setHeightForWidth(moveUp->sizePolicy().hasHeightForWidth());
        moveUp->setSizePolicy(sizePolicy);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/go-up-16.png"), QSize(), QIcon::Normal, QIcon::Off);
        moveUp->setIcon(icon3);
        moveUp->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(moveUp);

        moveDown = new QToolButton(PostProcessingChainConfigWidget);
        moveDown->setObjectName(QStringLiteral("moveDown"));
        sizePolicy.setHeightForWidth(moveDown->sizePolicy().hasHeightForWidth());
        moveDown->setSizePolicy(sizePolicy);
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/go-down-16.png"), QSize(), QIcon::Normal, QIcon::Off);
        moveDown->setIcon(icon4);
        moveDown->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(moveDown);

        shaderSettings = new QToolButton(PostProcessingChainConfigWidget);
        shaderSettings->setObjectName(QStringLiteral("shaderSettings"));
        sizePolicy.setHeightForWidth(shaderSettings->sizePolicy().hasHeightForWidth());
        shaderSettings->setSizePolicy(sizePolicy);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/preferences-system.png"), QSize(), QIcon::Normal, QIcon::Off);
        shaderSettings->setIcon(icon5);
        shaderSettings->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

        verticalLayout->addWidget(shaderSettings);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(PostProcessingChainConfigWidget);

        QMetaObject::connectSlotsByName(PostProcessingChainConfigWidget);
    } // setupUi

    void retranslateUi(QWidget *PostProcessingChainConfigWidget)
    {
        PostProcessingChainConfigWidget->setWindowTitle(QApplication::translate("PostProcessingChainConfigWidget", "Form", nullptr));
        add->setText(QApplication::translate("PostProcessingChainConfigWidget", "Add", nullptr));
        remove->setText(QApplication::translate("PostProcessingChainConfigWidget", "Remove", nullptr));
        clear->setText(QApplication::translate("PostProcessingChainConfigWidget", "Clear", nullptr));
        moveUp->setText(QApplication::translate("PostProcessingChainConfigWidget", "Move Up", nullptr));
        moveDown->setText(QApplication::translate("PostProcessingChainConfigWidget", "Move Down", nullptr));
        shaderSettings->setText(QApplication::translate("PostProcessingChainConfigWidget", "Options...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PostProcessingChainConfigWidget: public Ui_PostProcessingChainConfigWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_POSTPROCESSINGCHAINCONFIGWIDGET_H
